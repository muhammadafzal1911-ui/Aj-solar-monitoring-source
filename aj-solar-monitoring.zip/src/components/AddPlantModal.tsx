import React, { useState } from 'react';
import { X } from 'lucide-react';
import { Account, InverterStatus, Technician } from '../types/solar';
import { NewPlantInput } from '../data/demoData';

interface AddPlantModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (input: NewPlantInput) => void;
  defaultOwnerId: string;
  defaultCustomerName: string;
  customers?: Account[];
  technicians?: Technician[];
}

export const AddPlantModal: React.FC<AddPlantModalProps> = ({
  open,
  onClose,
  onSubmit,
  defaultOwnerId,
  defaultCustomerName,
  customers = [],
  technicians = [],
}) => {
  const [ownerId, setOwnerId] = useState(defaultOwnerId);
  const [customerName, setCustomerName] = useState(defaultCustomerName);
  const [name, setName] = useState('');
  const [location, setLocation] = useState('Lahore, Punjab');
  const [capacityKwp, setCapacityKwp] = useState('15');
  const [panelCount, setPanelCount] = useState('27');
  const [panelBrand, setPanelBrand] = useState('LONGi Solar');
  const [panelModel, setPanelModel] = useState('Hi-MO 6 565W Bifacial');
  const [inverterBrand, setInverterBrand] = useState('AJ Solutions');
  const [inverterModel, setInverterModel] = useState('AJ-HYB-15K Pro 3-Phase');
  const [batteryBrand, setBatteryBrand] = useState('AJ Vault');
  const [batteryCapacityKwh, setBatteryCapacityKwh] = useState('15.36');
  const [installedDate, setInstalledDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [status, setStatus] = useState<InverterStatus>('online');
  const [assignedTechnicianId, setAssignedTechnicianId] = useState(technicians[0]?.id || 'tech-1');

  if (!open) return null;

  const handleCustomerSelect = (nextOwnerId: string) => {
    setOwnerId(nextOwnerId);
    const found = customers.find((c) => c.id === nextOwnerId);
    if (found) setCustomerName(found.name);
  };

  const handleCapacityChange = (val: string) => {
    setCapacityKwp(val);
    const num = Number(val);
    if (num > 0) {
      setPanelCount(String(Math.max(1, Math.round((num * 1000) / 550))));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSubmit({
      ownerId: ownerId || defaultOwnerId,
      customerName: customerName.trim() || defaultCustomerName,
      name: name.trim(),
      location: location.trim() || 'Lahore, Punjab',
      capacityKwp: Number(capacityKwp) || 10,
      panelCount: Number(panelCount) || 18,
      panelBrand: panelBrand.trim() || 'LONGi Solar',
      panelModel: panelModel.trim() || 'Hi-MO 6 550W',
      inverterBrand: inverterBrand.trim() || 'AJ Solutions',
      inverterModel: inverterModel.trim() || 'AJ-HYB-12K Pro',
      batteryBrand: batteryBrand.trim() || 'AJ Vault',
      batteryCapacityKwh: Math.max(0, Number(batteryCapacityKwh) || 0),
      installedDate,
      status,
      assignedTechnicianId,
    });
    setName('');
    onClose();
  };

  const inputClass =
    'w-full min-h-[42px] px-3 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500';

  return (
    <div
      className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="add-plant-modal-title"
    >
      <div className="w-full sm:max-w-xl max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl panel-glass p-5 sm:p-6">
        <div className="w-10 h-1 bg-slate-400 dark:bg-slate-700 rounded-full mx-auto mb-3 sm:hidden" />
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 id="add-plant-modal-title" className="font-display text-lg font-semibold text-slate-900 dark:text-white">
              Add New Solar Plant
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Register system specifications in DEMO MODE telemetry
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close modal"
            className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Plant Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Gulberg Commercial Hub"
                className={inputClass}
              />
            </div>

            {customers.length > 0 ? (
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Customer Account
                </label>
                <select
                  value={ownerId}
                  onChange={(e) => handleCustomerSelect(e.target.value)}
                  className={inputClass}
                >
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.city})
                    </option>
                  ))}
                </select>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Customer Name
                </label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Customer full name"
                  className={inputClass}
                />
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Location
              </label>
              <input
                type="text"
                required
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="City, Province"
                className={inputClass}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Plant Status
              </label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as InverterStatus)}
                className={inputClass}
              >
                <option value="online">Online</option>
                <option value="warning">Warning</option>
                <option value="offline">Offline</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                System Capacity (kW)
              </label>
              <input
                type="number"
                min={1}
                max={500}
                step="0.1"
                required
                value={capacityKwp}
                onChange={(e) => handleCapacityChange(e.target.value)}
                className={`${inputClass} font-mono tabular-nums`}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Solar Panel Qty
              </label>
              <input
                type="number"
                min={1}
                max={2000}
                required
                value={panelCount}
                onChange={(e) => setPanelCount(e.target.value)}
                className={`${inputClass} font-mono tabular-nums`}
              />
            </div>
            <div className="col-span-2 sm:col-span-1">
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Installation Date
              </label>
              <input
                type="date"
                required
                value={installedDate}
                onChange={(e) => setInstalledDate(e.target.value)}
                className={`${inputClass} font-mono`}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Panel Brand
              </label>
              <input
                type="text"
                required
                value={panelBrand}
                onChange={(e) => setPanelBrand(e.target.value)}
                placeholder="e.g. LONGi Solar, JinkoSolar"
                className={inputClass}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Panel Model
              </label>
              <input
                type="text"
                required
                value={panelModel}
                onChange={(e) => setPanelModel(e.target.value)}
                placeholder="e.g. Hi-MO 6 565W Bifacial"
                className={inputClass}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Inverter Brand
              </label>
              <input
                type="text"
                required
                value={inverterBrand}
                onChange={(e) => setInverterBrand(e.target.value)}
                placeholder="e.g. AJ Solutions, GoodWe, Sungrow"
                className={inputClass}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Inverter Model
              </label>
              <input
                type="text"
                required
                value={inverterModel}
                onChange={(e) => setInverterModel(e.target.value)}
                placeholder="e.g. AJ-HYB-15K Pro"
                className={inputClass}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Battery Brand
              </label>
              <input
                type="text"
                value={batteryBrand}
                onChange={(e) => setBatteryBrand(e.target.value)}
                placeholder="e.g. AJ Vault, Pylontech"
                className={inputClass}
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Battery Capacity (kWh)
              </label>
              <input
                type="number"
                min={0}
                max={500}
                step="0.5"
                value={batteryCapacityKwh}
                onChange={(e) => setBatteryCapacityKwh(e.target.value)}
                className={`${inputClass} font-mono tabular-nums`}
              />
            </div>
            {technicians.length > 0 && (
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Assigned Technician
                </label>
                <select
                  value={assignedTechnicianId}
                  onChange={(e) => setAssignedTechnicianId(e.target.value)}
                  className={inputClass}
                >
                  {technicians.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="pt-2 flex gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 min-h-[46px] rounded-xl panel-inset text-sm font-medium text-slate-700 dark:text-slate-300"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 min-h-[46px] rounded-xl bg-emerald-600 hover:bg-emerald-500 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-sm font-semibold text-white dark:text-slate-950"
            >
              Add Solar Plant
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
