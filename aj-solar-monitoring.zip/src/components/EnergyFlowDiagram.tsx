import React from 'react';
import {
  ArrowDownLeft,
  ArrowUpRight,
  BatteryCharging,
  BatteryFull,
  Home,
  Sun,
  UtilityPole,
  Zap,
} from 'lucide-react';
import { SolarPlant } from '../types/solar';

interface EnergyFlowDiagramProps {
  plant: SolarPlant;
}

export const EnergyFlowDiagram: React.FC<EnergyFlowDiagramProps> = ({ plant }) => {
  const { telemetry, inverter, battery } = plant;
  const isOffline = inverter.status === 'offline';

  const solarActive = !isOffline && telemetry.solarKw > 0.05;
  const loadActive = !isOffline && telemetry.loadKw > 0.05;
  const gridImporting = !isOffline && telemetry.gridKw > 0.05;
  const gridExporting = !isOffline && telemetry.gridKw < -0.05;
  const batCharging = !isOffline && telemetry.batteryStatus === 'charging' && telemetry.batteryKw > 0.05;
  const batDischarging =
    !isOffline && telemetry.batteryStatus === 'discharging' && Math.abs(telemetry.batteryKw) > 0.05;

  const gridLabel = gridExporting ? 'Exporting' : gridImporting ? 'Importing' : 'Balanced';
  const batteryActionLabel = !battery
    ? 'Not Installed'
    : telemetry.batteryStatus === 'charging'
      ? 'Charging'
      : telemetry.batteryStatus === 'discharging'
        ? 'Discharging'
        : 'Standby';

  const gridImportVal = gridImporting ? telemetry.gridKw : 0;
  const solarCoveragePct =
    telemetry.loadKw > 0.05
      ? Math.max(0, Math.min(100, Math.round(((telemetry.loadKw - gridImportVal) / telemetry.loadKw) * 100)))
      : 100;

  return (
    <section
      aria-label="Live energy flow"
      className="panel-glass rounded-2xl p-4 sm:p-6 h-full flex flex-col justify-between"
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-4">
        <div>
          <h2 className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white">
            Energy Flow Topology
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {isOffline
              ? 'Power routing paused while inverter is offline'
              : 'Live directional power distribution across your system'}
          </p>
        </div>
        <div className="text-right shrink-0">
          <p className="text-[11px] text-slate-500 dark:text-slate-400">Self-Powered</p>
          <p className="font-mono text-sm font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums">
            {isOffline ? '0%' : `${solarCoveragePct}%`}
          </p>
        </div>
      </div>

      {/* Spacious Non-Overlapping 2x2 Quadrant + Central Inverter Layout */}
      <div className="my-auto py-1">
        {/* TOP ROW: Solar PV (Left) + Utility Grid (Right) */}
        <div className="grid grid-cols-2 gap-4 sm:gap-8">
          {/* Solar PV Node */}
          <div className="rounded-2xl panel-inset p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center gap-3 border-emerald-500/25 dark:border-emerald-500/30">
            <div
              className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                solarActive
                  ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-500'
              }`}
            >
              <Sun className="w-6 h-6" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300">Solar Panels</p>
              <p className="font-mono text-lg sm:text-xl font-semibold text-slate-900 dark:text-white tabular-nums leading-tight mt-0.5">
                {telemetry.solarKw.toFixed(2)}
                <span className="text-xs font-normal text-emerald-600 dark:text-emerald-400 ml-1">kW</span>
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                {solarActive ? 'Generating' : 'Idle'}
              </p>
            </div>
          </div>

          {/* Utility Grid Node */}
          <div className="rounded-2xl panel-inset p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center gap-3 border-sky-500/25 dark:border-cyan-500/30">
            <div
              className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                gridExporting
                  ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                  : gridImporting
                    ? 'bg-sky-500/15 text-sky-600 dark:text-cyan-300'
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
              }`}
            >
              <UtilityPole className="w-6 h-6" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300 flex items-center gap-1">
                <span>Utility Grid</span>
                {gridExporting && <ArrowUpRight className="w-3.5 h-3.5 text-emerald-500" aria-hidden="true" />}
                {gridImporting && <ArrowDownLeft className="w-3.5 h-3.5 text-sky-500" aria-hidden="true" />}
              </p>
              <p className="font-mono text-lg sm:text-xl font-semibold text-slate-900 dark:text-white tabular-nums leading-tight mt-0.5">
                {Math.abs(telemetry.gridKw).toFixed(2)}
                <span className="text-xs font-normal text-sky-600 dark:text-cyan-300 ml-1">kW</span>
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{gridLabel}</p>
            </div>
          </div>
        </div>

        {/* UPPER CONNECTOR TRACKS (Top Row <-> Inverter Hub) */}
        <div className="w-full h-11 sm:h-12 px-2">
          <svg
            viewBox="0 0 400 52"
            preserveAspectRatio="none"
            className="w-full h-full overflow-visible"
            aria-hidden="true"
          >
            {/* Base Track Left (Solar -> Inverter) */}
            <path
              d="M 92 0 L 92 14 Q 92 26 112 26 L 178 26 Q 192 26 192 40 L 192 52"
              fill="none"
              className="stroke-slate-300 dark:stroke-slate-700/70"
              strokeWidth="2.5"
            />
            {solarActive && (
              <path
                d="M 92 0 L 92 14 Q 92 26 112 26 L 178 26 Q 192 26 192 40 L 192 52"
                fill="none"
                stroke="#10B981"
                strokeWidth="3"
                strokeLinecap="round"
                className="animate-energy-flow"
              />
            )}

            {/* Base Track Right (Inverter <-> Grid) */}
            <path
              d="M 308 0 L 308 14 Q 308 26 288 26 L 222 26 Q 208 26 208 40 L 208 52"
              fill="none"
              className="stroke-slate-300 dark:stroke-slate-700/70"
              strokeWidth="2.5"
            />
            {gridExporting && (
              <path
                d="M 208 52 L 208 40 Q 208 26 222 26 L 288 26 Q 308 26 308 14 L 308 0"
                fill="none"
                stroke="#10B981"
                strokeWidth="3"
                strokeLinecap="round"
                className="animate-energy-flow"
              />
            )}
            {gridImporting && (
              <path
                d="M 308 0 L 308 14 Q 308 26 288 26 L 222 26 Q 208 26 208 40 L 208 52"
                fill="none"
                stroke="#0EA5E9"
                strokeWidth="3"
                strokeLinecap="round"
                className="animate-energy-flow"
              />
            )}
          </svg>
        </div>

        {/* CENTER ROW: Hybrid Inverter Hub */}
        <div className="flex justify-center">
          <div
            className={`w-full max-w-[270px] sm:max-w-[300px] rounded-2xl px-4 py-3 border flex items-center justify-between gap-3 transition-colors ${
              isOffline
                ? 'bg-rose-50 dark:bg-rose-500/10 border-rose-300 dark:border-rose-500/40'
                : inverter.status === 'warning'
                  ? 'bg-amber-50 dark:bg-amber-500/10 border-amber-300 dark:border-amber-500/40'
                  : 'bg-emerald-50/80 dark:bg-[#0D1E2E] border-emerald-300 dark:border-emerald-500/40'
            }`}
          >
            <div className="flex items-center gap-3 min-w-0">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                  isOffline
                    ? 'bg-rose-500/15 text-rose-600 dark:text-rose-400'
                    : inverter.status === 'warning'
                      ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                      : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                }`}
              >
                <Zap className="w-5 h-5" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                  AJ Hybrid Inverter
                </p>
                <p className="text-[11px] font-mono text-slate-600 dark:text-slate-300 tabular-nums">
                  {isOffline ? 'Offline' : `${inverter.efficiencyPct.toFixed(1)}% eff.`}
                </p>
              </div>
            </div>
            <div className="text-right font-mono text-[11px] text-slate-600 dark:text-slate-300 tabular-nums shrink-0">
              <p>{inverter.acVoltageV.toFixed(0)} V</p>
              <p>{inverter.acFrequencyHz.toFixed(1)} Hz</p>
            </div>
          </div>
        </div>

        {/* LOWER CONNECTOR TRACKS (Inverter Hub <-> Bottom Row) */}
        <div className="w-full h-11 sm:h-12 px-2">
          <svg
            viewBox="0 0 400 52"
            preserveAspectRatio="none"
            className="w-full h-full overflow-visible"
            aria-hidden="true"
          >
            {/* Base Track Left (Inverter <-> Battery) */}
            <path
              d="M 192 0 L 192 12 Q 192 26 178 26 L 112 26 Q 92 26 92 38 L 92 52"
              fill="none"
              className="stroke-slate-300 dark:stroke-slate-700/70"
              strokeWidth="2.5"
            />
            {batCharging && (
              <path
                d="M 192 0 L 192 12 Q 192 26 178 26 L 112 26 Q 92 26 92 38 L 92 52"
                fill="none"
                stroke="#F59E0B"
                strokeWidth="3"
                strokeLinecap="round"
                className="animate-energy-flow"
              />
            )}
            {batDischarging && (
              <path
                d="M 92 52 L 92 38 Q 92 26 112 26 L 178 26 Q 192 26 192 12 L 192 0"
                fill="none"
                stroke="#F97316"
                strokeWidth="3"
                strokeLinecap="round"
                className="animate-energy-flow"
              />
            )}

            {/* Base Track Right (Inverter -> Home Load) */}
            <path
              d="M 208 0 L 208 12 Q 208 26 222 26 L 288 26 Q 308 26 308 38 L 308 52"
              fill="none"
              className="stroke-slate-300 dark:stroke-slate-700/70"
              strokeWidth="2.5"
            />
            {loadActive && (
              <path
                d="M 208 0 L 208 12 Q 208 26 222 26 L 288 26 Q 308 26 308 38 L 308 52"
                fill="none"
                stroke="#06B6D4"
                strokeWidth="3"
                strokeLinecap="round"
                className="animate-energy-flow"
              />
            )}
          </svg>
        </div>

        {/* BOTTOM ROW: Battery Bank (Left) + Home Load (Right) */}
        <div className="grid grid-cols-2 gap-4 sm:gap-8">
          {/* Battery Node */}
          <div className="rounded-2xl panel-inset p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center gap-3 border-amber-500/25 dark:border-amber-500/30">
            <div
              className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                batCharging || batDischarging
                  ? 'bg-amber-500/15 text-amber-600 dark:text-amber-300'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
              }`}
            >
              {batCharging ? (
                <BatteryCharging className="w-6 h-6" aria-hidden="true" />
              ) : (
                <BatteryFull className="w-6 h-6" aria-hidden="true" />
              )}
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-1">
                <p className="text-xs font-medium text-slate-600 dark:text-slate-300">Battery</p>
                <span className="font-mono text-xs font-semibold text-amber-600 dark:text-amber-300 tabular-nums">
                  {battery ? `${telemetry.batterySoc}%` : '—'}
                </span>
              </div>
              <p className="font-mono text-lg sm:text-xl font-semibold text-slate-900 dark:text-white tabular-nums leading-tight mt-0.5">
                {Math.abs(telemetry.batteryKw).toFixed(2)}
                <span className="text-xs font-normal text-amber-600 dark:text-amber-300 ml-1">kW</span>
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{batteryActionLabel}</p>
            </div>
          </div>

          {/* Home Load Node */}
          <div className="rounded-2xl panel-inset p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center gap-3 border-cyan-500/25 dark:border-cyan-500/30">
            <div
              className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
                loadActive
                  ? 'bg-cyan-500/15 text-cyan-700 dark:text-cyan-300'
                  : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
              }`}
            >
              <Home className="w-6 h-6" aria-hidden="true" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-300">Home Load</p>
              <p className="font-mono text-lg sm:text-xl font-semibold text-slate-900 dark:text-white tabular-nums leading-tight mt-0.5">
                {telemetry.loadKw.toFixed(2)}
                <span className="text-xs font-normal text-cyan-600 dark:text-cyan-300 ml-1">kW</span>
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                {loadActive ? 'Consuming' : 'Standby'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Clean Legend Footer */}
      <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400">
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-0.5 bg-emerald-500 inline-block rounded-full" aria-hidden="true" />
          Solar / Export
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-0.5 bg-amber-500 inline-block rounded-full" aria-hidden="true" />
          Battery Flow
        </span>
        <span className="inline-flex items-center gap-1.5">
          <span className="w-2.5 h-0.5 bg-cyan-500 inline-block rounded-full" aria-hidden="true" />
          Grid / Home Load
        </span>
      </div>
    </section>
  );
};
