import React from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  BatteryCharging,
  BatteryFull,
  CheckCircle2,
  CloudSun,
  Headphones,
  Home,
  Info,
  MessageCircle,
  Pause,
  PhoneCall,
  Play,
  RefreshCw,
  Sun,
  Sunrise,
  Sunset,
  Thermometer,
  UtilityPole,
  Wind,
} from 'lucide-react';
import { Account, LanguageCode, SolarAlarm, SolarPlant, SupportConfig, Technician } from '../types/solar';
import { buildTelUrl, buildWhatsAppUrl, formatCurrency, formatRelativeTime, formatTimestamp } from '../utils/format';
import { getTranslations } from '../utils/i18n';
import { FallbackImage, InverterStatusText } from './BrandMark';
import { EnergyFlowDiagram } from './EnergyFlowDiagram';
import { EnergyCharts } from './EnergyCharts';

interface CustomerDashboardProps {
  account: Account;
  plants: SolarPlant[];
  selectedPlant: SolarPlant | null;
  onSelectPlant: (plantId: string) => void;
  alarms: SolarAlarm[];
  supportConfig: SupportConfig;
  assignedTechnician?: Technician;
  isLiveSim: boolean;
  onToggleLiveSim: () => void;
  onManualSync: (plantId: string) => void;
  onNavigateAlarms: () => void;
  onNavigatePlants: () => void;
  onNavigateSupport: () => void;
}

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({
  account,
  plants,
  selectedPlant,
  onSelectPlant,
  alarms,
  supportConfig,
  assignedTechnician,
  isLiveSim,
  onToggleLiveSim,
  onManualSync,
  onNavigateAlarms,
  onNavigatePlants,
  onNavigateSupport,
}) => {
  const language: LanguageCode = account.preferences.language || 'en';
  const t = getTranslations(language);
  if (!selectedPlant) {
    return (
      <div className="panel-glass rounded-2xl p-8 text-center">
        <Sun className="w-10 h-10 text-emerald-500 mx-auto mb-3" aria-hidden="true" />
        <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-white">No Solar Plant Linked</h2>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-md mx-auto">
          Your account does not have an active solar plant assigned yet. Contact {supportConfig.companyName} support to provision your inverter.
        </p>
      </div>
    );
  }

  const { telemetry, inverter, battery, weather } = selectedPlant;
  const plantAlarms = alarms.filter((a) => a.plantId === selectedPlant.id);
  const activePlantAlarms = plantAlarms.filter((a) => a.status !== 'resolved');

  const capacityPct = selectedPlant.capacityKwp > 0
    ? Math.min(100, Math.round((telemetry.solarKw / selectedPlant.capacityKwp) * 100))
    : 0;

  const dailyDiff = telemetry.dailyKwh - telemetry.yesterdayKwh;
  const dailyDiffPct = telemetry.yesterdayKwh > 0 ? Math.round((dailyDiff / telemetry.yesterdayKwh) * 100) : 0;

  const isGridExport = telemetry.gridKw < -0.02;
  const isGridImport = telemetry.gridKw > 0.02;
  const isOffline = inverter.status === 'offline';

  const radius = 78;
  const circumference = Math.PI * radius;
  const dashOffset = circumference - (capacityPct / 100) * circumference;

  const totalLoad = Math.max(0.01, telemetry.loadKw);
  const gridImportPower = isGridImport ? telemetry.gridKw : 0;
  const batDischargePower = telemetry.batteryStatus === 'discharging' ? Math.abs(telemetry.batteryKw) : 0;
  const solarToLoadPower = Math.max(0, totalLoad - gridImportPower - batDischargePower);
  const solarSharePct = isOffline ? 0 : Math.min(100, Math.round((solarToLoadPower / totalLoad) * 100));
  const batterySharePct = isOffline ? 0 : Math.min(100 - solarSharePct, Math.round((batDischargePower / totalLoad) * 100));
  const gridSharePct = isOffline ? 100 : Math.max(0, 100 - solarSharePct - batterySharePct);

  const whatsappText = `Hello ${supportConfig.companyName}, I need support for my solar plant "${selectedPlant.name}" (Inverter SN: ${inverter.serialNumber}).`;
  const whatsappUrl = buildWhatsAppUrl(supportConfig.whatsappNumber, whatsappText);
  const callUrl = buildTelUrl(supportConfig.supportPhone);

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Multi-Plant Command Strip + Weather & Inverter Comms */}
      <div className="panel-glass rounded-2xl p-3.5 sm:p-4 flex flex-col xl:flex-row xl:items-center justify-between gap-3.5">
        <div className="flex items-center gap-3.5 min-w-0">
          <div className="w-14 h-11 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700/60 shrink-0 hidden sm:block">
            <FallbackImage
              src={selectedPlant.imageUrl}
              alt={selectedPlant.name}
              className="w-full h-full object-cover"
              fallbackTitle="Site"
            />
          </div>
          <div className="min-w-0 flex-1">
            {plants.length > 1 ? (
              <div className="flex flex-wrap items-center gap-2">
                <label htmlFor="plant-select" className="sr-only">
                  Select solar plant
                </label>
                <select
                  id="plant-select"
                  value={selectedPlant.id}
                  onChange={(e) => onSelectPlant(e.target.value)}
                  className="min-h-[40px] px-3 rounded-xl bg-slate-100 dark:bg-[#09101E] border border-slate-300 dark:border-slate-700/80 text-sm font-semibold text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                >
                  {plants.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} · {p.capacityKwp} kWp
                    </option>
                  ))}
                </select>
                <InverterStatusText status={inverter.status} compact />
              </div>
            ) : (
              <div className="flex flex-wrap items-center gap-2.5">
                <h1 className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white truncate">
                  {selectedPlant.name}
                </h1>
                <InverterStatusText status={inverter.status} compact />
              </div>
            )}

            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 dark:text-slate-400 mt-1">
              <span>{selectedPlant.location}</span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1 font-mono tabular-nums text-slate-700 dark:text-slate-300">
                <Thermometer className="w-3.5 h-3.5 text-amber-500" aria-hidden="true" />
                Inverter {inverter.temperatureC.toFixed(1)}°C
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">
                Synced {formatRelativeTime(inverter.lastSyncIso)}
              </span>
            </div>
          </div>
        </div>

        {/* Weather Telemetry + Stream Controls */}
        <div className="flex flex-wrap items-center justify-between xl:justify-end gap-3 pt-2.5 xl:pt-0 border-t xl:border-t-0 border-slate-200 dark:border-slate-800/70">
          <div className="flex items-center gap-3.5 px-3 py-1.5 rounded-xl panel-inset text-xs">
            <span className="inline-flex items-center gap-1.5 text-slate-800 dark:text-slate-200 font-medium">
              <CloudSun className="w-4 h-4 text-amber-500" aria-hidden="true" />
              <span className="font-mono tabular-nums">{weather.tempC}°C</span>
              <span className="text-slate-500 dark:text-slate-400 hidden sm:inline">{weather.condition}</span>
            </span>
            <span className="font-mono tabular-nums text-emerald-700 dark:text-emerald-300 font-medium">
              {weather.irradianceWm2} W/m²
            </span>
            <span className="hidden md:inline-flex items-center gap-1 font-mono tabular-nums text-slate-500 dark:text-slate-400">
              <Wind className="w-3.5 h-3.5 text-sky-500 dark:text-cyan-400" aria-hidden="true" />
              {weather.windKmh} km/h
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={onToggleLiveSim}
              className={`min-h-[40px] px-3 rounded-xl border text-xs font-medium inline-flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                isLiveSim
                  ? 'bg-emerald-500/12 border-emerald-500/40 text-emerald-700 dark:text-emerald-300'
                  : 'bg-slate-100 dark:bg-[#09101E] border-slate-300 dark:border-slate-700/80 text-slate-700 dark:text-slate-300'
              }`}
            >
              {isLiveSim ? <Pause className="w-3.5 h-3.5" aria-hidden="true" /> : <Play className="w-3.5 h-3.5" aria-hidden="true" />}
              <span>{isLiveSim ? 'Live' : 'Paused'}</span>
            </button>
            <button
              type="button"
              onClick={() => onManualSync(selectedPlant.id)}
              aria-label="Sync inverter telemetry now"
              className="min-h-[40px] min-w-[40px] px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-[#09101E] dark:hover:bg-[#13203A] border border-slate-300 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 inline-flex items-center justify-center gap-1.5 text-xs font-medium transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" aria-hidden="true" />
              <span className="hidden sm:inline">Sync</span>
            </button>
          </div>
        </div>
      </div>

      {/* Hero Row: Live Power Generation Dial + Redesigned Energy Flow Topology */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 sm:gap-5 items-stretch">
        {/* Left: Live Power Gauge & Production Totals */}
        <section className="xl:col-span-5 panel-glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between relative overflow-hidden">
          <div className="relative z-10 flex items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white">
                {t.liveSolarOutput}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {selectedPlant.panelCount} modules · {selectedPlant.capacityKwp} kWp DC peak
              </p>
            </div>
            <button
              type="button"
              onClick={onNavigatePlants}
              className="text-xs font-medium text-emerald-700 dark:text-cyan-300 hover:underline whitespace-nowrap min-h-[36px] px-2"
            >
              Inverter Specs
            </button>
          </div>

          {/* Radial Arc Power Dial */}
          <div className="relative z-10 flex flex-col items-center justify-center my-4">
            <div className="relative w-56 h-32 flex items-end justify-center">
              <svg viewBox="0 0 200 112" className="w-full h-full overflow-visible" aria-hidden="true">
                <defs>
                  <linearGradient id="liveArcGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#10B981" />
                    <stop offset="65%" stopColor="#14B8A6" />
                    <stop offset="100%" stopColor="#06B6D4" />
                  </linearGradient>
                </defs>
                <path
                  d="M 22 100 A 78 78 0 0 1 178 100"
                  fill="none"
                  className="stroke-slate-200 dark:stroke-[#16243E]"
                  strokeWidth="12"
                  strokeLinecap="round"
                />
                <path
                  d="M 22 100 A 78 78 0 0 1 178 100"
                  fill="none"
                  stroke={isOffline ? '#F43F5E' : 'url(#liveArcGrad)'}
                  strokeWidth="12"
                  strokeLinecap="round"
                  strokeDasharray={circumference}
                  strokeDashoffset={isOffline ? circumference : dashOffset}
                  className="transition-all duration-500"
                />
              </svg>

              <div className="absolute bottom-1 text-center">
                <p className="font-mono text-3xl sm:text-4xl font-semibold text-slate-900 dark:text-white tabular-nums tracking-tight leading-none">
                  {telemetry.solarKw.toFixed(2)}
                  <span className="text-sm font-normal text-emerald-600 dark:text-emerald-400 ml-1">kW</span>
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-1.5">
                  {isOffline ? 'Inverter Offline' : `${capacityPct}% of ${selectedPlant.capacityKwp} kWp`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 mt-3 text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
              <span className="inline-flex items-center gap-1">
                <Sunrise className="w-3.5 h-3.5 text-amber-500" aria-hidden="true" />
                {weather.sunrise}
              </span>
              <span aria-hidden="true">·</span>
              <span>UV {weather.uvIndex}</span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1">
                <Sunset className="w-3.5 h-3.5 text-orange-500" aria-hidden="true" />
                {weather.sunset}
              </span>
            </div>
          </div>

          {/* 4-Cell Generation & Financial Matrix */}
          <div className="relative z-10 grid grid-cols-2 gap-2.5 pt-3 border-t border-slate-200 dark:border-slate-800/80">
            <div className="rounded-xl panel-inset p-3">
              <p className="text-[11px] text-slate-500 dark:text-slate-400">{t.todaysGeneration}</p>
              <p className="font-mono text-base sm:text-lg font-semibold text-slate-900 dark:text-white tabular-nums mt-0.5">
                {telemetry.dailyKwh.toFixed(1)} <span className="text-xs font-normal text-slate-500 dark:text-slate-400">kWh</span>
              </p>
              <p className={`text-[11px] font-mono tabular-nums mt-0.5 ${dailyDiff >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}`}>
                {dailyDiff >= 0 ? `+${dailyDiffPct}%` : `${dailyDiffPct}%`} vs yesterday
              </p>
            </div>

            <div className="rounded-xl panel-inset p-3">
              <p className="text-[11px] text-slate-500 dark:text-slate-400">{t.estimatedSavings}</p>
              <p className="font-mono text-base sm:text-lg font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums mt-0.5">
                {formatCurrency(telemetry.dailyKwh * account.preferences.tariffPerKwh, account.preferences.currency)}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 font-mono tabular-nums">
                Today @ {account.preferences.tariffPerKwh}/kWh
              </p>
            </div>

            <div className="rounded-xl panel-inset p-3">
              <p className="text-[11px] text-slate-500 dark:text-slate-400">{t.monthlyGeneration}</p>
              <p className="font-mono text-base sm:text-lg font-semibold text-slate-900 dark:text-white tabular-nums mt-0.5">
                {telemetry.monthlyKwh.toLocaleString()} <span className="text-xs font-normal text-slate-500 dark:text-slate-400">kWh</span>
              </p>
              <p className="text-[11px] text-sky-700 dark:text-cyan-300 mt-0.5 font-mono tabular-nums">
                {formatCurrency(telemetry.monthlyKwh * account.preferences.tariffPerKwh, account.preferences.currency)} value
              </p>
            </div>

            <div className="rounded-xl panel-inset p-3">
              <p className="text-[11px] text-slate-500 dark:text-slate-400">{t.lifetimeTotal}</p>
              <p className="font-mono text-base sm:text-lg font-semibold text-slate-900 dark:text-white tabular-nums mt-0.5">
                {telemetry.lifetimeMwh.toFixed(1)} <span className="text-xs font-normal text-slate-500 dark:text-slate-400">MWh</span>
              </p>
              <p className="text-[11px] text-emerald-700 dark:text-emerald-400 mt-0.5 font-mono tabular-nums">
                {(telemetry.co2SavedKg / 1000).toFixed(1)}t CO₂ offset
              </p>
            </div>
          </div>
        </section>

        {/* Right: Redesigned Non-Overlapping Energy Flow Topology */}
        <div className="xl:col-span-7">
          <EnergyFlowDiagram plant={selectedPlant} />
        </div>
      </div>

      {/* Smooth Solar Generation & Consumption Charts */}
      <EnergyCharts
        plant={selectedPlant}
        currency={account.preferences.currency}
        tariffPerKwh={account.preferences.tariffPerKwh}
        language={language}
      />

      {/* Battery & Home Load Breakdown + Recent Alerts & Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-5 items-stretch">
        <section className="lg:col-span-6 panel-glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-4">
              <h2 className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white">
                Storage & Load Balance
              </h2>
              <span className="text-xs font-mono text-slate-500 dark:text-slate-400 tabular-nums">
                Reserve {account.preferences.batteryReservePct}%
              </span>
            </div>

            <div className="rounded-xl panel-inset p-3.5 mb-4">
              <div className="flex items-center justify-between gap-2 mb-2.5">
                <div className="flex items-center gap-2.5">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                    telemetry.batteryStatus === 'charging'
                      ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                      : telemetry.batteryStatus === 'discharging'
                        ? 'bg-amber-500/15 text-amber-600 dark:text-amber-300'
                        : 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                  }`}>
                    {telemetry.batteryStatus === 'charging' ? (
                      <BatteryCharging className="w-5 h-5" aria-hidden="true" />
                    ) : (
                      <BatteryFull className="w-5 h-5" aria-hidden="true" />
                    )}
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-slate-900 dark:text-white">
                      {battery ? battery.model : 'Grid-Tie Configuration'}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 capitalize">
                      {battery
                        ? `${telemetry.batteryStatus} · ${Math.abs(telemetry.batteryKw).toFixed(2)} kW · ${battery.capacityKwh} kWh`
                        : 'No battery bank installed'}
                    </p>
                  </div>
                </div>
                <span className="font-mono text-xl font-semibold text-slate-900 dark:text-white tabular-nums">
                  {battery ? `${telemetry.batterySoc}%` : '—'}
                </span>
              </div>

              {battery && (
                <div className="grid grid-cols-10 gap-1.5 mt-2" aria-hidden="true">
                  {Array.from({ length: 10 }).map((_, idx) => {
                    const threshold = (idx + 1) * 10;
                    const filled = telemetry.batterySoc >= threshold - 4;
                    const barColor = !filled
                      ? 'bg-slate-200 dark:bg-slate-800/90'
                      : telemetry.batterySoc <= 20
                        ? 'bg-rose-500'
                        : telemetry.batteryStatus === 'discharging'
                          ? 'bg-amber-500'
                          : 'bg-emerald-500';
                    return <div key={idx} className={`h-2.5 rounded-sm transition-colors ${barColor}`} />;
                  })}
                </div>
              )}
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="inline-flex items-center gap-1.5 font-medium text-slate-700 dark:text-slate-200">
                  <Home className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-300" aria-hidden="true" />
                  Home Consumption Mix ({telemetry.loadKw.toFixed(2)} kW)
                </span>
                <span className="inline-flex items-center gap-1.5 font-mono text-slate-700 dark:text-slate-300 tabular-nums">
                  <UtilityPole className="w-3.5 h-3.5 text-sky-500 dark:text-cyan-400" aria-hidden="true" />
                  {isGridExport ? (
                    <span className="text-emerald-600 dark:text-emerald-400 inline-flex items-center gap-0.5">
                      <ArrowUpRight className="w-3.5 h-3.5" />
                      Export {Math.abs(telemetry.gridKw).toFixed(2)} kW
                    </span>
                  ) : isGridImport ? (
                    <span className="text-sky-700 dark:text-cyan-300 inline-flex items-center gap-0.5">
                      <ArrowDownLeft className="w-3.5 h-3.5" />
                      Import {telemetry.gridKw.toFixed(2)} kW
                    </span>
                  ) : (
                    <span>Grid Balanced</span>
                  )}
                </span>
              </div>

              <div className="h-3 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden flex">
                {solarSharePct > 0 && (
                  <div className="bg-emerald-500 h-full" style={{ width: `${solarSharePct}%` }} />
                )}
                {batterySharePct > 0 && (
                  <div className="bg-amber-500 h-full" style={{ width: `${batterySharePct}%` }} />
                )}
                {gridSharePct > 0 && (
                  <div className="bg-cyan-500 h-full" style={{ width: `${gridSharePct}%` }} />
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 mt-2 text-[11px] font-mono tabular-nums">
                <span className="text-emerald-700 dark:text-emerald-400">Solar {solarSharePct}%</span>
                <span className="text-amber-700 dark:text-amber-300">Battery {batterySharePct}%</span>
                <span className="text-sky-700 dark:text-cyan-300">Utility Grid {gridSharePct}%</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Inverter: <span className="text-slate-800 dark:text-slate-200">{inverter.model}</span></span>
            <span className="font-mono tabular-nums">PF {inverter.powerFactor.toFixed(2)}</span>
          </div>
        </section>

        <section className="lg:col-span-6 panel-glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between gap-2 mb-3">
              <div>
                <h2 className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white">
                  Recent Alerts & Activity
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {activePlantAlarms.length === 0
                    ? 'No unresolved alerts on this system'
                    : `${activePlantAlarms.length} active alert${activePlantAlarms.length === 1 ? '' : 's'} requiring review`}
                </p>
              </div>
              <button
                type="button"
                onClick={onNavigateAlarms}
                className="text-xs font-medium text-emerald-700 dark:text-cyan-300 hover:underline whitespace-nowrap min-h-[36px] px-2"
              >
                All Alerts
              </button>
            </div>

            {plantAlarms.length === 0 ? (
              <div className="rounded-xl panel-inset p-6 text-center my-4">
                <CheckCircle2 className="w-7 h-7 text-emerald-500 mx-auto mb-2" aria-hidden="true" />
                <p className="text-sm font-medium text-slate-900 dark:text-white">All Systems Nominal</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  No inverter warnings or grid faults logged for {selectedPlant.name}.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-slate-200 dark:divide-slate-800/70">
                {plantAlarms.slice(0, 3).map((alarm) => {
                  const Icon =
                    alarm.severity === 'critical'
                      ? AlertOctagon
                      : alarm.severity === 'warning'
                        ? AlertTriangle
                        : Info;
                  const iconColor =
                    alarm.severity === 'critical'
                      ? 'text-rose-600 dark:text-rose-400 bg-rose-500/15'
                      : alarm.severity === 'warning'
                        ? 'text-amber-600 dark:text-amber-400 bg-amber-500/15'
                        : 'text-sky-600 dark:text-cyan-300 bg-cyan-500/15';

                  return (
                    <button
                      key={alarm.id}
                      type="button"
                      onClick={onNavigateAlarms}
                      className="w-full text-left py-3 first:pt-1 last:pb-1 flex items-start gap-3 hover:bg-slate-100/70 dark:hover:bg-slate-800/20 rounded-lg px-1.5 -mx-1.5 transition-colors"
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${iconColor}`}>
                        <Icon className="w-4 h-4" aria-hidden="true" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">{alarm.title}</p>
                          <span
                            className={`text-[11px] font-medium capitalize shrink-0 ${
                              alarm.status === 'resolved'
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : 'text-amber-600 dark:text-amber-300'
                            }`}
                          >
                            {alarm.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-1 mt-0.5">{alarm.message}</p>
                        <p className="text-[11px] font-mono text-slate-500 tabular-nums mt-0.5">
                          {alarm.code} · {formatTimestamp(alarm.timestampIso)}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Firmware: <span className="font-mono text-slate-800 dark:text-slate-200">{inverter.firmwareVersion}</span></span>
            <span>SN: <span className="font-mono text-slate-800 dark:text-slate-200">{inverter.serialNumber}</span></span>
          </div>
        </section>
      </div>

      {/* AJ Solutions Direct WhatsApp, Call & Customer Support Card */}
      <section
        aria-label="AJ Solutions customer support"
        className="panel-glass rounded-2xl p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
      >
        <div className="flex items-start sm:items-center gap-3.5 min-w-0">
          <div className="w-11 h-11 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <Headphones className="w-5 h-5" aria-hidden="true" />
          </div>
          <div className="min-w-0">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              {t.supportDeskTitle}
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
              {supportConfig.supportHours}
              {assignedTechnician ? ` · Site Engineer: ${assignedTechnician.name}` : ''}
              {' · '}Demo contact channels (configurable in Admin Settings)
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="min-h-[44px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <MessageCircle className="w-4 h-4" aria-hidden="true" />
            <span>{t.whatsappChat}</span>
          </a>

          <a
            href={callUrl}
            className="min-h-[44px] px-4 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <PhoneCall className="w-4 h-4" aria-hidden="true" />
            <span>{t.callNow}</span>
          </a>

          <button
            type="button"
            onClick={onNavigateSupport}
            className="min-h-[44px] px-4 rounded-xl panel-inset hover:bg-slate-200/80 dark:hover:bg-slate-800/80 text-xs font-medium text-slate-800 dark:text-slate-200 inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
          >
            <span>{t.submitInquiry}</span>
          </button>
        </div>
      </section>
    </div>
  );
};
