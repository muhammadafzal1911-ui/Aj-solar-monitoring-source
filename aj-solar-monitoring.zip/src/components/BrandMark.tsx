import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, WifiOff } from 'lucide-react';
import { InverterStatus } from '../types/solar';

export const BrandMark: React.FC<{ size?: number }> = ({ size = 34 }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 38 38"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
    className="shrink-0"
  >
    <defs>
      <linearGradient id="ajLogoBg" x1="0" y1="0" x2="38" y2="38" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#0E223D" />
        <stop offset="100%" stopColor="#091923" />
      </linearGradient>
      <linearGradient id="ajSunGrad" x1="12" y1="8" x2="26" y2="22" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#34D399" />
        <stop offset="100%" stopColor="#06B6D4" />
      </linearGradient>
    </defs>
    <rect width="38" height="38" rx="10" fill="url(#ajLogoBg)" stroke="#22D3EE" strokeOpacity="0.35" strokeWidth="1.2" />
    <circle cx="19" cy="14.5" r="4.8" fill="url(#ajSunGrad)" />
    <path
      d="M19 6V7.8M19 21.2V23M10.5 14.5H12.3M25.7 14.5H27.5M12.9 8.4L14.2 9.7M23.8 19.3L25.1 20.6M25.1 8.4L23.8 9.7M14.2 19.3L12.9 20.6"
      stroke="#34D399"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path
      d="M8.5 29.5L13.5 23.8H24.5L29.5 29.5H8.5Z"
      fill="#10B981"
      fillOpacity="0.18"
      stroke="#22D3EE"
      strokeWidth="1.35"
      strokeLinejoin="round"
    />
    <path d="M16 23.8L14.2 29.5M22 23.8L23.8 29.5M11.3 26.6H26.7" stroke="#34D399" strokeOpacity="0.7" strokeWidth="1.1" />
  </svg>
);

interface FallbackImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackTitle?: string;
}

export const FallbackImage: React.FC<FallbackImageProps> = ({
  src,
  alt,
  className = '',
  fallbackTitle = 'AJ Solar System',
}) => {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-slate-100 via-emerald-50 to-sky-50 dark:from-[#0D192E] dark:via-[#091224] dark:to-[#0A1D24] text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800/80 ${className}`}
        role="img"
        aria-label={alt}
      >
        <BrandMark size={40} />
        <span className="mt-2 text-xs font-medium text-slate-500 dark:text-slate-400 px-3 text-center">{fallbackTitle}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
};

export const InverterStatusText: React.FC<{ status: InverterStatus; compact?: boolean }> = ({
  status,
  compact = false,
}) => {
  if (status === 'online') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400 whitespace-nowrap shrink-0">
        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
        <span>{compact ? 'Online' : 'Inverter Online'}</span>
      </span>
    );
  }
  if (status === 'warning') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 dark:text-amber-400 whitespace-nowrap shrink-0">
        <AlertTriangle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
        <span>{compact ? 'Warning' : 'Grid Warning'}</span>
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-rose-700 dark:text-rose-400 whitespace-nowrap shrink-0">
      <WifiOff className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
      <span>{compact ? 'Offline' : 'Inverter Offline'}</span>
    </span>
  );
};
