import React, { useState } from 'react';
import {
  Bell,
  Building2,
  Check,
  Download,
  Globe,
  Headphones,
  LogOut,
  Mail,
  MessageCircle,
  Moon,
  PhoneCall,
  RotateCcw,
  Save,
  Send,
  Shield,
  Sun,
  User,
  Wrench,
} from 'lucide-react';
import {
  Account,
  CurrencyCode,
  LanguageCode,
  SolarPlant,
  SupportConfig,
  SupportInquiry,
  Technician,
  ThemeMode,
  UserPreferences,
} from '../types/solar';
import { buildTelUrl, buildWhatsAppUrl, exportPlantCsv, formatTimestamp } from '../utils/format';
import { getTranslations } from '../utils/i18n';

interface ProfileSettingsViewProps {
  account: Account;
  selectedPlant: SolarPlant | null;
  theme: ThemeMode;
  onChangeTheme: (mode: ThemeMode) => void;
  supportConfig: SupportConfig;
  onUpdateSupportConfig?: (config: SupportConfig) => void;
  assignedTechnician?: Technician;
  inquiries: SupportInquiry[];
  onSubmitInquiry: (payload: {
    category: SupportInquiry['category'];
    target: SupportInquiry['target'];
    message: string;
  }) => void;
  onUpdateAccount: (updated: Account) => void;
  onLogout: () => void;
  onResetDemoData: () => void;
}

export const ProfileSettingsView: React.FC<ProfileSettingsViewProps> = ({
  account,
  selectedPlant,
  theme,
  onChangeTheme,
  supportConfig,
  onUpdateSupportConfig,
  assignedTechnician,
  inquiries,
  onSubmitInquiry,
  onUpdateAccount,
  onLogout,
  onResetDemoData,
}) => {
  const [name, setName] = useState(account.name);
  const [phone, setPhone] = useState(account.phone);
  const [address, setAddress] = useState(account.address);
  const [prefs, setPrefs] = useState<UserPreferences>(account.preferences);
  const [savedNotice, setSavedNotice] = useState(false);

  const currentLang: LanguageCode = prefs.language || account.preferences.language || 'en';
  const t = getTranslations(currentLang);

  const handleLanguageChange = (nextLang: LanguageCode) => {
    const nextPrefs = { ...prefs, language: nextLang };
    setPrefs(nextPrefs);
    onUpdateAccount({
      ...account,
      preferences: nextPrefs,
    });
  };

  // Support Inquiry state
  const [inqCategory, setInqCategory] = useState<SupportInquiry['category']>('Technical Fault');
  const [inqTarget, setInqTarget] = useState<SupportInquiry['target']>('AJ Solutions Admin');
  const [inqMessage, setInqMessage] = useState('');
  const [inqSent, setInqSent] = useState(false);

  // Admin Support Config editable fields
  const [cfgWhatsapp, setCfgWhatsapp] = useState(supportConfig.whatsappNumber);
  const [cfgPhone, setCfgPhone] = useState(supportConfig.supportPhone);
  const [cfgEmail, setCfgEmail] = useState(supportConfig.supportEmail);
  const [cfgHours, setCfgHours] = useState(supportConfig.supportHours);
  const [cfgSaved, setCfgSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateAccount({
      ...account,
      name: name.trim() || account.name,
      phone: phone.trim() || account.phone,
      address: address.trim() || account.address,
      preferences: prefs,
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2500);
  };

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inqMessage.trim()) return;
    onSubmitInquiry({
      category: inqCategory,
      target: inqTarget,
      message: inqMessage.trim(),
    });
    setInqMessage('');
    setInqSent(true);
    setTimeout(() => setInqSent(false), 3000);
  };

  const handleSaveSupportConfig = (e: React.FormEvent) => {
    e.preventDefault();
    if (!onUpdateSupportConfig) return;
    onUpdateSupportConfig({
      ...supportConfig,
      whatsappNumber: cfgWhatsapp.trim() || supportConfig.whatsappNumber,
      supportPhone: cfgPhone.trim() || supportConfig.supportPhone,
      supportEmail: cfgEmail.trim() || supportConfig.supportEmail,
      supportHours: cfgHours.trim() || supportConfig.supportHours,
    });
    setCfgSaved(true);
    setTimeout(() => setCfgSaved(false), 2500);
  };

  const whatsappText = selectedPlant
    ? `Hello ${supportConfig.companyName}, this is ${account.name}. Need assistance with plant "${selectedPlant.name}" (SN: ${selectedPlant.inverter.serialNumber}).`
    : `Hello ${supportConfig.companyName}, this is ${account.name}. I have a solar monitoring inquiry.`;

  return (
    <div className="space-y-4 sm:space-y-5 max-w-4xl">
      {/* Account Summary Header */}
      <section className="panel-glass rounded-2xl p-4 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            {account.role === 'admin' ? <Shield className="w-7 h-7" /> : <User className="w-7 h-7" />}
          </div>
          <div>
            <h1 className="font-display text-lg sm:text-xl font-semibold text-slate-900 dark:text-white">
              {account.name}
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {account.email} ·{' '}
              <span className="capitalize text-emerald-700 dark:text-emerald-400 font-medium">
                {account.role} Account
              </span>
            </p>
            <p className="text-xs text-slate-500 mt-0.5 font-mono">
              ID: {account.id} · {account.city}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {selectedPlant && (
            <button
              type="button"
              onClick={() => exportPlantCsv(selectedPlant, prefs.currency, prefs.tariffPerKwh)}
              className="min-h-[44px] px-4 rounded-xl panel-inset hover:bg-slate-200 dark:hover:bg-[#152847] text-xs font-medium text-slate-800 dark:text-white inline-flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <Download className="w-4 h-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
              <span>Export CSV Report</span>
            </button>
          )}
          <button
            type="button"
            onClick={onLogout}
            className="min-h-[44px] px-4 rounded-xl bg-rose-500/12 hover:bg-rose-500/20 border border-rose-500/35 text-xs font-medium text-rose-700 dark:text-rose-300 inline-flex items-center gap-2 transition-colors whitespace-nowrap"
          >
            <LogOut className="w-4 h-4" aria-hidden="true" />
            <span>{t.signOut}</span>
          </button>
        </div>
      </section>

      {/* Appearance & Language Settings */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <section className="panel-glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between gap-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              {t.themeLabel}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Switch between Light Mode and Dark Mode. Saved automatically.
            </p>
          </div>

          <div className="inline-grid grid-cols-2 p-1 rounded-xl panel-inset self-start">
            <button
              type="button"
              onClick={() => onChangeTheme('light')}
              className={`min-h-[42px] px-4 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                theme === 'light'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Sun className="w-4 h-4" aria-hidden="true" />
              <span>{t.lightMode}</span>
            </button>
            <button
              type="button"
              onClick={() => onChangeTheme('dark')}
              className={`min-h-[42px] px-4 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                theme === 'dark'
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Moon className="w-4 h-4" aria-hidden="true" />
              <span>{t.darkMode}</span>
            </button>
          </div>
        </section>

        <section className="panel-glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between gap-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
              <span>{t.languageLabel}</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Choose interface language (English or اردو Urdu).
            </p>
          </div>

          <div className="inline-grid grid-cols-2 p-1 rounded-xl panel-inset self-start">
            <button
              type="button"
              onClick={() => handleLanguageChange('en')}
              className={`min-h-[42px] px-4 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                currentLang === 'en'
                  ? 'bg-emerald-600 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>English</span>
            </button>
            <button
              type="button"
              onClick={() => handleLanguageChange('ur')}
              className={`min-h-[42px] px-4 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                currentLang === 'ur'
                  ? 'bg-emerald-600 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>اردو (Urdu)</span>
            </button>
          </div>
        </section>
      </div>

      {/* Contact Us & Customer Support (AJ Solutions) */}
      <section id="support-section" className="panel-glass rounded-2xl p-4 sm:p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Headphones className="w-5 h-5" aria-hidden="true" />
            </div>
            <div>
              <h2 className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white">
                Contact {supportConfig.companyName} & Support
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {supportConfig.supportHours} · {supportConfig.supportEmail}
              </p>
            </div>
          </div>
          <span className="text-[11px] text-slate-500 dark:text-slate-400">
            Demo numbers · Editable in Admin Settings
          </span>
        </div>

        {/* Direct Contact Buttons Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="rounded-xl panel-inset p-4 flex flex-col justify-between gap-3">
            <div>
              <p className="text-xs font-semibold text-slate-900 dark:text-white">
                {supportConfig.companyName} Official Desk
              </p>
              <p className="text-xs font-mono text-slate-600 dark:text-slate-300 mt-1">
                WhatsApp: {supportConfig.whatsappNumber}
              </p>
              <p className="text-xs font-mono text-slate-600 dark:text-slate-300">
                Helpline: {supportConfig.supportPhone}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <a
                href={buildWhatsAppUrl(supportConfig.whatsappNumber, whatsappText)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
              >
                <MessageCircle className="w-4 h-4" aria-hidden="true" />
                <span>WhatsApp Chat</span>
              </a>
              <a
                href={buildTelUrl(supportConfig.supportPhone)}
                className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
              >
                <PhoneCall className="w-4 h-4" aria-hidden="true" />
                <span>Call Now</span>
              </a>
            </div>
          </div>

          <div className="rounded-xl panel-inset p-4 flex flex-col justify-between gap-3">
            {assignedTechnician ? (
              <>
                <div>
                  <p className="text-xs font-semibold text-slate-900 dark:text-white inline-flex items-center gap-1.5">
                    <Wrench className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-300" aria-hidden="true" />
                    Assigned Engineer · {assignedTechnician.name}
                  </p>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                    {assignedTechnician.roleTitle} · {assignedTechnician.region}
                  </p>
                  <p className="text-xs font-mono text-slate-600 dark:text-slate-300 mt-0.5">
                    {assignedTechnician.phone}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <a
                    href={buildWhatsAppUrl(
                      assignedTechnician.phone,
                      `Hello ${assignedTechnician.name}, I need technical assistance with my solar plant.`
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-emerald-600/15 hover:bg-emerald-600/25 border border-emerald-500/35 text-emerald-700 dark:text-emerald-300 text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
                  >
                    <MessageCircle className="w-4 h-4" aria-hidden="true" />
                    <span>WhatsApp Tech</span>
                  </a>
                  <a
                    href={buildTelUrl(assignedTechnician.phone)}
                    className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-sky-600/15 hover:bg-sky-600/25 border border-sky-500/35 text-sky-700 dark:text-cyan-300 text-xs font-semibold inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap"
                  >
                    <PhoneCall className="w-4 h-4" aria-hidden="true" />
                    <span>Call Tech</span>
                  </a>
                </div>
              </>
            ) : (
              <div className="flex flex-col justify-between h-full">
                <div>
                  <p className="text-xs font-semibold text-slate-900 dark:text-white">Email Support</p>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                    Send net-metering documents, warranty claims, or fleet inquiries directly to our engineering desk.
                  </p>
                </div>
                <a
                  href={`mailto:${supportConfig.supportEmail}`}
                  className="min-h-[44px] px-4 rounded-xl panel-glass text-xs font-semibold text-slate-800 dark:text-white inline-flex items-center justify-center gap-2 mt-3"
                >
                  <Mail className="w-4 h-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                  <span>Email {supportConfig.supportEmail}</span>
                </a>
              </div>
            )}
          </div>
        </div>

        {/* Customer Inquiry Ticket Form */}
        <form onSubmit={handleInquirySubmit} className="pt-3 border-t border-slate-200 dark:border-slate-800/80 space-y-3">
          <h3 className="text-xs font-semibold text-slate-800 dark:text-slate-200">
            Send Support or Maintenance Inquiry
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="inq-target" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Route To
              </label>
              <select
                id="inq-target"
                value={inqTarget}
                onChange={(e) => setInqTarget(e.target.value as SupportInquiry['target'])}
                className="w-full min-h-[42px] px-3 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="AJ Solutions Admin">AJ Solutions Administrator</option>
                <option value="Assigned Technician">Assigned Field Technician</option>
              </select>
            </div>
            <div>
              <label htmlFor="inq-cat" className="block text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-1">
                Topic
              </label>
              <select
                id="inq-cat"
                value={inqCategory}
                onChange={(e) => setInqCategory(e.target.value as SupportInquiry['category'])}
                className="w-full min-h-[42px] px-3 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="Technical Fault">Technical Fault / Inverter Alert</option>
                <option value="Battery & Backup">Battery & Backup Optimization</option>
                <option value="Net Metering">Grid Export & Net Metering</option>
                <option value="General Inquiry">General System Inquiry</option>
              </select>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5">
            <input
              type="text"
              value={inqMessage}
              onChange={(e) => setInqMessage(e.target.value)}
              placeholder="Describe your question, fault code, or service request..."
              aria-label="Inquiry message"
              className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
            />
            <button
              type="submit"
              className="min-h-[44px] px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs inline-flex items-center justify-center gap-2 whitespace-nowrap"
            >
              {inqSent ? (
                <>
                  <Check className="w-4 h-4" aria-hidden="true" />
                  <span>Inquiry Logged</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Send Inquiry</span>
                </>
              )}
            </button>
          </div>

          {inquiries.length > 0 && (
            <div className="pt-2 space-y-2">
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                Recent Support Inquiries ({inquiries.length})
              </p>
              {inquiries.slice(0, 3).map((item) => (
                <div key={item.id} className="rounded-xl panel-inset px-3 py-2 text-xs flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-medium text-slate-900 dark:text-white truncate">
                      {item.category} · <span className="font-normal text-slate-500 dark:text-slate-400">{item.target}</span>
                    </p>
                    <p className="text-slate-600 dark:text-slate-400 truncate">{item.message}</p>
                  </div>
                  <span className="font-mono text-[11px] text-emerald-700 dark:text-emerald-400 shrink-0">
                    {formatTimestamp(item.createdAtIso)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </form>
      </section>

      {/* Admin-Only Configurable AJ Solutions Contact Settings */}
      {account.role === 'admin' && onUpdateSupportConfig && (
        <form onSubmit={handleSaveSupportConfig} className="panel-glass rounded-2xl p-4 sm:p-6 space-y-4">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Admin Contact Configuration (AJ Solutions)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Update the WhatsApp and Helpline numbers shown to all customers across the app.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                WhatsApp Number (with country code)
              </label>
              <input
                type="text"
                value={cfgWhatsapp}
                onChange={(e) => setCfgWhatsapp(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm font-mono text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Support Phone (Call Now Dialer)
              </label>
              <input
                type="text"
                value={cfgPhone}
                onChange={(e) => setCfgPhone(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm font-mono text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Support Email
              </label>
              <input
                type="email"
                value={cfgEmail}
                onChange={(e) => setCfgEmail(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Support Hours
              </label>
              <input
                type="text"
                value={cfgHours}
                onChange={(e) => setCfgHours(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="min-h-[44px] px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs inline-flex items-center gap-2"
            >
              {cfgSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
              <span>{cfgSaved ? 'Contact Info Updated' : 'Update Contact Details'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Account Profile & Inverter Preferences Form */}
      <form onSubmit={handleSave} className="space-y-4 sm:space-y-5">
        <section className="panel-glass rounded-2xl p-4 sm:p-6 space-y-4">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">Account Information</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="prof-name" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Full Name
              </label>
              <input
                id="prof-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
            <div>
              <label htmlFor="prof-phone" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Phone Number
              </label>
              <input
                id="prof-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div>
            <label htmlFor="prof-addr" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
              Installation Address
            </label>
            <input
              id="prof-addr"
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
        </section>

        <section className="panel-glass rounded-2xl p-4 sm:p-6 space-y-4">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">Tariff & Inverter Preferences</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label htmlFor="pref-currency" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Billing Currency
              </label>
              <select
                id="pref-currency"
                value={prefs.currency}
                onChange={(e) => setPrefs({ ...prefs, currency: e.target.value as CurrencyCode })}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="PKR">PKR (Rs)</option>
                <option value="USD">USD ($)</option>
                <option value="AED">AED</option>
                <option value="EUR">EUR (€)</option>
              </select>
            </div>

            <div>
              <label htmlFor="pref-tariff" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Electricity Rate ({prefs.currency}/kWh)
              </label>
              <input
                id="pref-tariff"
                type="number"
                step="0.5"
                min={0}
                value={prefs.tariffPerKwh}
                onChange={(e) => setPrefs({ ...prefs, tariffPerKwh: Number(e.target.value) || 0 })}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm font-mono tabular-nums text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label htmlFor="pref-refresh" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                Live Telemetry Interval
              </label>
              <select
                id="pref-refresh"
                value={prefs.autoRefreshSec}
                onChange={(e) => setPrefs({ ...prefs, autoRefreshSec: Number(e.target.value) })}
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
              >
                <option value={3}>Every 3 seconds</option>
                <option value={5}>Every 5 seconds</option>
                <option value={10}>Every 10 seconds</option>
              </select>
            </div>
          </div>

          <div className="pt-2">
            <div className="flex items-center justify-between text-xs mb-2">
              <label htmlFor="pref-reserve" className="font-medium text-slate-700 dark:text-slate-300">
                Battery Backup Reserve Floor
              </label>
              <span className="font-mono text-amber-600 dark:text-amber-300 font-semibold tabular-nums">
                {prefs.batteryReservePct}%
              </span>
            </div>
            <input
              id="pref-reserve"
              type="range"
              min={10}
              max={50}
              step={5}
              value={prefs.batteryReservePct}
              onChange={(e) => setPrefs({ ...prefs, batteryReservePct: Number(e.target.value) })}
              className="w-full accent-emerald-600 dark:accent-emerald-400 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Hybrid inverter preserves at least {prefs.batteryReservePct}% battery capacity for grid outages.
            </p>
          </div>
        </section>

        <section className="panel-glass rounded-2xl p-4 sm:p-6 space-y-3">
          <div className="flex items-center gap-2 mb-1">
            <Bell className="w-4 h-4 text-sky-600 dark:text-cyan-300" aria-hidden="true" />
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              {t.notificationPreferences}
            </h2>
          </div>

          {[
            {
              key: 'pushAlerts' as const,
              title: 'Mobile Push Notifications',
              desc: 'Instant alerts for inverter offline status or grid voltage faults',
            },
            {
              key: 'smsAlerts' as const,
              title: 'SMS Critical Escalation',
              desc: 'Send SMS to registered phone if inverter stays offline for 30+ minutes',
            },
            {
              key: 'dailyDigest' as const,
              title: 'Daily Yield Summary',
              desc: 'Evening report of total kWh generated and net savings',
            },
          ].map((item) => {
            const enabled = prefs[item.key];
            return (
              <div
                key={item.key}
                className="flex items-center justify-between gap-4 py-2.5 border-b last:border-b-0 border-slate-200 dark:border-slate-800/70"
              >
                <div>
                  <p className="text-sm font-medium text-slate-900 dark:text-white">{item.title}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{item.desc}</p>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={enabled}
                  onClick={() => setPrefs({ ...prefs, [item.key]: !enabled })}
                  className={`relative w-12 h-7 rounded-full transition-colors shrink-0 ${
                    enabled ? 'bg-emerald-500' : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                >
                  <span
                    className={`block w-5 h-5 rounded-full bg-white transition-transform ${
                      enabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            );
          })}
        </section>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
          <button
            type="button"
            onClick={onResetDemoData}
            className="min-h-[44px] px-4 rounded-xl panel-glass hover:bg-slate-100 dark:hover:bg-[#101C33] text-xs font-medium text-slate-600 dark:text-slate-300 inline-flex items-center justify-center gap-2 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Reset Demo Data</span>
          </button>

          <button
            type="submit"
            className="min-h-[48px] px-6 rounded-xl bg-emerald-600 hover:bg-emerald-500 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold text-sm inline-flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-500/15"
          >
            {savedNotice ? (
              <>
                <Check className="w-4 h-4" aria-hidden="true" />
                <span>Preferences Saved</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" aria-hidden="true" />
                <span>{t.saveSettings}</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* About AJ Solutions */}
      <section className="panel-glass rounded-2xl p-4 sm:p-6 space-y-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
            <Building2 className="w-4 h-4" aria-hidden="true" />
          </div>
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              {t.aboutAjTitle}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Residential Hybrid, Commercial Solar & Net-Metering Engineering
            </p>
          </div>
        </div>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          AJ Solutions designs, installs, and maintains Tier-1 solar PV arrays, lithium battery energy storage systems (BESS), and smart hybrid inverters across Lahore, Karachi, Islamabad, and Faisalabad.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1 text-xs">
          <div className="rounded-xl panel-inset p-3">
            <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Head Office</span>
            <span className="font-medium text-slate-900 dark:text-white">Gulberg III, Lahore</span>
          </div>
          <div className="rounded-xl panel-inset p-3">
            <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Service Desk</span>
            <span className="font-mono text-slate-900 dark:text-white">{supportConfig.supportPhone}</span>
          </div>
          <div className="rounded-xl panel-inset p-3">
            <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Operating Mode</span>
            <span className="font-semibold text-amber-600 dark:text-amber-300">DEMO MODE (Simulated)</span>
          </div>
        </div>
      </section>
    </div>
  );
};
