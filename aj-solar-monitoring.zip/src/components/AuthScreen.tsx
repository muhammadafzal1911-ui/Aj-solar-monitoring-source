import React, { useState } from 'react';
import {
  ArrowRight,
  BatteryCharging,
  CheckCircle2,
  Eye,
  EyeOff,
  Lock,
  Mail,
  MapPin,
  Moon,
  Phone,
  ShieldCheck,
  Sun,
  User,
  Zap,
} from 'lucide-react';
import { ThemeMode } from '../types/solar';
import { BrandMark, FallbackImage } from './BrandMark';
import { PLANT_IMAGE_URL, SOLAR_FARM_IMAGE_URL } from '../data/demoData';

interface AuthScreenProps {
  theme: ThemeMode;
  onToggleTheme: () => void;
  onLogin: (email: string, password: string) => { ok: boolean; error?: string };
  onSignUp: (payload: {
    name: string;
    email: string;
    password: string;
    phone: string;
    address: string;
    plantName: string;
    capacityKwp: number;
  }) => { ok: boolean; error?: string };
  onQuickDemoLogin: (email: string) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({
  theme,
  onToggleTheme,
  onLogin,
  onSignUp,
  onQuickDemoLogin,
}) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [loginEmail, setLoginEmail] = useState('tariq@example.com');
  const [loginPassword, setLoginPassword] = useState('solar123');

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [plantName, setPlantName] = useState('');
  const [capacityKwp, setCapacityKwp] = useState('12');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const res = onLogin(loginEmail.trim(), loginPassword);
    if (!res.ok) {
      setError(res.error || 'Invalid credentials');
    }
  };

  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!name.trim() || !email.trim() || password.length < 6) {
      setError('Please enter your full name, valid email, and a password of at least 6 characters.');
      return;
    }
    const res = onSignUp({
      name: name.trim(),
      email: email.trim(),
      password,
      phone: phone.trim() || '+92 300 0000000',
      address: address.trim() || 'Lahore, Punjab',
      plantName: plantName.trim() || `${name.trim().split(' ')[0]}'s Solar Plant`,
      capacityKwp: Number(capacityKwp) || 12,
    });
    if (!res.ok) {
      setError(res.error || 'Could not create account.');
    }
  };

  return (
    <div className="relative min-h-screen energy-canvas text-slate-900 dark:text-slate-100 flex flex-col lg:flex-row overflow-hidden">
      {/* Subtle atmospheric solar farm backdrop */}
      <div className="fixed inset-0 pointer-events-none">
        <FallbackImage
          src={SOLAR_FARM_IMAGE_URL}
          alt="Utility solar array background"
          className="w-full h-full object-cover opacity-10 dark:opacity-20 scale-105"
          fallbackTitle="AJ Solar Array"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-[#F3F7FA]/90 via-[#F8FAFC]/85 to-[#EBF3F7]/92 dark:from-[#0B1322]/92 dark:via-[#0D182D]/85 dark:to-[#091523]/92" />
      </div>

      {/* Left Showcase Column */}
      <div className="relative z-10 lg:w-[52%] xl:w-[55%] flex flex-col justify-between p-6 sm:p-10 lg:p-14 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800/60">
        {/* Top Brand Lockup + Theme Switcher */}
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <BrandMark size={38} />
            <div>
              <span className="font-display text-lg font-semibold tracking-tight text-slate-900 dark:text-white block leading-tight">
                AJ Solar Monitoring
              </span>
              <span className="text-xs text-emerald-700 dark:text-cyan-300/90 font-medium">
                by AJ Solutions · Energy Telemetry
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
            className="min-h-[40px] px-3 rounded-xl panel-glass text-xs font-medium text-slate-700 dark:text-slate-200 inline-flex items-center gap-2"
          >
            {theme === 'dark' ? (
              <>
                <Sun className="w-4 h-4 text-amber-400" aria-hidden="true" />
                <span className="hidden sm:inline">Light</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-slate-700" aria-hidden="true" />
                <span className="hidden sm:inline">Dark</span>
              </>
            )}
          </button>
        </div>

        {/* Center Hero Value Prop + Preview Card */}
        <div className="my-8 lg:my-auto max-w-xl">
          <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 tracking-wide mb-2.5">
            PV Generation · Hybrid BESS · Grid Net Metering
          </p>
          <h1 className="font-display text-2xl sm:text-4xl lg:text-[42px] font-semibold tracking-tight text-slate-900 dark:text-white [text-wrap:balance] leading-[1.14]">
            Precision telemetry for residential rooftops and commercial solar fleets.
          </h1>
          <p className="mt-3.5 text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
            Monitor real-time kW array production, lithium battery state of charge, bi-directional grid export, and inverter diagnostics from any Android device or desktop console.
          </p>

          <div className="mt-7 hidden sm:grid grid-cols-12 rounded-2xl panel-glass overflow-hidden">
            <div className="col-span-5 relative min-h-[140px]">
              <FallbackImage
                src={PLANT_IMAGE_URL}
                alt="AJ Solar architectural rooftop array"
                className="w-full h-full object-cover"
                fallbackTitle="Rooftop Solar"
              />
            </div>
            <div className="col-span-7 p-4 flex flex-col justify-between">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-900 dark:text-white">Demo Fleet Telemetry</span>
                <span className="text-amber-700 dark:text-amber-300 font-semibold inline-flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
                  DEMO MODE
                </span>
              </div>
              <div className="grid grid-cols-3 gap-3 my-3">
                <div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">Monitored</p>
                  <p className="font-mono text-base font-semibold text-slate-900 dark:text-white tabular-nums">112.8 kWp</p>
                </div>
                <div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">Storage</p>
                  <p className="font-mono text-base font-semibold text-amber-600 dark:text-amber-300 tabular-nums">122.9 kWh</p>
                </div>
                <div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">Efficiency</p>
                  <p className="font-mono text-base font-semibold text-sky-700 dark:text-cyan-300 tabular-nums">97.6%</p>
                </div>
              </div>
              <div className="flex items-center gap-4 text-[11px] text-slate-600 dark:text-slate-400 pt-2 border-t border-slate-200 dark:border-slate-800/80">
                <span className="inline-flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                  MPPT Diagnostics
                </span>
                <span className="inline-flex items-center gap-1">
                  <BatteryCharging className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" aria-hidden="true" />
                  UPS Reserve Control
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="hidden lg:flex items-center justify-between text-xs text-slate-500 pt-4 border-t border-slate-200 dark:border-slate-800/60">
          <span>AJ Solutions · Clean Energy Systems</span>
          <span>Android & Desktop Ready</span>
        </div>
      </div>

      {/* Right Glass Auth Panel */}
      <div className="relative z-10 flex-1 flex flex-col justify-center px-5 py-8 sm:px-10 lg:px-12 xl:px-16">
        <div className="w-full max-w-md mx-auto rounded-2xl panel-glass p-5 sm:p-7">
          <div className="grid grid-cols-2 p-1 panel-inset rounded-xl mb-5">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError(null);
              }}
              className={`min-h-[42px] rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                mode === 'login'
                  ? 'bg-emerald-600 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('signup');
                setError(null);
              }}
              className={`min-h-[42px] rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                mode === 'signup'
                  ? 'bg-emerald-600 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              Create Account
            </button>
          </div>

          <div className="mb-5">
            <h2 className="font-display text-xl sm:text-2xl font-semibold text-slate-900 dark:text-white">
              {mode === 'login' ? 'Access Monitoring Portal' : 'Register Customer System'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {mode === 'login'
                ? 'Sign in to view live solar generation, battery charge, and plant alerts.'
                : 'Create your customer profile and provision your solar array telemetry.'}
            </p>
          </div>

          {error && (
            <div
              role="alert"
              className="mb-4 p-3 rounded-xl bg-rose-500/12 border border-rose-500/35 text-xs sm:text-sm text-rose-700 dark:text-rose-200"
            >
              {error}
            </div>
          )}

          {mode === 'login' ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label htmlFor="login-email" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" aria-hidden="true" />
                  <input
                    id="login-email"
                    type="email"
                    required
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full min-h-[46px] pl-10 pr-4 rounded-xl bg-white dark:bg-[#070D19]/90 border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="login-password" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" aria-hidden="true" />
                  <input
                    id="login-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="Enter password"
                    className="w-full min-h-[46px] pl-10 pr-12 rounded-xl bg-white dark:bg-[#070D19]/90 border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    className="absolute right-1.5 top-1/2 -translate-y-1/2 min-w-[40px] min-h-[40px] flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full min-h-[48px] mt-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 dark:hover:from-emerald-400 dark:hover:to-teal-300 active:scale-[0.99] text-white dark:text-slate-950 font-semibold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-500/15"
              >
                <span>Sign In to Portal</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>

              <div className="pt-5 mt-5 border-t border-slate-200 dark:border-slate-800/80">
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    Instant Demo Environments
                  </p>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-amber-500/15 text-amber-700 dark:text-amber-300 border border-amber-500/30">
                    DEMO MODE · Simulated
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() => onQuickDemoLogin('tariq@example.com')}
                    className="min-h-[48px] px-3.5 py-2.5 rounded-xl panel-inset hover:bg-slate-200/70 dark:hover:bg-[#101D36] text-left transition-colors flex items-center gap-2.5"
                  >
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                      <Sun className="w-4 h-4" aria-hidden="true" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">Customer Portal</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">Tariq · 2 Plants</p>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => onQuickDemoLogin('admin@ajsolar.com')}
                    className="min-h-[48px] px-3.5 py-2.5 rounded-xl panel-inset hover:bg-slate-200/70 dark:hover:bg-[#101D36] text-left transition-colors flex items-center gap-2.5"
                  >
                    <div className="w-8 h-8 rounded-lg bg-sky-500/15 text-sky-700 dark:text-cyan-300 flex items-center justify-center shrink-0">
                      <ShieldCheck className="w-4 h-4" aria-hidden="true" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">Admin Control</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">Fleet Operations</p>
                    </div>
                  </button>
                </div>
                <p className="mt-2.5 text-[11px] text-slate-500 font-mono">
                  tariq@example.com / solar123 · admin@ajsolar.com / admin123
                </p>
              </div>
            </form>
          ) : (
            <form onSubmit={handleSignUpSubmit} className="space-y-3.5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="signup-name" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Full Name
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" aria-hidden="true" />
                    <input
                      id="signup-name"
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Hamza Raza"
                      className="w-full min-h-[44px] pl-9 pr-3 rounded-xl bg-white dark:bg-[#070D19]/90 border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="signup-phone" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Phone Number
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" aria-hidden="true" />
                    <input
                      id="signup-phone"
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+92 300 1234567"
                      className="w-full min-h-[44px] pl-9 pr-3 rounded-xl bg-white dark:bg-[#070D19]/90 border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label htmlFor="signup-email" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" aria-hidden="true" />
                  <input
                    id="signup-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="hamza@example.com"
                    className="w-full min-h-[44px] pl-9 pr-3 rounded-xl bg-white dark:bg-[#070D19]/90 border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="signup-password" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Password (min. 6 characters)
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" aria-hidden="true" />
                  <input
                    id="signup-password"
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Create a strong password"
                    className="w-full min-h-[44px] pl-9 pr-11 rounded-xl bg-white dark:bg-[#070D19]/90 border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    className="absolute right-1 top-1/2 -translate-y-1/2 min-w-[40px] min-h-[40px] flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label htmlFor="signup-address" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Site Address
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" aria-hidden="true" />
                  <input
                    id="signup-address"
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Street, Sector, City"
                    className="w-full min-h-[44px] pl-9 pr-3 rounded-xl bg-white dark:bg-[#070D19]/90 border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 pt-0.5">
                <div className="col-span-2">
                  <label htmlFor="signup-plant" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Solar Plant Name
                  </label>
                  <input
                    id="signup-plant"
                    type="text"
                    value={plantName}
                    onChange={(e) => setPlantName(e.target.value)}
                    placeholder="e.g. Model Town Residence"
                    className="w-full min-h-[44px] px-3 rounded-xl bg-white dark:bg-[#070D19]/90 border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label htmlFor="signup-cap" className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                    Size (kWp)
                  </label>
                  <input
                    id="signup-cap"
                    type="number"
                    min={3}
                    max={250}
                    step="0.5"
                    value={capacityKwp}
                    onChange={(e) => setCapacityKwp(e.target.value)}
                    className="w-full min-h-[44px] px-3 rounded-xl bg-white dark:bg-[#070D19]/90 border border-slate-300 dark:border-slate-700/70 text-sm font-mono text-slate-900 dark:text-white tabular-nums focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full min-h-[48px] mt-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 active:scale-[0.99] text-white dark:text-slate-950 font-semibold text-sm flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-500/15"
              >
                <span>Create Customer Account</span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
