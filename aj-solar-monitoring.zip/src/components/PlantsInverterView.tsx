import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  BatteryFull,
  Calendar,
  CloudSun,
  Cpu,
  Gauge,
  LayoutDashboard,
  Leaf,
  MapPin,
  Plus,
  Search,
  Sun,
  User,
  Wrench,
  Zap,
} from 'lucide-react';
import { InverterStatus, LanguageCode, SolarPlant, Technician } from '../types/solar';
import { BATTERY_STORAGE_IMAGE_URL } from '../data/demoData';
import { formatRelativeTime } from '../utils/format';
import { getTranslations } from '../utils/i18n';
import { FallbackImage, InverterStatusText } from './BrandMark';

interface PlantsInverterViewProps {
  plants: SolarPlant[];
  selectedPlant: SolarPlant | null;
  onSelectPlant: (plantId: string) => void;
  onOpenPlantDashboard: (plantId: string) => void;
  onOpenAddPlant: () => void;
  onUpdatePlantStatus?: (plantId: string, status: InverterStatus) => void;
  technicians?: Technician[];
  language?: LanguageCode;
}

export const PlantsInverterView: React.FC<PlantsInverterViewProps> = ({
  plants,
  selectedPlant,
  onSelectPlant,
  onOpenPlantDashboard,
  onOpenAddPlant,
  onUpdatePlantStatus,
  technicians = [],
  language = 'en',
}) => {
  const t = getTranslations(language);
  const [viewMode, setViewMode] = useState<'directory' | 'detail'>('directory');
  const [statusFilter, setStatusFilter] = useState<'all' | InverterStatus>('all');
  const [search, setSearch] = useState('');

  const filteredPlants = useMemo(() => {
    const q = search.trim().toLowerCase();
    return plants.filter((p) => {
      if (statusFilter !== 'all' && p.inverter.status !== statusFilter) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        (p.customerName || '').toLowerCase().includes(q) ||
        p.location.toLowerCase().includes(q) ||
        p.panelModel.toLowerCase().includes(q) ||
        p.inverter.model.toLowerCase().includes(q)
      );
    });
  }, [plants, statusFilter, search]);

  if (plants.length === 0) {
    return (
      <div className="panel-glass rounded-2xl p-8 text-center space-y-3">
        <Sun className="w-10 h-10 text-emerald-500 mx-auto" aria-hidden="true" />
        <h2 className="font-display text-lg font-semibold text-slate-900 dark:text-white">
          No Solar Plants Registered
        </h2>
        <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md mx-auto">
          Add your first solar plant to monitor PV array strings, hybrid inverter health, and battery storage.
        </p>
        <button
          type="button"
          onClick={onOpenAddPlant}
          className="min-h-[44px] px-5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs inline-flex items-center gap-2"
        >
          <Plus className="w-4 h-4" aria-hidden="true" />
          <span>{t.addNewPlant}</span>
        </button>
      </div>
    );
  }

  // DIRECTORY VIEW: All Plants + Add New Plant + Status Filters
  if (viewMode === 'directory' || !selectedPlant) {
    return (
      <div className="space-y-4 sm:space-y-5">
        {/* Header Bar */}
        <section className="panel-glass rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h1 className="font-display text-lg sm:text-xl font-semibold text-slate-900 dark:text-white">
              {t.plantsManagement} ({plants.length})
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Tap any plant to inspect inverter MPPT diagnostics or launch its live monitoring dashboard
            </p>
          </div>
          <button
            type="button"
            onClick={onOpenAddPlant}
            className="min-h-[44px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold text-xs inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" aria-hidden="true" />
            <span>{t.addNewPlant}</span>
          </button>
        </section>

        {/* Search & Status Filter Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" aria-hidden="true" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search plant, customer, location, inverter..."
              aria-label="Search solar plants"
              className="w-full min-h-[44px] pl-10 pr-4 rounded-xl bg-white dark:bg-[#091224] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="inline-grid grid-cols-4 p-1 rounded-xl panel-glass self-start">
            {(['all', 'online', 'warning', 'offline'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`min-h-[38px] px-3 rounded-lg text-xs font-medium capitalize transition-colors whitespace-nowrap ${
                  statusFilter === st
                    ? 'bg-emerald-600 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        {/* Plant Cards Grid */}
        {filteredPlants.length === 0 ? (
          <div className="panel-glass rounded-2xl p-8 text-center">
            <p className="text-sm font-medium text-slate-900 dark:text-white">No plants match your filter</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Try clearing the search query or switching status filter.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-5">
            {filteredPlants.map((plant) => {
              const isSelected = plant.id === selectedPlant?.id;
              return (
                <article
                  key={plant.id}
                  className={`panel-glass rounded-2xl overflow-hidden flex flex-col justify-between transition-all ${
                    isSelected ? 'ring-1 ring-emerald-500/45' : ''
                  }`}
                >
                  <div>
                    <div className="relative h-40">
                      <FallbackImage
                        src={plant.imageUrl}
                        alt={plant.name}
                        className="w-full h-full object-cover"
                        fallbackTitle={plant.name}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/35 to-transparent" />
                      <div className="absolute top-3 left-3.5 right-3.5 flex items-center justify-between gap-2">
                        <span className="text-xs font-medium text-white/90 bg-slate-950/55 backdrop-blur-sm px-2.5 py-1 rounded-lg">
                          {plant.plantType}
                        </span>
                        <div className="bg-white/95 dark:bg-[#091224]/90 backdrop-blur-sm px-2.5 py-1 rounded-lg">
                          <InverterStatusText status={plant.inverter.status} compact />
                        </div>
                      </div>
                      <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between gap-2">
                        <div className="min-w-0">
                          <h2 className="font-display text-lg font-semibold text-white truncate">{plant.name}</h2>
                          <p className="text-xs text-slate-200 flex items-center gap-1.5 truncate">
                            <MapPin className="w-3.5 h-3.5 text-emerald-400 shrink-0" aria-hidden="true" />
                            <span>{plant.location}</span>
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="font-mono text-lg font-semibold text-emerald-300 tabular-nums leading-none">
                            {plant.telemetry.solarKw.toFixed(2)} kW
                          </p>
                          <p className="text-[11px] font-mono text-slate-300 tabular-nums mt-0.5">
                            {plant.capacityKwp} kWp
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 sm:p-5 space-y-3">
                      {/* Hardware & Customer Specification Grid */}
                      <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Customer</span>
                          <span className="font-medium text-slate-900 dark:text-white inline-flex items-center gap-1">
                            <User className="w-3 h-3 text-emerald-600 dark:text-emerald-400 shrink-0" aria-hidden="true" />
                            {plant.customerName || 'Account Owner'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Installed Date</span>
                          <span className="font-mono text-slate-900 dark:text-white tabular-nums">
                            {plant.installedDate}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Solar Array</span>
                          <span className="font-medium text-slate-900 dark:text-white block truncate">
                            {plant.panelCount} × {plant.panelBrand ? `${plant.panelBrand} ` : ''}
                            {plant.panelModel}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Inverter</span>
                          <span className="font-medium text-slate-900 dark:text-white block truncate">
                            {plant.inverter.brand ? `${plant.inverter.brand} ` : ''}
                            {plant.inverter.model}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Battery Bank</span>
                          <span className="font-medium text-slate-900 dark:text-white block truncate">
                            {plant.battery
                              ? `${plant.battery.brand ? `${plant.battery.brand} · ` : ''}${plant.battery.capacityKwh} kWh (${plant.telemetry.batterySoc}%)`
                              : 'Grid-Tie (No Battery)'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 block text-[11px]">Today Yield</span>
                          <span className="font-mono font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
                            {plant.telemetry.dailyKwh.toFixed(1)} kWh
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Card Action Bar */}
                  <div className="px-4 sm:px-5 pb-4 pt-2 border-t border-slate-200 dark:border-slate-800/70 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onOpenPlantDashboard(plant.id)}
                      className="flex-1 min-h-[42px] px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold text-xs inline-flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
                    >
                      <LayoutDashboard className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>{t.openDashboard}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        onSelectPlant(plant.id);
                        setViewMode('detail');
                      }}
                      className="min-h-[42px] px-3.5 rounded-xl panel-inset hover:bg-slate-200 dark:hover:bg-[#14233F] text-xs font-medium text-slate-800 dark:text-slate-200 inline-flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
                    >
                      <Cpu className="w-3.5 h-3.5 text-sky-600 dark:text-cyan-300" aria-hidden="true" />
                      <span>Inverter & Specs</span>
                    </button>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  // DETAILED HARDWARE & PLANT INSPECTOR VIEW
  const { inverter, battery, telemetry, weather } = selectedPlant;
  const assignedTech = technicians.find((t) => t.id === selectedPlant.assignedTechnicianId);

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Top Back & Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => setViewMode('directory')}
          className="min-h-[42px] px-3.5 rounded-xl panel-glass hover:bg-slate-100 dark:hover:bg-[#101C33] text-xs font-semibold text-slate-800 dark:text-white inline-flex items-center gap-2 transition-colors whitespace-nowrap"
        >
          <ArrowLeft className="w-4 h-4" aria-hidden="true" />
          <span>{t.backToPlants}</span>
        </button>

        <div className="flex flex-wrap items-center gap-2">
          {onUpdatePlantStatus && (
            <div className="inline-grid grid-cols-3 p-1 rounded-xl panel-glass">
              {(['online', 'warning', 'offline'] as InverterStatus[]).map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => onUpdatePlantStatus(selectedPlant.id, st)}
                  className={`min-h-[34px] px-2.5 rounded-lg text-[11px] font-medium capitalize transition-colors whitespace-nowrap ${
                    inverter.status === st
                      ? st === 'online'
                        ? 'bg-emerald-600 text-white font-semibold'
                        : st === 'warning'
                          ? 'bg-amber-500 text-slate-950 font-semibold'
                          : 'bg-rose-600 text-white font-semibold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {st}
                </button>
              ))}
            </div>
          )}

          <button
            type="button"
            onClick={() => onOpenPlantDashboard(selectedPlant.id)}
            className="min-h-[42px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold text-xs inline-flex items-center gap-2 whitespace-nowrap"
          >
            <LayoutDashboard className="w-4 h-4" aria-hidden="true" />
            <span>{t.openDashboard}</span>
          </button>
        </div>
      </div>

      {/* Hero Plant Summary */}
      <section className="panel-glass rounded-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
        <div className="lg:col-span-5 relative min-h-[210px] sm:min-h-[250px]">
          <FallbackImage
            src={selectedPlant.imageUrl}
            alt={selectedPlant.name}
            className="w-full h-full object-cover"
            fallbackTitle={selectedPlant.name}
          />
        </div>

        <div className="lg:col-span-7 p-4 sm:p-6 flex flex-col justify-between">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-semibold text-emerald-700 dark:text-cyan-300">
                {selectedPlant.plantType} · {selectedPlant.customerName || 'Customer'}
              </span>
              <InverterStatusText status={inverter.status} />
            </div>

            <h1 className="font-display text-xl sm:text-2xl font-semibold text-slate-900 dark:text-white mt-1.5">
              {selectedPlant.name}
            </h1>

            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 dark:text-slate-400 mt-1.5">
              <span className="inline-flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                {selectedPlant.location}
              </span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5" aria-hidden="true" />
                Installed {selectedPlant.installedDate}
              </span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1">
                <CloudSun className="w-3.5 h-3.5 text-amber-500" aria-hidden="true" />
                {weather.condition}, {weather.tempC}°C · {weather.irradianceWm2} W/m²
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 pt-4 border-t border-slate-200 dark:border-slate-800/80">
            <div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Array Capacity</p>
              <p className="font-mono text-base font-semibold text-slate-900 dark:text-white tabular-nums mt-0.5">
                {selectedPlant.capacityKwp} kWp
              </p>
            </div>
            <div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">PV Modules</p>
              <p className="font-mono text-base font-semibold text-slate-900 dark:text-white tabular-nums mt-0.5">
                {selectedPlant.panelCount} panels
              </p>
            </div>
            <div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">Yearly Yield</p>
              <p className="font-mono text-base font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums mt-0.5">
                {(telemetry.yearlyKwh / 1000).toFixed(2)} MWh
              </p>
            </div>
            <div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">CO₂ Saved</p>
              <p className="font-mono text-base font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums mt-0.5 inline-flex items-center gap-1">
                <Leaf className="w-3.5 h-3.5" aria-hidden="true" />
                {(telemetry.co2SavedKg / 1000).toFixed(1)} t
              </p>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span>
              Modules:{' '}
              <span className="text-slate-800 dark:text-slate-200">
                {selectedPlant.panelBrand ? `${selectedPlant.panelBrand} · ` : ''}
                {selectedPlant.panelModel}
              </span>
            </span>
            {assignedTech && (
              <span className="inline-flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                <Wrench className="w-3.5 h-3.5 text-sky-600 dark:text-cyan-300" aria-hidden="true" />
                Engineer: {assignedTech.name}
              </span>
            )}
          </div>
        </div>
      </section>

      {/* Inverter MPPT Details + Battery Storage */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 sm:gap-5 items-stretch">
        <section className="xl:col-span-7 panel-glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-16 h-12 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700/70 shrink-0">
                  <FallbackImage
                    src={selectedPlant.inverterImageUrl}
                    alt={inverter.model}
                    className="w-full h-full object-cover"
                    fallbackTitle="Inverter"
                  />
                </div>
                <div>
                  <h2 className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white">
                    {inverter.brand ? `${inverter.brand} · ` : ''}
                    {inverter.model}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                    SN {inverter.serialNumber} · {inverter.firmwareVersion}
                  </p>
                </div>
              </div>
              <InverterStatusText status={inverter.status} />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 rounded-xl panel-inset mb-4">
              <div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Rated Output</p>
                <p className="font-mono text-sm font-semibold text-slate-900 dark:text-white tabular-nums mt-0.5">
                  {inverter.ratedPowerKw} kW
                </p>
              </div>
              <div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">AC Grid Output</p>
                <p className="font-mono text-sm font-semibold text-sky-700 dark:text-cyan-300 tabular-nums mt-0.5">
                  {inverter.acVoltageV.toFixed(1)} V
                </p>
              </div>
              <div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Grid Frequency</p>
                <p className="font-mono text-sm font-semibold text-slate-900 dark:text-white tabular-nums mt-0.5">
                  {inverter.acFrequencyHz.toFixed(2)} Hz
                </p>
              </div>
              <div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">Internal Temp</p>
                <p className="font-mono text-sm font-semibold text-amber-600 dark:text-amber-300 tabular-nums mt-0.5">
                  {inverter.temperatureC.toFixed(1)} °C
                </p>
              </div>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2 flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                DC MPPT Input Strings
              </h3>
              <div className="overflow-x-auto rounded-xl panel-inset">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-200/70 dark:bg-[#060B16]/80 text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800/80">
                    <tr>
                      <th className="py-2.5 px-3 font-medium">String</th>
                      <th className="py-2.5 px-3 font-medium text-right">Voltage</th>
                      <th className="py-2.5 px-3 font-medium text-right">Current</th>
                      <th className="py-2.5 px-3 font-medium text-right">Power</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
                    {inverter.dcStrings.map((str) => (
                      <tr key={str.id} className="hover:bg-slate-200/40 dark:hover:bg-slate-800/20">
                        <td className="py-2.5 px-3 text-slate-800 dark:text-slate-200 font-medium">{str.name}</td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                          {str.voltageV.toFixed(1)} V
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                          {str.currentA.toFixed(2)} A
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums font-semibold text-emerald-700 dark:text-emerald-400">
                          {str.powerKw.toFixed(2)} kW
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span className="inline-flex items-center gap-1.5">
              <Gauge className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
              Conversion Efficiency:{' '}
              <span className="font-mono text-slate-900 dark:text-white tabular-nums">
                {inverter.efficiencyPct.toFixed(1)}%
              </span>
            </span>
            <span className="font-mono tabular-nums">Last Sync: {formatRelativeTime(inverter.lastSyncIso)}</span>
          </div>
        </section>

        <section className="xl:col-span-5 panel-glass rounded-2xl overflow-hidden flex flex-col justify-between">
          {battery ? (
            <>
              <div className="relative h-36">
                <FallbackImage
                  src={BATTERY_STORAGE_IMAGE_URL}
                  alt={battery.model}
                  className="w-full h-full object-cover"
                  fallbackTitle={battery.model}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/40 to-transparent" />
                <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
                  <div>
                    <h2 className="font-display text-base sm:text-lg font-semibold text-white">
                      {battery.brand ? `${battery.brand} · ` : ''}
                      {battery.model}
                    </h2>
                    <p className="text-xs text-slate-200">
                      {battery.chemistry} · {battery.capacityKwh} kWh Rack
                    </p>
                  </div>
                  <span className="font-mono text-xl font-semibold text-amber-300 tabular-nums">
                    {telemetry.batterySoc}%
                  </span>
                </div>
              </div>

              <div className="p-4 sm:p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="h-2.5 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden mb-4">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        telemetry.batterySoc <= 20 ? 'bg-rose-500' : 'bg-gradient-to-r from-emerald-500 to-amber-400'
                      }`}
                      style={{ width: `${telemetry.batterySoc}%` }}
                    />
                  </div>

                  <div className="divide-y divide-slate-200 dark:divide-slate-800/70 text-sm">
                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">Charge Mode</span>
                      <span className="font-medium capitalize text-slate-900 dark:text-white">
                        {telemetry.batteryStatus}
                      </span>
                    </div>
                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">Live Battery Power</span>
                      <span className="font-mono text-slate-900 dark:text-white tabular-nums">
                        {Math.abs(telemetry.batteryKw).toFixed(2)} kW
                      </span>
                    </div>
                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">State of Health (SoH)</span>
                      <span className="font-mono text-emerald-700 dark:text-emerald-400 tabular-nums">
                        {battery.sohPct}%
                      </span>
                    </div>
                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">DC Bus Voltage</span>
                      <span className="font-mono text-slate-900 dark:text-white tabular-nums">
                        {battery.voltageV.toFixed(1)} V
                      </span>
                    </div>
                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">Cell Temperature</span>
                      <span className="font-mono text-slate-900 dark:text-white tabular-nums">
                        {battery.temperatureC.toFixed(1)} °C
                      </span>
                    </div>
                    <div className="py-2 flex items-center justify-between">
                      <span className="text-slate-500 dark:text-slate-400">Completed Cycles</span>
                      <span className="font-mono text-slate-900 dark:text-white tabular-nums">{battery.cycles}</span>
                    </div>
                  </div>
                </div>

                <p className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-800/80 text-xs text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                  <BatteryFull className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                  BMS protection active · Thermal balancing nominal
                </p>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
              <Zap className="w-8 h-8 text-sky-600 dark:text-cyan-300 mb-2" aria-hidden="true" />
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Grid-Tie Configuration
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs">
                This plant operates without local battery storage and exports surplus generation directly to the utility grid.
              </p>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
