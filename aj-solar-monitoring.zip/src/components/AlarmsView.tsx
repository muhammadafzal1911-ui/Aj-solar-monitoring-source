import React, { useMemo, useState } from 'react';
import {
  AlertOctagon,
  AlertTriangle,
  BatteryWarning,
  Check,
  CheckCircle2,
  Info,
  Thermometer,
  WifiOff,
} from 'lucide-react';
import { AlarmCategory, AlarmStatus, LanguageCode, SolarAlarm } from '../types/solar';
import { formatTimestamp } from '../utils/format';
import { getTranslations } from '../utils/i18n';

interface AlarmsViewProps {
  alarms: SolarAlarm[];
  onUpdateAlarmStatus: (alarmId: string, status: AlarmStatus) => void;
  onResolveAll: () => void;
  title?: string;
  language?: LanguageCode;
}

function inferCategory(alarm: SolarAlarm): AlarmCategory {
  if (alarm.category) return alarm.category;
  const code = alarm.code.toUpperCase();
  const title = alarm.title.toLowerCase();
  if (code.startsWith('COM') || title.includes('offline')) return 'inverter_offline';
  if (code.startsWith('BAT') || title.includes('battery')) return 'battery';
  if (code.startsWith('TMP') || title.includes('temp')) return 'temperature';
  if (code.startsWith('GRD') || title.includes('grid')) return 'grid';
  return 'system';
}

const CATEGORY_LABELS: Record<AlarmCategory, string> = {
  inverter_offline: 'Inverter Offline',
  battery: 'Battery Alert',
  temperature: 'Temperature Alert',
  grid: 'Grid & Voltage',
  system: 'System Notice',
};

export const AlarmsView: React.FC<AlarmsViewProps> = ({
  alarms,
  onUpdateAlarmStatus,
  onResolveAll,
  title,
  language = 'en',
}) => {
  const t = getTranslations(language);
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'warning_history'>('all');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'critical' | AlarmCategory>('all');

  const counts = useMemo(() => {
    const active = alarms.filter((a) => a.status !== 'resolved').length;
    const warningHistory = alarms.filter((a) => a.severity === 'warning' || a.status === 'resolved').length;
    const critical = alarms.filter((a) => a.severity === 'critical').length;
    const offline = alarms.filter((a) => inferCategory(a) === 'inverter_offline').length;
    const battery = alarms.filter((a) => inferCategory(a) === 'battery').length;
    const temperature = alarms.filter((a) => inferCategory(a) === 'temperature').length;
    return { active, warningHistory, critical, offline, battery, temperature };
  }, [alarms]);

  const filteredAlarms = useMemo(() => {
    return alarms.filter((alarm) => {
      if (statusFilter === 'active' && alarm.status === 'resolved') return false;
      if (statusFilter === 'warning_history' && alarm.severity !== 'warning' && alarm.status !== 'resolved') {
        return false;
      }
      if (categoryFilter === 'critical' && alarm.severity !== 'critical') return false;
      if (
        categoryFilter !== 'all' &&
        categoryFilter !== 'critical' &&
        inferCategory(alarm) !== categoryFilter
      ) {
        return false;
      }
      return true;
    });
  }, [alarms, statusFilter, categoryFilter]);

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Header */}
      <div className="panel-glass rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-lg sm:text-xl font-semibold text-slate-900 dark:text-white">
            {title || t.alarmsTitle}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {counts.active === 0
              ? 'All inverters, battery packs, and thermal sensors are nominal'
              : `${counts.active} active alert${counts.active === 1 ? '' : 's'} · ${counts.warningHistory} in warning history`}
          </p>
        </div>

        {counts.active > 0 && (
          <button
            type="button"
            onClick={onResolveAll}
            className="min-h-[44px] px-4 rounded-xl panel-inset hover:bg-slate-200 dark:hover:bg-[#14233F] text-xs font-medium text-slate-800 dark:text-white inline-flex items-center justify-center gap-2 transition-colors whitespace-nowrap self-start sm:self-auto"
          >
            <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
            <span>{t.markAllResolved}</span>
          </button>
        )}
      </div>

      {/* Category & Alert-Type Quick Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <button
          type="button"
          onClick={() => setCategoryFilter(categoryFilter === 'critical' ? 'all' : 'critical')}
          className={`rounded-xl p-3 text-left transition-colors border ${
            categoryFilter === 'critical'
              ? 'bg-rose-500/15 border-rose-500/50'
              : 'panel-glass hover:border-rose-500/35'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-rose-700 dark:text-rose-300 font-medium">
            <span>Critical Faults</span>
            <AlertOctagon className="w-4 h-4" aria-hidden="true" />
          </div>
          <p className="font-mono text-xl font-semibold text-slate-900 dark:text-white tabular-nums mt-1">
            {counts.critical}
          </p>
        </button>

        <button
          type="button"
          onClick={() =>
            setCategoryFilter(categoryFilter === 'inverter_offline' ? 'all' : 'inverter_offline')
          }
          className={`rounded-xl p-3 text-left transition-colors border ${
            categoryFilter === 'inverter_offline'
              ? 'bg-rose-500/15 border-rose-500/50'
              : 'panel-glass hover:border-rose-500/35'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-slate-700 dark:text-slate-300 font-medium">
            <span>Inverter Offline</span>
            <WifiOff className="w-4 h-4 text-rose-500" aria-hidden="true" />
          </div>
          <p className="font-mono text-xl font-semibold text-slate-900 dark:text-white tabular-nums mt-1">
            {counts.offline}
          </p>
        </button>

        <button
          type="button"
          onClick={() => setCategoryFilter(categoryFilter === 'battery' ? 'all' : 'battery')}
          className={`rounded-xl p-3 text-left transition-colors border ${
            categoryFilter === 'battery'
              ? 'bg-amber-500/15 border-amber-500/50'
              : 'panel-glass hover:border-amber-500/35'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-amber-700 dark:text-amber-300 font-medium">
            <span>Battery Alerts</span>
            <BatteryWarning className="w-4 h-4" aria-hidden="true" />
          </div>
          <p className="font-mono text-xl font-semibold text-slate-900 dark:text-white tabular-nums mt-1">
            {counts.battery}
          </p>
        </button>

        <button
          type="button"
          onClick={() => setCategoryFilter(categoryFilter === 'temperature' ? 'all' : 'temperature')}
          className={`rounded-xl p-3 text-left transition-colors border ${
            categoryFilter === 'temperature'
              ? 'bg-orange-500/15 border-orange-500/50'
              : 'panel-glass hover:border-orange-500/35'
          }`}
        >
          <div className="flex items-center justify-between text-xs text-orange-700 dark:text-orange-300 font-medium">
            <span>Temp Alerts</span>
            <Thermometer className="w-4 h-4" aria-hidden="true" />
          </div>
          <p className="font-mono text-xl font-semibold text-slate-900 dark:text-white tabular-nums mt-1">
            {counts.temperature}
          </p>
        </button>
      </div>

      {/* Status & Category Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="inline-grid grid-cols-3 p-1 rounded-xl panel-glass self-start">
          {(
            [
              { id: 'all', label: 'All Logs' },
              { id: 'active', label: `Active (${counts.active})` },
              { id: 'warning_history', label: 'Warning History' },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setStatusFilter(tab.id)}
              className={`min-h-[40px] px-3.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                statusFilter === tab.id
                  ? 'bg-emerald-600 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          {(
            [
              { id: 'all', label: 'All Types' },
              { id: 'critical', label: 'Critical' },
              { id: 'inverter_offline', label: 'Offline' },
              { id: 'battery', label: 'Battery' },
              { id: 'temperature', label: 'Temperature' },
              { id: 'grid', label: 'Grid' },
            ] as const
          ).map((cat) => (
            <button
              key={cat.id}
              type="button"
              onClick={() => setCategoryFilter(cat.id)}
              className={`min-h-[38px] px-3 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 border ${
                categoryFilter === cat.id
                  ? 'bg-slate-200 dark:bg-[#172847] border-slate-400 dark:border-slate-600 text-slate-900 dark:text-white font-semibold'
                  : 'panel-glass text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Alarm Cards */}
      {filteredAlarms.length === 0 ? (
        <div className="panel-glass rounded-2xl p-10 text-center">
          <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-3" aria-hidden="true" />
          <p className="font-display text-base font-semibold text-slate-900 dark:text-white">
            No matching alerts
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Adjust the filters above or check back when new inverter, battery, or thermal events occur.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredAlarms.map((alarm) => {
            const isResolved = alarm.status === 'resolved';
            const cat = inferCategory(alarm);
            const SeverityIcon =
              cat === 'inverter_offline'
                ? WifiOff
                : cat === 'temperature'
                  ? Thermometer
                  : cat === 'battery'
                    ? BatteryWarning
                    : alarm.severity === 'critical'
                      ? AlertOctagon
                      : alarm.severity === 'warning'
                        ? AlertTriangle
                        : Info;

            const iconColor =
              alarm.severity === 'critical'
                ? 'text-rose-600 dark:text-rose-400 bg-rose-500/15'
                : alarm.severity === 'warning'
                  ? 'text-amber-600 dark:text-amber-400 bg-amber-500/15'
                  : 'text-sky-600 dark:text-cyan-300 bg-cyan-500/15';

            const statusTextClass = isResolved
              ? 'text-emerald-700 dark:text-emerald-400'
              : alarm.status === 'acknowledged'
                ? 'text-sky-700 dark:text-cyan-300'
                : 'text-amber-700 dark:text-amber-400';

            return (
              <article
                key={alarm.id}
                className={`panel-glass rounded-2xl p-4 sm:p-5 transition-opacity ${
                  isResolved ? 'opacity-80' : 'opacity-100'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="flex items-start gap-3.5 min-w-0">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${iconColor}`}>
                      <SeverityIcon className="w-5 h-5" aria-hidden="true" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500 dark:text-slate-400">
                        <span className="font-mono text-slate-700 dark:text-slate-300">{alarm.code}</span>
                        <span aria-hidden="true">·</span>
                        <span className="capitalize font-semibold text-slate-800 dark:text-slate-200">
                          {alarm.severity}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{CATEGORY_LABELS[cat]}</span>
                        <span aria-hidden="true">·</span>
                        <span>{alarm.plantName}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">{formatTimestamp(alarm.timestampIso)}</span>
                      </div>

                      <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white mt-1">
                        {alarm.title}
                      </h2>
                      <p className="text-sm text-slate-700 dark:text-slate-300 mt-1 leading-relaxed">
                        {alarm.message}
                      </p>

                      <div className="mt-3 p-3 rounded-xl panel-inset text-xs text-slate-700 dark:text-slate-300">
                        <span className="font-semibold text-emerald-700 dark:text-emerald-400">
                          Recommended Action:{' '}
                        </span>
                        {alarm.recommendation}
                      </div>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end gap-2 shrink-0 pt-2 sm:pt-0">
                    <span className={`text-xs font-semibold capitalize inline-flex items-center gap-1.5 ${statusTextClass}`}>
                      <span
                        className={`w-2 h-2 rounded-full ${
                          isResolved
                            ? 'bg-emerald-500'
                            : alarm.status === 'acknowledged'
                              ? 'bg-cyan-500'
                              : 'bg-amber-500'
                        }`}
                        aria-hidden="true"
                      />
                      {alarm.status}
                    </span>

                    {!isResolved && (
                      <div className="flex items-center gap-2">
                        {alarm.status === 'active' && (
                          <button
                            type="button"
                            onClick={() => onUpdateAlarmStatus(alarm.id, 'acknowledged')}
                            className="min-h-[40px] px-3 rounded-xl panel-inset hover:bg-slate-200 dark:hover:bg-[#152847] text-xs font-medium text-slate-800 dark:text-slate-200 whitespace-nowrap"
                          >
                            {t.acknowledge}
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onUpdateAlarmStatus(alarm.id, 'resolved')}
                          className="min-h-[40px] px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-xs font-semibold text-white dark:text-slate-950 whitespace-nowrap"
                        >
                          {t.resolve}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
