import React, { useMemo, useState } from 'react';
import {
  Activity,
  AlertOctagon,
  AlertTriangle,
  Building2,
  Cpu,
  Eye,
  MapPin,
  MessageCircle,
  Phone,
  Plus,
  Power,
  Search,
  Settings,
  ShieldCheck,
  Sun,
  UserCheck,
  UserPlus,
  Users,
  UserX,
  Wrench,
  X,
} from 'lucide-react';
import {
  Account,
  AdminTab,
  InverterStatus,
  SolarAlarm,
  SolarPlant,
  SupportInquiry,
  Technician,
} from '../types/solar';
import { ENGINEER_FIELD_IMAGE_URL, NewPlantInput } from '../data/demoData';
import { buildTelUrl, buildWhatsAppUrl, formatTimestamp } from '../utils/format';
import { FallbackImage, InverterStatusText } from './BrandMark';
import { AlarmsView } from './AlarmsView';
import { AddPlantModal } from './AddPlantModal';

interface AdminDashboardViewProps {
  activeTab: AdminTab;
  onTabChange: (tab: AdminTab) => void;
  accounts: Account[];
  plants: SolarPlant[];
  alarms: SolarAlarm[];
  technicians: Technician[];
  inquiries: SupportInquiry[];
  onAddCustomer: (payload: { name: string; email: string; phone: string; address: string; city: string }) => void;
  onToggleCustomerStatus: (customerId: string) => void;
  onCreatePlant: (input: NewPlantInput) => void;
  onSetInverterStatus: (plantId: string, status: InverterStatus) => void;
  onSimulateFaultAlarm: (plantId: string) => void;
  onInspectCustomer: (customerId: string) => void;
  onUpdateAlarmStatus: (alarmId: string, status: SolarAlarm['status']) => void;
  onResolveAllAlarms: () => void;
  onAddTechnician: (payload: {
    name: string;
    roleTitle: string;
    region: string;
    phone: string;
    certification: string;
  }) => void;
  onCycleTechnicianAvailability: (techId: string) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  activeTab,
  onTabChange,
  accounts,
  plants,
  alarms,
  technicians,
  inquiries,
  onAddCustomer,
  onToggleCustomerStatus,
  onCreatePlant,
  onSetInverterStatus,
  onSimulateFaultAlarm,
  onInspectCustomer,
  onUpdateAlarmStatus,
  onResolveAllAlarms,
  onAddTechnician,
  onCycleTechnicianAvailability,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'suspended'>('all');
  const [cityFilter, setCityFilter] = useState<string>('all');

  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [showAddSystem, setShowAddSystem] = useState(false);
  const [showAddTechnician, setShowAddTechnician] = useState(false);

  const [custName, setCustName] = useState('');
  const [custEmail, setCustEmail] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custAddress, setCustAddress] = useState('');
  const [custCity, setCustCity] = useState('Lahore');

  const customers = useMemo(() => accounts.filter((a) => a.role === 'customer'), [accounts]);

  const [techName, setTechName] = useState('');
  const [techRole, setTechRole] = useState('Field Commissioning Engineer');
  const [techRegion, setTechRegion] = useState('Lahore & Punjab');
  const [techPhone, setTechPhone] = useState('');
  const [techCert, setTechCert] = useState('AEDB Certified · 3-Phase Hybrid');

  const fleetStats = useMemo(() => {
    const totalCapacity = plants.reduce((sum, p) => sum + p.capacityKwp, 0);
    const totalLiveKw = plants.reduce((sum, p) => sum + p.telemetry.solarKw, 0);
    const totalDailyKwh = plants.reduce((sum, p) => sum + p.telemetry.dailyKwh, 0);
    const totalMonthlyKwh = plants.reduce((sum, p) => sum + p.telemetry.monthlyKwh, 0);
    const onlineCount = plants.filter((p) => p.inverter.status === 'online').length;
    const offlineCount = plants.filter((p) => p.inverter.status === 'offline').length;
    const warningCount = plants.filter((p) => p.inverter.status === 'warning').length;
    const healthPct = plants.length > 0 ? Math.round(((onlineCount + warningCount * 0.6) / plants.length) * 100) : 100;

    const criticalAlarms = alarms.filter((a) => a.status !== 'resolved' && a.severity === 'critical').length;
    const warningAlarms = alarms.filter((a) => a.status !== 'resolved' && a.severity === 'warning').length;
    const infoAlarms = alarms.filter((a) => a.status !== 'resolved' && a.severity === 'info').length;
    const resolvedAlarms = alarms.filter((a) => a.status === 'resolved').length;

    return {
      totalCapacity,
      totalLiveKw,
      totalDailyKwh,
      totalMonthlyKwh,
      onlineCount,
      offlineCount,
      warningCount,
      healthPct,
      criticalAlarms,
      warningAlarms,
      infoAlarms,
      resolvedAlarms,
      activeAlarms: criticalAlarms + warningAlarms + infoAlarms,
    };
  }, [plants, alarms]);

  const cityBreakdown = useMemo(() => {
    const map = new Map<string, { city: string; plants: number; capacityKwp: number; liveKw: number }>();
    for (const p of plants) {
      const key = p.city || 'Other';
      const prev = map.get(key) || { city: key, plants: 0, capacityKwp: 0, liveKw: 0 };
      map.set(key, {
        city: key,
        plants: prev.plants + 1,
        capacityKwp: prev.capacityKwp + p.capacityKwp,
        liveKw: prev.liveKw + p.telemetry.solarKw,
      });
    }
    return Array.from(map.values()).sort((a, b) => b.capacityKwp - a.capacityKwp);
  }, [plants]);

  const availableCities = useMemo(
    () => Array.from(new Set(customers.map((c) => c.city).filter(Boolean))),
    [customers]
  );

  const filteredCustomers = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return customers.filter((c) => {
      if (statusFilter !== 'all' && c.status !== statusFilter) return false;
      if (cityFilter !== 'all' && c.city !== cityFilter) return false;
      if (!q) return true;
      return (
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        c.address.toLowerCase().includes(q) ||
        c.city.toLowerCase().includes(q)
      );
    });
  }, [customers, searchQuery, statusFilter, cityFilter]);

  const filteredPlants = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return plants;
    return plants.filter((p) => {
      const owner = customers.find((c) => c.id === p.ownerId);
      return (
        p.name.toLowerCase().includes(q) ||
        p.location.toLowerCase().includes(q) ||
        p.city.toLowerCase().includes(q) ||
        p.inverter.serialNumber.toLowerCase().includes(q) ||
        p.inverter.model.toLowerCase().includes(q) ||
        (owner && owner.name.toLowerCase().includes(q))
      );
    });
  }, [plants, customers, searchQuery]);

  const fleetDailyTotals = useMemo(() => {
    const hours = ['06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00'];
    return hours.map((time) => {
      const sumKw = plants.reduce((acc, p) => {
        const pt = p.charts.daily.find((d) => d.time === time);
        return acc + (pt ? pt.solarKw : 0);
      }, 0);
      return { time, sumKw: Number(sumKw.toFixed(1)) };
    });
  }, [plants]);

  const maxFleetHourKw = Math.max(...fleetDailyTotals.map((h) => h.sumKw), 1);

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!custName.trim() || !custEmail.trim()) return;
    onAddCustomer({
      name: custName.trim(),
      email: custEmail.trim(),
      phone: custPhone.trim() || '+92 300 0000000',
      address: custAddress.trim() || `${custCity}, Pakistan`,
      city: custCity.trim() || 'Lahore',
    });
    setCustName('');
    setCustEmail('');
    setCustPhone('');
    setCustAddress('');
    setShowAddCustomer(false);
  };

  const handleCreateTechnician = (e: React.FormEvent) => {
    e.preventDefault();
    if (!techName.trim()) return;
    onAddTechnician({
      name: techName.trim(),
      roleTitle: techRole.trim() || 'Solar Field Technician',
      region: techRegion.trim() || 'Lahore & Punjab',
      phone: techPhone.trim() || '+92 300 5550199',
      certification: techCert.trim() || 'AEDB Certified Installer',
    });
    setTechName('');
    setTechPhone('');
    setShowAddTechnician(false);
  };

  if (activeTab === 'alarms') {
    return (
      <AlarmsView
        alarms={alarms}
        onUpdateAlarmStatus={onUpdateAlarmStatus}
        onResolveAll={onResolveAllAlarms}
        title="Fleet Alarms & Incident Queue"
      />
    );
  }

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* 5-Metric Commercial Fleet Command Strip */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3 sm:gap-4">
        <div className="panel-glass rounded-2xl p-3.5 sm:p-4">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Total Customers</span>
            <Users className="w-4 h-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
          </div>
          <p className="font-mono text-2xl font-semibold text-slate-900 dark:text-white tabular-nums mt-2">
            {customers.length}
          </p>
          <p className="text-[11px] text-emerald-700 dark:text-emerald-400 mt-1 font-mono tabular-nums">
            {customers.filter((c) => c.status === 'active').length} active · {customers.filter((c) => c.status === 'suspended').length} suspended
          </p>
        </div>

        <div className="panel-glass rounded-2xl p-3.5 sm:p-4">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Total Plants</span>
            <Building2 className="w-4 h-4 text-sky-600 dark:text-cyan-300" aria-hidden="true" />
          </div>
          <p className="font-mono text-2xl font-semibold text-slate-900 dark:text-white tabular-nums mt-2">
            {plants.length}
            <span className="text-xs font-normal text-slate-500 dark:text-slate-400 ml-1.5">sites</span>
          </p>
          <p className="text-[11px] text-sky-700 dark:text-cyan-300 mt-1 font-mono tabular-nums">
            {fleetStats.totalCapacity.toFixed(1)} kWp · {fleetStats.totalLiveKw.toFixed(1)} kW live
          </p>
        </div>

        <div className="panel-glass rounded-2xl p-3.5 sm:p-4">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Online Inverters</span>
            <Cpu className="w-4 h-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
          </div>
          <p className="font-mono text-2xl font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums mt-2">
            {fleetStats.onlineCount}
            <span className="text-xs font-normal text-slate-500 dark:text-slate-400 ml-1.5">/ {plants.length}</span>
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 font-mono tabular-nums">
            {fleetStats.warningCount} warning · {fleetStats.healthPct}% health
          </p>
        </div>

        <div className="panel-glass rounded-2xl p-3.5 sm:p-4">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Offline Inverters</span>
            <Power className="w-4 h-4 text-rose-500 dark:text-rose-400" aria-hidden="true" />
          </div>
          <p className="font-mono text-2xl font-semibold text-rose-600 dark:text-rose-400 tabular-nums mt-2">
            {fleetStats.offlineCount}
          </p>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 font-mono tabular-nums">
            {fleetStats.offlineCount === 0 ? 'All nodes reporting' : 'Requires technician check'}
          </p>
        </div>

        <button
          type="button"
          onClick={() => onTabChange('alarms')}
          className="col-span-2 md:col-span-1 panel-glass rounded-2xl p-3.5 sm:p-4 text-left hover:border-amber-500/45 transition-colors"
        >
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Active Alarms</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" aria-hidden="true" />
          </div>
          <p className="font-mono text-2xl font-semibold text-slate-900 dark:text-white tabular-nums mt-2">
            {fleetStats.activeAlarms}
          </p>
          <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-1 font-mono tabular-nums">
            {fleetStats.criticalAlarms} critical · {fleetStats.warningAlarms} warning
          </p>
        </button>
      </div>

      {/* Fleet Analytics Overview Row */}
      {activeTab === 'fleet' && (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 sm:gap-5 items-stretch">
          {/* Energy Production Overview */}
          <section className="xl:col-span-5 panel-glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-2 mb-4">
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                    Energy Production Overview
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Aggregated fleet solar output curve today
                  </p>
                </div>
                <span className="font-mono text-xs font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
                  {(fleetStats.totalMonthlyKwh / 1000).toFixed(2)} MWh / mo
                </span>
              </div>

              <div className="grid grid-cols-7 gap-2 items-end h-36 pt-4 px-2 rounded-xl panel-inset">
                {fleetDailyTotals.map((pt) => {
                  const pct = Math.max(8, Math.round((pt.sumKw / maxFleetHourKw) * 100));
                  return (
                    <div key={pt.time} className="flex flex-col items-center justify-end h-full pb-2">
                      <span className="font-mono text-[10px] text-slate-700 dark:text-slate-300 tabular-nums mb-1">
                        {pt.sumKw}
                      </span>
                      <div className="w-full max-w-[26px] flex-1 flex items-end">
                        <div
                          className="w-full rounded-t-md bg-gradient-to-t from-emerald-500 to-cyan-400 transition-all"
                          style={{ height: `${pct}%` }}
                        />
                      </div>
                      <span className="font-mono text-[10px] text-slate-500 mt-1.5">
                        {pt.time.slice(0, 2)}h
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <span>Fleet Peak Today: <span className="font-mono text-slate-900 dark:text-white tabular-nums">{maxFleetHourKw} kW</span></span>
              <span>Active Arrays: <span className="font-mono text-emerald-700 dark:text-emerald-400 tabular-nums">{fleetStats.onlineCount + fleetStats.warningCount}</span></span>
            </div>
          </section>

          {/* Customer Locations Overview */}
          <section className="xl:col-span-4 panel-glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                    Customer Locations
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Installed capacity & live generation by city</p>
                </div>
                <MapPin className="w-4 h-4 text-sky-600 dark:text-cyan-300" aria-hidden="true" />
              </div>

              <div className="space-y-3 mt-2">
                {cityBreakdown.map((region) => {
                  const capPct = Math.round((region.capacityKwp / Math.max(1, fleetStats.totalCapacity)) * 100);
                  return (
                    <div key={region.city} className="rounded-xl panel-inset p-3">
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-semibold text-slate-900 dark:text-white">
                          {region.city} · <span className="font-normal text-slate-500 dark:text-slate-400">{region.plants} site{region.plants === 1 ? '' : 's'}</span>
                        </span>
                        <span className="font-mono text-emerald-700 dark:text-emerald-400 tabular-nums">
                          {region.liveKw.toFixed(1)} kW live
                        </span>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-slate-200 dark:bg-slate-800 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-emerald-500"
                          style={{ width: `${capPct}%` }}
                        />
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-1">
                        <span>{region.capacityKwp.toFixed(1)} kWp</span>
                        <span>{capPct}% of fleet</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </section>

          {/* Fault & Alert Statistics */}
          <section className="xl:col-span-3 panel-glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between gap-2 mb-3">
                <div>
                  <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                    Fault & Alert Stats
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Fleet diagnostics summary</p>
                </div>
                <button
                  type="button"
                  onClick={() => onTabChange('alarms')}
                  className="text-xs font-medium text-emerald-700 dark:text-cyan-300 hover:underline whitespace-nowrap"
                >
                  Open Queue
                </button>
              </div>

              <div className="space-y-2.5 mt-2">
                <div className="rounded-xl panel-inset p-3 flex items-center justify-between">
                  <span className="inline-flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300 font-medium">
                    <AlertOctagon className="w-4 h-4 text-rose-500 dark:text-rose-400" aria-hidden="true" />
                    Critical Faults
                  </span>
                  <span className="font-mono text-base font-semibold text-slate-900 dark:text-white tabular-nums">
                    {fleetStats.criticalAlarms}
                  </span>
                </div>

                <div className="rounded-xl panel-inset p-3 flex items-center justify-between">
                  <span className="inline-flex items-center gap-2 text-xs text-amber-700 dark:text-amber-300 font-medium">
                    <AlertTriangle className="w-4 h-4 text-amber-500 dark:text-amber-400" aria-hidden="true" />
                    Grid / Inverter Warnings
                  </span>
                  <span className="font-mono text-base font-semibold text-slate-900 dark:text-white tabular-nums">
                    {fleetStats.warningAlarms}
                  </span>
                </div>

                <div className="rounded-xl panel-inset p-3 flex items-center justify-between">
                  <span className="inline-flex items-center gap-2 text-xs text-sky-700 dark:text-cyan-300 font-medium">
                    <ShieldCheck className="w-4 h-4 text-sky-600 dark:text-cyan-400" aria-hidden="true" />
                    Firmware / Info Notices
                  </span>
                  <span className="font-mono text-base font-semibold text-slate-900 dark:text-white tabular-nums">
                    {fleetStats.infoAlarms}
                  </span>
                </div>

                <div className="rounded-xl panel-inset p-3 flex items-center justify-between">
                  <span className="inline-flex items-center gap-2 text-xs text-emerald-700 dark:text-emerald-300 font-medium">
                    <Activity className="w-4 h-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                    Resolved Incidents
                  </span>
                  <span className="font-mono text-base font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
                    {fleetStats.resolvedAlarms}
                  </span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onTabChange('technicians')}
              className="mt-4 w-full min-h-[40px] rounded-xl panel-inset hover:bg-slate-200 dark:hover:bg-[#14233F] text-xs font-medium text-slate-800 dark:text-white inline-flex items-center justify-center gap-2 transition-colors"
            >
              <Wrench className="w-3.5 h-3.5 text-sky-600 dark:text-cyan-300" aria-hidden="true" />
              <span>Dispatch Technicians ({technicians.filter((t) => t.availability === 'available').length} ready)</span>
            </button>
          </section>
        </div>
      )}

      {/* Customer Support Inquiries Banner (if any submitted) */}
      {activeTab === 'fleet' && inquiries.length > 0 && (
        <section className="panel-glass rounded-2xl p-4 sm:p-5">
          <div className="flex items-center justify-between gap-2 mb-3">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              Recent Customer Support Inquiries ({inquiries.length})
            </h2>
            <button
              type="button"
              onClick={() => onTabChange('profile')}
              className="text-xs font-medium text-emerald-700 dark:text-cyan-300 hover:underline"
            >
              Configure Contact Info
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {inquiries.slice(0, 4).map((inq) => (
              <div key={inq.id} className="rounded-xl panel-inset p-3 text-xs">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-semibold text-slate-900 dark:text-white">{inq.customerName}</span>
                  <span className="font-mono text-[11px] text-slate-500">{formatTimestamp(inq.createdAtIso)}</span>
                </div>
                <p className="text-emerald-700 dark:text-emerald-400 font-medium mt-0.5">
                  {inq.category} · {inq.plantName} → {inq.target}
                </p>
                <p className="text-slate-600 dark:text-slate-300 mt-1">{inq.message}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Search & Operational Action Bar */}
      {activeTab !== 'technicians' && (
        <div className="panel-glass rounded-2xl p-3.5 sm:p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2.5 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" aria-hidden="true" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search customers, cities, plants, inverter serials..."
                aria-label="Search customers and solar systems"
                className="w-full min-h-[44px] pl-10 pr-4 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {(activeTab === 'fleet' || activeTab === 'customers') && (
              <div className="flex items-center gap-2">
                <select
                  aria-label="Filter by customer status"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as 'all' | 'active' | 'suspended')}
                  className="min-h-[44px] px-3 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="all">All Status</option>
                  <option value="active">Active Only</option>
                  <option value="suspended">Suspended</option>
                </select>

                <select
                  aria-label="Filter by city"
                  value={cityFilter}
                  onChange={(e) => setCityFilter(e.target.value)}
                  className="min-h-[44px] px-3 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-xs font-medium text-slate-800 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
                >
                  <option value="all">All Cities</option>
                  {availableCities.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              type="button"
              onClick={() => onTabChange('profile')}
              className="min-h-[44px] px-4 rounded-xl panel-inset hover:bg-slate-200 dark:hover:bg-[#14233F] text-xs font-medium text-slate-800 dark:text-white inline-flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <Settings className="w-4 h-4 text-sky-600 dark:text-cyan-300" aria-hidden="true" />
              <span>System Settings</span>
            </button>

            <button
              type="button"
              onClick={() => setShowAddCustomer(true)}
              className="min-h-[44px] px-4 rounded-xl panel-inset hover:bg-slate-200 dark:hover:bg-[#14233F] text-xs font-medium text-slate-800 dark:text-white inline-flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <UserPlus className="w-4 h-4 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
              <span>Add Customer</span>
            </button>

            <button
              type="button"
              onClick={() => setShowAddSystem(true)}
              className="min-h-[44px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold text-xs inline-flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <Plus className="w-4 h-4" aria-hidden="true" />
              <span>Add New Plant</span>
            </button>
          </div>
        </div>
      )}

      {/* Customer Management Table */}
      {(activeTab === 'fleet' || activeTab === 'customers') && (
        <section className="panel-glass rounded-2xl overflow-hidden">
          <div className="px-4 sm:px-5 py-3.5 border-b border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Customer Management ({filteredCustomers.length})
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Inspect live customer dashboards, manage access status, and verify installed kWp
              </p>
            </div>
            {activeTab === 'fleet' && (
              <button
                type="button"
                onClick={() => onTabChange('customers')}
                className="text-xs font-medium text-emerald-700 dark:text-cyan-300 hover:underline whitespace-nowrap"
              >
                Full Directory
              </button>
            )}
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/90 dark:bg-[#070D19]/90 text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800/80">
                <tr>
                  <th className="py-3 px-4 sm:px-5 font-medium">Customer</th>
                  <th className="py-3 px-4 font-medium hidden md:table-cell">Location</th>
                  <th className="py-3 px-4 font-medium text-right">Sites</th>
                  <th className="py-3 px-4 font-medium text-right">Capacity</th>
                  <th className="py-3 px-4 font-medium">Status</th>
                  <th className="py-3 px-4 sm:px-5 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800/60">
                {filteredCustomers.map((cust) => {
                  const custPlants = plants.filter((p) => p.ownerId === cust.id);
                  const totalKwp = custPlants.reduce((s, p) => s + p.capacityKwp, 0);
                  const isActive = cust.status === 'active';

                  return (
                    <tr key={cust.id} className="hover:bg-slate-100/60 dark:hover:bg-slate-800/20 transition-colors">
                      <td className="py-3.5 px-4 sm:px-5">
                        <p className="text-sm font-semibold text-slate-900 dark:text-white">{cust.name}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">{cust.email} · {cust.phone}</p>
                      </td>
                      <td className="py-3.5 px-4 hidden md:table-cell text-slate-600 dark:text-slate-300">
                        <p className="font-medium text-slate-900 dark:text-white">{cust.city}</p>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[240px]">{cust.address}</p>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-900 dark:text-white">
                        {custPlants.length}
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums text-emerald-700 dark:text-emerald-400 font-semibold">
                        {totalKwp.toFixed(1)} kWp
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`font-semibold ${isActive ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                          {isActive ? 'Active' : 'Suspended'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 sm:px-5 text-right">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => onInspectCustomer(cust.id)}
                            className="min-h-[38px] px-3 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/35 text-xs font-medium text-emerald-700 dark:text-emerald-300 inline-flex items-center gap-1.5 whitespace-nowrap"
                          >
                            <Eye className="w-3.5 h-3.5" aria-hidden="true" />
                            <span className="hidden sm:inline">Inspect</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => onToggleCustomerStatus(cust.id)}
                            className="min-h-[38px] px-3 rounded-lg panel-inset hover:bg-slate-200 dark:hover:bg-[#14233F] text-xs font-medium text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 whitespace-nowrap"
                          >
                            {isActive ? (
                              <>
                                <UserX className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" aria-hidden="true" />
                                <span className="hidden sm:inline">Suspend</span>
                              </>
                            ) : (
                              <>
                                <UserCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                                <span className="hidden sm:inline">Activate</span>
                              </>
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Plant & Inverter Management */}
      {(activeTab === 'fleet' || activeTab === 'systems') && (
        <section className="panel-glass rounded-2xl overflow-hidden">
          <div className="px-4 sm:px-5 py-3.5 border-b border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Plant & Inverter Management ({filteredPlants.length})
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Control live inverter telemetry states, review serial numbers, and dispatch fault tests
              </p>
            </div>
            {activeTab === 'fleet' && (
              <button
                type="button"
                onClick={() => onTabChange('systems')}
                className="text-xs font-medium text-emerald-700 dark:text-cyan-300 hover:underline whitespace-nowrap"
              >
                All Inverters
              </button>
            )}
          </div>

          <div className="divide-y divide-slate-200 dark:divide-slate-800/60">
            {filteredPlants.map((plant) => {
              const owner = customers.find((c) => c.id === plant.ownerId);
              const tech = technicians.find((t) => t.id === plant.assignedTechnicianId);
              const isOffline = plant.inverter.status === 'offline';

              return (
                <div
                  key={plant.id}
                  className="p-4 sm:px-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-slate-100/60 dark:hover:bg-slate-800/20 transition-colors"
                >
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <span className="text-sm font-semibold text-slate-900 dark:text-white">{plant.name}</span>
                      <InverterStatusText status={plant.inverter.status} compact />
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      Customer: <span className="text-slate-800 dark:text-slate-200">{owner?.name || 'Unassigned'}</span> · {plant.location}
                      {tech ? ` · Tech: ${tech.name}` : ''}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono tabular-nums">
                      {plant.inverter.model} · SN {plant.inverter.serialNumber} · {plant.capacityKwp} kWp
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center justify-between lg:justify-end gap-4">
                    <div className="grid grid-cols-3 gap-4 text-left lg:text-right">
                      <div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">Live PV</p>
                        <p className="font-mono text-sm font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
                          {plant.telemetry.solarKw.toFixed(2)} kW
                        </p>
                      </div>
                      <div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">Today</p>
                        <p className="font-mono text-sm font-semibold text-slate-900 dark:text-white tabular-nums">
                          {plant.telemetry.dailyKwh.toFixed(1)} kWh
                        </p>
                      </div>
                      <div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400">Temp</p>
                        <p className="font-mono text-sm font-semibold text-amber-600 dark:text-amber-300 tabular-nums">
                          {plant.inverter.temperatureC.toFixed(1)}°C
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          onSetInverterStatus(plant.id, isOffline ? 'online' : 'offline')
                        }
                        className={`min-h-[40px] px-3 rounded-xl border text-xs font-medium inline-flex items-center gap-1.5 whitespace-nowrap ${
                          isOffline
                            ? 'bg-emerald-500/15 border-emerald-500/35 text-emerald-700 dark:text-emerald-300'
                            : 'panel-inset text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-[#14233F]'
                        }`}
                      >
                        <Power className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>{isOffline ? 'Bring Online' : 'Set Offline'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onSimulateFaultAlarm(plant.id)}
                        className="min-h-[40px] px-3 rounded-xl bg-amber-500/12 hover:bg-amber-500/20 border border-amber-500/35 text-xs font-medium text-amber-700 dark:text-amber-300 inline-flex items-center gap-1.5 whitespace-nowrap"
                      >
                        <AlertTriangle className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Test Alert</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Technician / Installer Management Tab */}
      {activeTab === 'technicians' && (
        <div className="space-y-4 sm:space-y-5">
          <section className="panel-glass rounded-2xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 items-stretch">
            <div className="lg:col-span-5 relative min-h-[190px]">
              <FallbackImage
                src={ENGINEER_FIELD_IMAGE_URL}
                alt="AJ Solar commissioning field engineer"
                className="w-full h-full object-cover"
                fallbackTitle="Field Engineering Team"
              />
            </div>

            <div className="lg:col-span-7 p-4 sm:p-6 flex flex-col justify-between">
              <div>
                <h2 className="font-display text-lg sm:text-xl font-semibold text-slate-900 dark:text-white">
                  Technician & Installer Dispatch
                </h2>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
                  Manage certified AJ Solutions field engineers, track regional coverage, contact installers directly via WhatsApp or Phone, and onboard new technicians.
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 mt-5 pt-4 border-t border-slate-200 dark:border-slate-800/80">
                <div className="flex items-center gap-6 text-xs">
                  <div>
                    <p className="text-slate-500 dark:text-slate-400">Field Staff</p>
                    <p className="font-mono text-base font-semibold text-slate-900 dark:text-white tabular-nums">{technicians.length}</p>
                  </div>
                  <div>
                    <p className="text-slate-500 dark:text-slate-400">Available</p>
                    <p className="font-mono text-base font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
                      {technicians.filter((t) => t.availability === 'available').length}
                    </p>
                  </div>
                  <div>
                    <p className="text-slate-500 dark:text-slate-400">On-Site</p>
                    <p className="font-mono text-base font-semibold text-amber-600 dark:text-amber-300 tabular-nums">
                      {technicians.filter((t) => t.availability === 'on-site').length}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowAddTechnician(true)}
                  className="min-h-[44px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold text-xs inline-flex items-center gap-2 whitespace-nowrap"
                >
                  <Plus className="w-4 h-4" aria-hidden="true" />
                  <span>Add Technician</span>
                </button>
              </div>
            </div>
          </section>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {technicians.map((tech) => {
              const statusColor =
                tech.availability === 'available'
                  ? 'text-emerald-700 dark:text-emerald-400'
                  : tech.availability === 'on-site'
                    ? 'text-amber-700 dark:text-amber-300'
                    : 'text-slate-500 dark:text-slate-400';

              return (
                <article key={tech.id} className="panel-glass rounded-2xl p-4 sm:p-5 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-display text-base font-semibold text-slate-900 dark:text-white">{tech.name}</h3>
                        <p className="text-xs text-sky-700 dark:text-cyan-300 mt-0.5">{tech.roleTitle}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => onCycleTechnicianAvailability(tech.id)}
                        className={`min-h-[34px] px-2.5 rounded-lg panel-inset text-xs font-semibold capitalize ${statusColor}`}
                      >
                        {tech.availability}
                      </button>
                    </div>

                    <div className="mt-3 space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                      <p className="inline-flex items-center gap-1.5 mr-4">
                        <MapPin className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" aria-hidden="true" />
                        {tech.region}
                      </p>
                      <p className="inline-flex items-center gap-1.5 font-mono">
                        <Phone className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
                        {tech.phone}
                      </p>
                      <p className="text-slate-500 dark:text-slate-400 pt-1">{tech.certification}</p>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                      {tech.activeJobs} active · <span className="text-emerald-700 dark:text-emerald-400">{tech.completedInstalls} installs</span>
                    </span>
                    <div className="flex items-center gap-2">
                      <a
                        href={buildWhatsAppUrl(tech.phone, `Hello ${tech.name}, AJ Solutions Ops checking in on field dispatch.`)}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="min-h-[36px] px-2.5 rounded-lg bg-emerald-600/15 text-emerald-700 dark:text-emerald-300 text-xs font-medium inline-flex items-center gap-1"
                      >
                        <MessageCircle className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>WhatsApp</span>
                      </a>
                      <a
                        href={buildTelUrl(tech.phone)}
                        className="min-h-[36px] px-2.5 rounded-lg bg-sky-600/15 text-sky-700 dark:text-cyan-300 text-xs font-medium inline-flex items-center gap-1"
                      >
                        <Phone className="w-3.5 h-3.5" aria-hidden="true" />
                        <span>Call</span>
                      </a>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </div>
      )}

      {/* Add Customer Modal */}
      {showAddCustomer && (
        <div
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-cust-title"
        >
          <div className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl panel-glass p-5 sm:p-6">
            <div className="w-10 h-1 bg-slate-400 dark:bg-slate-700 rounded-full mx-auto mb-4 sm:hidden" />
            <div className="flex items-center justify-between mb-4">
              <h3 id="add-cust-title" className="font-display text-lg font-semibold text-slate-900 dark:text-white">
                Add New Customer
              </h3>
              <button
                type="button"
                onClick={() => setShowAddCustomer(false)}
                aria-label="Close modal"
                className="min-w-[40px] min-h-[40px] flex items-center justify-center text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={custName}
                  onChange={(e) => setCustName(e.target.value)}
                  placeholder="Usman Tariq"
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={custEmail}
                  onChange={(e) => setCustEmail(e.target.value)}
                  placeholder="usman@example.com"
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={custPhone}
                    onChange={(e) => setCustPhone(e.target.value)}
                    placeholder="+92 301 5551234"
                    className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">City</label>
                  <input
                    type="text"
                    value={custCity}
                    onChange={(e) => setCustCity(e.target.value)}
                    placeholder="Lahore"
                    className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Site Address</label>
                <input
                  type="text"
                  value={custAddress}
                  onChange={(e) => setCustAddress(e.target.value)}
                  placeholder="Phase 8, DHA Lahore"
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div className="pt-2 flex gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowAddCustomer(false)}
                  className="flex-1 min-h-[46px] rounded-xl panel-inset text-sm font-medium text-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 min-h-[46px] rounded-xl bg-emerald-600 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-sm font-semibold text-white dark:text-slate-950"
                >
                  Create Customer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Solar Plant Modal (Full Plant, Panel, Inverter, Battery & Status Fields) */}
      <AddPlantModal
        open={showAddSystem}
        onClose={() => setShowAddSystem(false)}
        onSubmit={onCreatePlant}
        defaultOwnerId={customers[0]?.id || 'cust-1'}
        defaultCustomerName={customers[0]?.name || 'Customer'}
        customers={customers}
        technicians={technicians}
      />

      {/* Add Technician Modal */}
      {showAddTechnician && (
        <div
          className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-tech-title"
        >
          <div className="w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl panel-glass p-5 sm:p-6">
            <div className="w-10 h-1 bg-slate-400 dark:bg-slate-700 rounded-full mx-auto mb-4 sm:hidden" />
            <div className="flex items-center justify-between mb-4">
              <h3 id="add-tech-title" className="font-display text-lg font-semibold text-slate-900 dark:text-white">
                Add Field Technician
              </h3>
              <button
                type="button"
                onClick={() => setShowAddTechnician(false)}
                aria-label="Close modal"
                className="min-w-[40px] min-h-[40px] flex items-center justify-center text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateTechnician} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Engineer Full Name</label>
                <input
                  type="text"
                  required
                  value={techName}
                  onChange={(e) => setTechName(e.target.value)}
                  placeholder="Salman Haider"
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Role / Specialization</label>
                <input
                  type="text"
                  value={techRole}
                  onChange={(e) => setTechRole(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Region</label>
                  <input
                    type="text"
                    value={techRegion}
                    onChange={(e) => setTechRegion(e.target.value)}
                    className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Phone</label>
                  <input
                    type="tel"
                    value={techPhone}
                    onChange={(e) => setTechPhone(e.target.value)}
                    placeholder="+92 300 5550199"
                    className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Certification</label>
                <input
                  type="text"
                  value={techCert}
                  onChange={(e) => setTechCert(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 rounded-xl bg-white dark:bg-[#070D19] border border-slate-300 dark:border-slate-700/70 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div className="pt-2 flex gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowAddTechnician(false)}
                  className="flex-1 min-h-[46px] rounded-xl panel-inset text-sm font-medium text-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 min-h-[46px] rounded-xl bg-emerald-600 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-sm font-semibold text-white dark:text-slate-950"
                >
                  Save Technician
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
