import React, { useMemo, useState } from 'react';
import { CurrencyCode, LanguageCode, PeriodChartPoint, SolarPlant } from '../types/solar';
import { buildWeeklySeries } from '../data/demoData';
import { formatCurrency } from '../utils/format';
import { getTranslations } from '../utils/i18n';

type ChartRange = 'daily' | 'weekly' | 'monthly' | 'yearly';
type ChartMetric = 'overview' | 'solar' | 'battery' | 'grid' | 'load';

interface EnergyChartsProps {
  plant: SolarPlant;
  currency: CurrencyCode;
  tariffPerKwh: number;
  language?: LanguageCode;
}

function buildSmoothPath(points: { x: number; y: number }[]): string {
  if (points.length === 0) return '';
  if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;
  let d = `M ${points[0].x.toFixed(1)} ${points[0].y.toFixed(1)}`;
  for (let i = 0; i < points.length - 1; i++) {
    const p0 = points[i];
    const p1 = points[i + 1];
    const midX = ((p0.x + p1.x) / 2).toFixed(1);
    d += ` C ${midX} ${p0.y.toFixed(1)}, ${midX} ${p1.y.toFixed(1)}, ${p1.x.toFixed(1)} ${p1.y.toFixed(1)}`;
  }
  return d;
}

export const EnergyCharts: React.FC<EnergyChartsProps> = ({
  plant,
  currency,
  tariffPerKwh,
  language = 'en',
}) => {
  const t = getTranslations(language);
  const [range, setRange] = useState<ChartRange>('daily');
  const [metric, setMetric] = useState<ChartMetric>('overview');
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const weeklyPoints = useMemo<PeriodChartPoint[]>(() => {
    if (plant.charts.weekly && plant.charts.weekly.length > 0) return plant.charts.weekly;
    return buildWeeklySeries(plant.telemetry.dailyKwh || plant.capacityKwp * 3.6, plant.capacityKwp * 2.3, plant.inverter.status === 'offline');
  }, [plant]);

  const periodPoints = useMemo<PeriodChartPoint[]>(() => {
    if (range === 'weekly') return weeklyPoints;
    if (range === 'monthly') return plant.charts.monthly;
    return plant.charts.yearly;
  }, [range, weeklyPoints, plant.charts.monthly, plant.charts.yearly]);

  const dailyPoints = useMemo(() => {
    return plant.charts.daily.map((pt) => ({
      ...pt,
      gridKw: pt.gridKw !== undefined ? pt.gridKw : Number((pt.loadKw - pt.solarKw).toFixed(2)),
    }));
  }, [plant.charts.daily]);

  const summary = useMemo(() => {
    const co2Factor = 0.425; // kg CO2 avoided per kWh solar
    if (range === 'daily') {
      const totalGen = plant.telemetry.dailyKwh;
      const peakSolar = Math.max(...dailyPoints.map((d) => d.solarKw), 0);
      const co2Kg = totalGen * co2Factor;
      return {
        energyLabel: 'Energy Generated (Today)',
        energyVal: `${totalGen.toFixed(1)} kWh`,
        savingsLabel: `Est. Savings (${currency})`,
        savingsVal: formatCurrency(totalGen * tariffPerKwh, currency),
        co2Label: t.co2Reduction,
        co2Val: `${co2Kg.toFixed(1)} kg`,
        fourthLabel: metric === 'battery' ? 'Current Battery SoC' : 'Peak Solar Output',
        fourthVal:
          metric === 'battery'
            ? plant.battery
              ? `${plant.telemetry.batterySoc}%`
              : 'No Battery'
            : `${peakSolar.toFixed(2)} kW`,
      };
    }

    const totalSolar = periodPoints.reduce((acc, d) => acc + d.solarKwh, 0);
    const totalExport = periodPoints.reduce((acc, d) => acc + d.exportedKwh, 0);
    const co2Kg = totalSolar * co2Factor;
    const rangeTitle = range === 'weekly' ? '7-Day' : range === 'monthly' ? '30-Day' : 'Annual';
    return {
      energyLabel: `${rangeTitle} Energy Generated`,
      energyVal: totalSolar >= 1000 ? `${totalSolar.toLocaleString()} kWh` : `${totalSolar.toFixed(1)} kWh`,
      savingsLabel: `Est. Savings (${currency})`,
      savingsVal: formatCurrency(totalSolar * tariffPerKwh, currency),
      co2Label: t.co2Reduction,
      co2Val: co2Kg >= 1000 ? `${(co2Kg / 1000).toFixed(2)} t` : `${co2Kg.toFixed(0)} kg`,
      fourthLabel: metric === 'battery' ? 'Avg Battery SoC' : 'Grid Exported',
      fourthVal:
        metric === 'battery'
          ? plant.battery
            ? `${Math.round(
                periodPoints.reduce((acc, p) => acc + (p.batterySocAvg || 75), 0) /
                  Math.max(1, periodPoints.length)
              )}%`
            : 'No Battery'
          : `${totalExport.toFixed(0)} kWh`,
    };
  }, [range, metric, plant, dailyPoints, periodPoints, currency, tariffPerKwh, t.co2Reduction]);

  const width = 760;
  const height = 248;
  const padLeft = 44;
  const padRight = 14;
  const padTop = 18;
  const padBottom = 30;
  const innerW = width - padLeft - padRight;
  const innerH = height - padTop - padBottom;

  const dailyMaxKw = useMemo(() => {
    if (metric === 'battery') return 100;
    if (metric === 'grid') {
      const m = Math.max(...dailyPoints.map((p) => Math.abs(p.gridKw || 0)), 1);
      return Math.ceil(m * 1.15);
    }
    const m = Math.max(...dailyPoints.map((p) => Math.max(p.solarKw, p.loadKw)), 1);
    return Math.ceil(m * 1.15);
  }, [dailyPoints, metric]);

  const periodMaxVal = useMemo(() => {
    if (metric === 'battery') return 100;
    if (metric === 'grid') {
      const m = Math.max(
        ...periodPoints.map((p) => Math.max(p.exportedKwh, p.importedKwh || 0)),
        5
      );
      return Math.ceil(m * 1.15);
    }
    const m = Math.max(...periodPoints.map((p) => Math.max(p.solarKwh, p.loadKwh)), 10);
    return Math.ceil(m * 1.12);
  }, [periodPoints, metric]);

  const activeDailyIdx =
    hoveredIndex !== null && range === 'daily'
      ? Math.min(hoveredIndex, dailyPoints.length - 1)
      : 12;

  const activePeriodIdx =
    hoveredIndex !== null && range !== 'daily'
      ? Math.min(hoveredIndex, periodPoints.length - 1)
      : null;

  const dailySolarCoords = dailyPoints.map((pt, i) => ({
    x: padLeft + (i / (dailyPoints.length - 1)) * innerW,
    y: padTop + innerH - (pt.solarKw / Math.max(1, dailyMaxKw)) * innerH,
  }));

  const dailyLoadCoords = dailyPoints.map((pt, i) => ({
    x: padLeft + (i / (dailyPoints.length - 1)) * innerW,
    y: padTop + innerH - (pt.loadKw / Math.max(1, dailyMaxKw)) * innerH,
  }));

  const dailyBatteryCoords = dailyPoints.map((pt, i) => ({
    x: padLeft + (i / (dailyPoints.length - 1)) * innerW,
    y: padTop + innerH - (pt.batterySoc / 100) * innerH,
  }));

  const solarLinePath = buildSmoothPath(dailySolarCoords);
  const solarAreaPath = `${solarLinePath} L ${(padLeft + innerW).toFixed(1)} ${(padTop + innerH).toFixed(1)} L ${padLeft.toFixed(1)} ${(padTop + innerH).toFixed(1)} Z`;
  const loadLinePath = buildSmoothPath(dailyLoadCoords);
  const loadAreaPath = `${loadLinePath} L ${(padLeft + innerW).toFixed(1)} ${(padTop + innerH).toFixed(1)} L ${padLeft.toFixed(1)} ${(padTop + innerH).toFixed(1)} Z`;
  const batteryLinePath = buildSmoothPath(dailyBatteryCoords);
  const batteryAreaPath = `${batteryLinePath} L ${(padLeft + innerW).toFixed(1)} ${(padTop + innerH).toFixed(1)} L ${padLeft.toFixed(1)} ${(padTop + innerH).toFixed(1)} Z`;

  const metricTabs: { id: ChartMetric; label: string }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'solar', label: 'Solar' },
    { id: 'battery', label: 'Battery SOC' },
    { id: 'grid', label: 'Grid I/O' },
    { id: 'load', label: 'Home Load' },
  ];

  const rangeTabs: { id: ChartRange; label: string }[] = [
    { id: 'daily', label: 'Daily' },
    { id: 'weekly', label: 'Weekly' },
    { id: 'monthly', label: 'Monthly' },
    { id: 'yearly', label: 'Yearly' },
  ];

  return (
    <section
      aria-label="Energy generation and analytics charts"
      className="panel-glass rounded-2xl p-4 sm:p-5"
    >
      {/* Header + Timeframe Filter */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-3">
        <div>
          <h2 className="font-display text-base sm:text-lg font-semibold text-slate-900 dark:text-white">
            {t.powerYieldAnalytics}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Solar generation, battery state of charge, grid import/export, and home consumption
          </p>
        </div>

        <div
          role="tablist"
          aria-label="Chart time range"
          className="inline-grid grid-cols-4 p-1 rounded-xl panel-inset self-start lg:self-auto"
        >
          {rangeTabs.map((tab) => (
            <button
              key={tab.id}
              type="button"
              role="tab"
              aria-selected={range === tab.id}
              onClick={() => {
                setRange(tab.id);
                setHoveredIndex(null);
              }}
              className={`min-h-[38px] px-3 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                range === tab.id
                  ? 'bg-emerald-600 dark:bg-gradient-to-r dark:from-emerald-500 dark:to-teal-400 text-white dark:text-slate-950 font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Dedicated Graph Metric Selector */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 mb-3">
        {metricTabs.map((mt) => (
          <button
            key={mt.id}
            type="button"
            onClick={() => {
              setMetric(mt.id);
              setHoveredIndex(null);
            }}
            className={`min-h-[36px] px-3 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 border ${
              metric === mt.id
                ? 'bg-emerald-500/15 border-emerald-500/45 text-emerald-700 dark:text-emerald-300 font-semibold'
                : 'panel-inset text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {mt.label}
          </button>
        ))}
      </div>

      {/* Inspection Readout Bar */}
      <div className="mb-3 px-3.5 py-2 rounded-xl panel-inset flex flex-wrap items-center justify-between gap-2 text-xs">
        {range === 'daily' ? (
          <>
            <span className="font-medium text-slate-700 dark:text-slate-300">
              {hoveredIndex !== null ? 'Inspected Hour' : 'Midday Window'} ·{' '}
              <span className="font-mono text-slate-900 dark:text-white tabular-nums">
                {dailyPoints[activeDailyIdx].time}
              </span>
            </span>
            <div className="flex flex-wrap items-center gap-3.5 font-mono tabular-nums">
              {(metric === 'overview' || metric === 'solar') && (
                <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                  Solar: {dailyPoints[activeDailyIdx].solarKw.toFixed(2)} kW
                </span>
              )}
              {(metric === 'overview' || metric === 'load') && (
                <span className="text-cyan-700 dark:text-cyan-300 font-medium">
                  Load: {dailyPoints[activeDailyIdx].loadKw.toFixed(2)} kW
                </span>
              )}
              {(metric === 'overview' || metric === 'battery') && plant.battery && (
                <span className="text-amber-700 dark:text-amber-300 font-medium">
                  SoC: {dailyPoints[activeDailyIdx].batterySoc}%
                </span>
              )}
              {metric === 'grid' && (
                <span
                  className={`font-medium ${
                    (dailyPoints[activeDailyIdx].gridKw || 0) <= 0
                      ? 'text-emerald-700 dark:text-emerald-400'
                      : 'text-sky-700 dark:text-sky-300'
                  }`}
                >
                  {(dailyPoints[activeDailyIdx].gridKw || 0) < 0
                    ? `Export: ${Math.abs(dailyPoints[activeDailyIdx].gridKw || 0).toFixed(2)} kW`
                    : `Import: ${(dailyPoints[activeDailyIdx].gridKw || 0).toFixed(2)} kW`}
                </span>
              )}
            </div>
          </>
        ) : (
          <>
            <span className="font-medium text-slate-700 dark:text-slate-300">
              {activePeriodIdx !== null
                ? periodPoints[activePeriodIdx].label
                : range === 'weekly'
                  ? '7-Day Breakdown (Tap or hover bar)'
                  : range === 'monthly'
                    ? '30-Day Daily Yield (Tap or hover bar)'
                    : '12-Month Seasonal Yield (Tap or hover bar)'}
            </span>
            {activePeriodIdx !== null && (
              <div className="flex flex-wrap items-center gap-3.5 font-mono tabular-nums">
                {(metric === 'overview' || metric === 'solar') && (
                  <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                    Solar: {periodPoints[activePeriodIdx].solarKwh} kWh
                  </span>
                )}
                {(metric === 'overview' || metric === 'load') && (
                  <span className="text-cyan-700 dark:text-cyan-300 font-medium">
                    Load: {periodPoints[activePeriodIdx].loadKwh} kWh
                  </span>
                )}
                {metric === 'battery' && (
                  <span className="text-amber-700 dark:text-amber-300 font-medium">
                    Avg SoC: {periodPoints[activePeriodIdx].batterySocAvg || 76}%
                  </span>
                )}
                {metric === 'grid' && (
                  <>
                    <span className="text-emerald-700 dark:text-emerald-400 font-medium">
                      Export: {periodPoints[activePeriodIdx].exportedKwh} kWh
                    </span>
                    <span className="text-sky-700 dark:text-sky-300 font-medium">
                      Import: {periodPoints[activePeriodIdx].importedKwh ?? 4.2} kWh
                    </span>
                  </>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* SVG Chart */}
      <div className="w-full overflow-hidden">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto select-none touch-pan-y"
          role="img"
          aria-label={`${range} ${metric} solar chart`}
          onMouseLeave={() => setHoveredIndex(null)}
        >
          <defs>
            <linearGradient id="solarCurveGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#10B981" stopOpacity="0.34" />
              <stop offset="100%" stopColor="#10B981" stopOpacity="0.01" />
            </linearGradient>
            <linearGradient id="loadCurveGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#06B6D4" stopOpacity="0.22" />
              <stop offset="100%" stopColor="#06B6D4" stopOpacity="0.0" />
            </linearGradient>
            <linearGradient id="batteryCurveGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#F59E0B" stopOpacity="0.28" />
              <stop offset="100%" stopColor="#F59E0B" stopOpacity="0.02" />
            </linearGradient>
          </defs>

          {/* Horizontal Gridlines & Y-Axis Labels */}
          {range === 'daily' && metric === 'grid' ? (
            [-1, -0.5, 0, 0.5, 1].map((ratio) => {
              const midY = padTop + innerH / 2;
              const y = midY - ratio * (innerH / 2);
              const valLabel = (dailyMaxKw * ratio).toFixed(1);
              return (
                <g key={ratio}>
                  <line
                    x1={padLeft}
                    y1={y}
                    x2={width - padRight}
                    y2={y}
                    className={ratio === 0 ? 'stroke-slate-400 dark:stroke-slate-600' : 'stroke-slate-200 dark:stroke-[#1B2B49]'}
                    strokeWidth={ratio === 0 ? '1.3' : '1'}
                    strokeDasharray={ratio === 0 ? undefined : '3 3'}
                  />
                  <text
                    x={padLeft - 8}
                    y={y + 4}
                    textAnchor="end"
                    className="fill-slate-500 dark:fill-slate-400"
                    fontSize="10.5"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    {valLabel}
                  </text>
                </g>
              );
            })
          ) : (
            [0, 0.25, 0.5, 0.75, 1].map((ratio) => {
              const y = padTop + innerH - ratio * innerH;
              const maxVal = range === 'daily' ? dailyMaxKw : periodMaxVal;
              const valLabel = Math.round(maxVal * ratio);
              return (
                <g key={ratio}>
                  <line
                    x1={padLeft}
                    y1={y}
                    x2={width - padRight}
                    y2={y}
                    className="stroke-slate-200 dark:stroke-[#1B2B49]"
                    strokeWidth="1"
                    strokeDasharray={ratio === 0 ? undefined : '3 3'}
                  />
                  <text
                    x={padLeft - 8}
                    y={y + 4}
                    textAnchor="end"
                    className="fill-slate-500 dark:fill-slate-400"
                    fontSize="11"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    {metric === 'battery' ? `${valLabel}%` : valLabel}
                  </text>
                </g>
              );
            })
          )}

          {range === 'daily' ? (
            metric === 'grid' ? (
              <>
                {dailyPoints.map((pt, idx) => {
                  const groupW = innerW / dailyPoints.length;
                  const barW = Math.max(6, groupW - 6);
                  const x = padLeft + idx * groupW + 3;
                  const midY = padTop + innerH / 2;
                  const gVal = pt.gridKw || 0;
                  const barH = (Math.abs(gVal) / Math.max(1, dailyMaxKw)) * (innerH / 2);
                  // Negative gridKw = exporting to grid (emerald downward/upward? Let's show Export upward in Emerald, Import downward in Sky)
                  const isExport = gVal <= 0;
                  const y = isExport ? midY - barH : midY;
                  const isSelected = activeDailyIdx === idx;
                  return (
                    <g
                      key={pt.time}
                      className="cursor-pointer"
                      onMouseEnter={() => setHoveredIndex(idx)}
                      onClick={() => setHoveredIndex(idx)}
                    >
                      <rect
                        x={x}
                        y={y}
                        width={barW}
                        height={Math.max(2, barH)}
                        rx="3"
                        fill={isExport ? (isSelected ? '#34D399' : '#10B981') : isSelected ? '#38BDF8' : '#0EA5E9'}
                      />
                    </g>
                  );
                })}
                {dailyPoints.map((pt, idx) => {
                  if (idx % 4 !== 0 && idx !== 23) return null;
                  const groupW = innerW / dailyPoints.length;
                  const x = padLeft + idx * groupW + groupW / 2;
                  return (
                    <text
                      key={pt.time}
                      x={x}
                      y={height - 8}
                      textAnchor="middle"
                      className="fill-slate-500 dark:fill-slate-400"
                      fontSize="11"
                      fontFamily="JetBrains Mono, monospace"
                    >
                      {pt.time.slice(0, 2)}h
                    </text>
                  );
                })}
              </>
            ) : (
              <>
                {(metric === 'overview' || metric === 'load') && (
                  <>
                    <path d={loadAreaPath} fill="url(#loadCurveGrad)" />
                    <path d={loadLinePath} fill="none" stroke="#06B6D4" strokeWidth="2.3" strokeLinecap="round" />
                  </>
                )}
                {(metric === 'overview' || metric === 'solar') && (
                  <>
                    <path d={solarAreaPath} fill="url(#solarCurveGrad)" />
                    <path d={solarLinePath} fill="none" stroke="#10B981" strokeWidth="2.6" strokeLinecap="round" />
                  </>
                )}
                {(metric === 'overview' || metric === 'battery') && plant.battery && (
                  <>
                    {metric === 'battery' && <path d={batteryAreaPath} fill="url(#batteryCurveGrad)" />}
                    <path
                      d={batteryLinePath}
                      fill="none"
                      stroke="#F59E0B"
                      strokeWidth={metric === 'battery' ? '2.6' : '1.7'}
                      strokeDasharray={metric === 'battery' ? undefined : '4 4'}
                      strokeLinecap="round"
                    />
                  </>
                )}

                {/* Inspection Crosshair */}
                <line
                  x1={dailySolarCoords[activeDailyIdx].x}
                  y1={padTop}
                  x2={dailySolarCoords[activeDailyIdx].x}
                  y2={padTop + innerH}
                  className="stroke-slate-400 dark:stroke-slate-500"
                  strokeWidth="1"
                  strokeDasharray="3 3"
                />
                {(metric === 'overview' || metric === 'solar') && (
                  <circle
                    cx={dailySolarCoords[activeDailyIdx].x}
                    cy={dailySolarCoords[activeDailyIdx].y}
                    r="5"
                    fill="#10B981"
                    className="stroke-white dark:stroke-[#0B1322]"
                    strokeWidth="2"
                  />
                )}
                {(metric === 'overview' || metric === 'load') && (
                  <circle
                    cx={dailyLoadCoords[activeDailyIdx].x}
                    cy={dailyLoadCoords[activeDailyIdx].y}
                    r="4.5"
                    fill="#06B6D4"
                    className="stroke-white dark:stroke-[#0B1322]"
                    strokeWidth="2"
                  />
                )}
                {metric === 'battery' && plant.battery && (
                  <circle
                    cx={dailyBatteryCoords[activeDailyIdx].x}
                    cy={dailyBatteryCoords[activeDailyIdx].y}
                    r="5"
                    fill="#F59E0B"
                    className="stroke-white dark:stroke-[#0B1322]"
                    strokeWidth="2"
                  />
                )}

                {dailyPoints.map((pt, idx) => {
                  if (idx % 4 !== 0 && idx !== 23) return null;
                  const x = padLeft + (idx / (dailyPoints.length - 1)) * innerW;
                  return (
                    <text
                      key={pt.time}
                      x={x}
                      y={height - 8}
                      textAnchor="middle"
                      className="fill-slate-500 dark:fill-slate-400"
                      fontSize="11"
                      fontFamily="JetBrains Mono, monospace"
                    >
                      {pt.time.slice(0, 2)}h
                    </text>
                  );
                })}

                {dailyPoints.map((pt, idx) => {
                  const sliceW = innerW / dailyPoints.length;
                  const x = padLeft + (idx / (dailyPoints.length - 1)) * innerW - sliceW / 2;
                  return (
                    <rect
                      key={pt.time}
                      x={Math.max(padLeft, x)}
                      y={padTop}
                      width={sliceW}
                      height={innerH}
                      fill="transparent"
                      className="cursor-pointer"
                      onMouseEnter={() => setHoveredIndex(idx)}
                      onClick={() => setHoveredIndex(idx)}
                    />
                  );
                })}
              </>
            )
          ) : (
            <>
              {periodPoints.map((pt, idx) => {
                const groupW = innerW / periodPoints.length;
                const isDual = metric === 'overview' || metric === 'grid';
                const barGap = range === 'monthly' ? 2 : 8;
                const barW = isDual
                  ? Math.max(4, (groupW - barGap * 2) / 2)
                  : Math.max(6, groupW - barGap * 2);
                const groupX = padLeft + idx * groupW;
                const isSelected = activePeriodIdx === idx;

                const showLabel =
                  range === 'weekly' ||
                  range === 'yearly' ||
                  idx % 5 === 0 ||
                  idx === periodPoints.length - 1;

                let firstVal = pt.solarKwh;
                let secondVal = pt.loadKwh;
                let firstColor = isSelected ? '#34D399' : '#10B981';
                let secondColor = isSelected ? '#38BDF8' : '#06B6D4';

                if (metric === 'load') {
                  firstVal = pt.loadKwh;
                  firstColor = isSelected ? '#38BDF8' : '#06B6D4';
                } else if (metric === 'battery') {
                  firstVal = pt.batterySocAvg || 76;
                  firstColor = isSelected ? '#FBBF24' : '#F59E0B';
                } else if (metric === 'grid') {
                  firstVal = pt.exportedKwh;
                  secondVal = pt.importedKwh ?? 4.2;
                  firstColor = isSelected ? '#34D399' : '#10B981';
                  secondColor = isSelected ? '#38BDF8' : '#0EA5E9';
                }

                const firstH = (firstVal / Math.max(1, periodMaxVal)) * innerH;
                const secondH = (secondVal / Math.max(1, periodMaxVal)) * innerH;

                return (
                  <g
                    key={pt.label}
                    className="cursor-pointer"
                    onMouseEnter={() => setHoveredIndex(idx)}
                    onClick={() => setHoveredIndex(idx)}
                  >
                    {isSelected && (
                      <rect
                        x={groupX}
                        y={padTop}
                        width={groupW}
                        height={innerH}
                        className="fill-slate-200/70 dark:fill-[#172642]/70"
                        rx="4"
                      />
                    )}
                    <rect
                      x={groupX + barGap * 0.5}
                      y={padTop + innerH - firstH}
                      width={barW}
                      height={Math.max(2, firstH)}
                      rx="3"
                      fill={firstColor}
                    />
                    {isDual && (
                      <rect
                        x={groupX + barGap * 0.5 + barW + 2}
                        y={padTop + innerH - secondH}
                        width={barW}
                        height={Math.max(2, secondH)}
                        rx="3"
                        fill={secondColor}
                        fillOpacity="0.88"
                      />
                    )}
                    {showLabel && (
                      <text
                        x={groupX + groupW / 2}
                        y={height - 8}
                        textAnchor="middle"
                        className="fill-slate-500 dark:fill-slate-400"
                        fontSize="11"
                        fontFamily="JetBrains Mono, monospace"
                      >
                        {range === 'monthly' ? pt.label.replace('Nov ', '') : pt.label}
                      </text>
                    )}
                  </g>
                );
              })}
            </>
          )}
        </svg>
      </div>

      {/* 4-column Summary Strip: Energy kWh, Savings PKR, CO2 Reduction, Peak/SoC */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 mt-3 border-t border-slate-200 dark:border-slate-800/80">
        <div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">{summary.energyLabel}</p>
          <p className="font-mono text-sm sm:text-base font-semibold text-slate-900 dark:text-white tabular-nums mt-0.5">
            {summary.energyVal}
          </p>
        </div>
        <div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">{summary.savingsLabel}</p>
          <p className="font-mono text-sm sm:text-base font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums mt-0.5">
            {summary.savingsVal}
          </p>
        </div>
        <div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">{summary.co2Label}</p>
          <p className="font-mono text-sm sm:text-base font-semibold text-emerald-700 dark:text-emerald-300 tabular-nums mt-0.5">
            {summary.co2Val}
          </p>
        </div>
        <div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">{summary.fourthLabel}</p>
          <p className="font-mono text-sm sm:text-base font-semibold text-cyan-700 dark:text-cyan-300 tabular-nums mt-0.5">
            {summary.fourthVal}
          </p>
        </div>
      </div>
    </section>
  );
};
