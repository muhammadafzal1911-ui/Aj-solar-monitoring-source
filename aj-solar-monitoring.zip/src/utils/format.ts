import { CurrencyCode, SolarPlant } from '../types/solar';

export function formatCurrency(amount: number, currency: CurrencyCode): string {
  const symbols: Record<CurrencyCode, string> = {
    PKR: 'Rs ',
    USD: '$',
    AED: 'AED ',
    EUR: '€',
  };
  const formatted = new Intl.NumberFormat('en-US', {
    maximumFractionDigits: currency === 'PKR' ? 0 : 2,
    minimumFractionDigits: currency === 'PKR' ? 0 : 2,
  }).format(amount);
  return `${symbols[currency]}${formatted}`;
}

export function formatRelativeTime(isoString: string): string {
  const diffMs = Date.now() - new Date(isoString).getTime();
  const diffSec = Math.max(0, Math.floor(diffMs / 1000));
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  return `${diffDays}d ago`;
}

export function formatTimestamp(isoString: string): string {
  const date = new Date(isoString);
  return date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function buildWhatsAppUrl(phoneNumber: string, prefillText: string): string {
  const digitsOnly = phoneNumber.replace(/[^0-9]/g, '');
  const encoded = encodeURIComponent(prefillText);
  return `https://wa.me/${digitsOnly}?text=${encoded}`;
}

export function buildTelUrl(phoneNumber: string): string {
  const cleaned = phoneNumber.replace(/[^0-9+]/g, '');
  return `tel:${cleaned}`;
}

export function exportPlantCsv(plant: SolarPlant, currency: CurrencyCode, tariff: number): void {
  const headers = ['Date / Period', 'Solar Generation (kWh)', 'Home Load (kWh)', 'Grid Export (kWh)', `Estimated Value (${currency})`];
  const rows = plant.charts.monthly.map((pt) => [
    pt.label,
    pt.solarKwh.toFixed(2),
    pt.loadKwh.toFixed(2),
    pt.exportedKwh.toFixed(2),
    (pt.solarKwh * tariff).toFixed(2),
  ]);

  const csvContent = [
    [`AJ Solar Monitoring — Monthly Plant Yield Report`],
    [`Plant Name`, plant.name],
    [`Location`, plant.location],
    [`Capacity`, `${plant.capacityKwp} kWp`],
    [`Inverter`, `${plant.inverter.model} (${plant.inverter.serialNumber})`],
    [],
    headers,
    ...rows,
  ]
    .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${plant.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}-solar-report.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
