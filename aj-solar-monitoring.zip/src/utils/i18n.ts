import { LanguageCode } from '../types/solar';

export interface Translations {
  demoModeBadge: string;
  demoModeNotice: string;
  navDashboard: string;
  navPlants: string;
  navAlarms: string;
  navProfile: string;
  adminNavFleet: string;
  adminNavCustomers: string;
  adminNavSystems: string;
  adminNavTeam: string;
  adminNavAlarms: string;
  adminNavSettings: string;
  liveSolarOutput: string;
  energyFlowTopology: string;
  todaysGeneration: string;
  estimatedSavings: string;
  monthlyGeneration: string;
  lifetimeTotal: string;
  co2Reduction: string;
  powerYieldAnalytics: string;
  storageLoadBalance: string;
  recentAlertsActivity: string;
  supportDeskTitle: string;
  whatsappChat: string;
  callNow: string;
  submitInquiry: string;
  plantsManagement: string;
  addNewPlant: string;
  openDashboard: string;
  backToPlants: string;
  alarmsTitle: string;
  acknowledge: string;
  resolve: string;
  markAllResolved: string;
  profileSettingsTitle: string;
  languageLabel: string;
  themeLabel: string;
  lightMode: string;
  darkMode: string;
  notificationPreferences: string;
  aboutAjTitle: string;
  signOut: string;
  saveSettings: string;
  online: string;
  warning: string;
  offline: string;
}

const EN: Translations = {
  demoModeBadge: 'DEMO MODE',
  demoModeNotice: 'Simulated solar telemetry active — no physical inverter hardware or live utility API is connected yet.',
  navDashboard: 'Dashboard',
  navPlants: 'Plants',
  navAlarms: 'Alarms',
  navProfile: 'Profile',
  adminNavFleet: 'Fleet',
  adminNavCustomers: 'Customers',
  adminNavSystems: 'Systems',
  adminNavTeam: 'Team',
  adminNavAlarms: 'Alarms',
  adminNavSettings: 'Settings',
  liveSolarOutput: 'Live Solar Output',
  energyFlowTopology: 'Energy Flow Topology',
  todaysGeneration: "Today's Generation",
  estimatedSavings: 'Estimated Savings',
  monthlyGeneration: 'Monthly Generation',
  lifetimeTotal: 'Lifetime Total',
  co2Reduction: 'CO₂ Reduction',
  powerYieldAnalytics: 'Power & Yield Analytics',
  storageLoadBalance: 'Storage & Load Balance',
  recentAlertsActivity: 'Recent Alerts & Activity',
  supportDeskTitle: 'AJ Solutions Support Desk',
  whatsappChat: 'WhatsApp Chat',
  callNow: 'Call Now',
  submitInquiry: 'Submit Inquiry',
  plantsManagement: 'Solar Plants Management',
  addNewPlant: 'Add New Plant',
  openDashboard: 'Open Live Dashboard',
  backToPlants: 'All Plants',
  alarmsTitle: 'Alarms & Fault Center',
  acknowledge: 'Acknowledge',
  resolve: 'Resolve',
  markAllResolved: 'Mark All Resolved',
  profileSettingsTitle: 'Profile & Settings',
  languageLabel: 'App Language',
  themeLabel: 'Appearance & Theme',
  lightMode: 'Light Mode',
  darkMode: 'Dark Mode',
  notificationPreferences: 'Alert & Notification Preferences',
  aboutAjTitle: 'About AJ Solutions',
  signOut: 'Sign Out',
  saveSettings: 'Save Settings',
  online: 'Online',
  warning: 'Warning',
  offline: 'Offline',
};

const UR: Translations = {
  demoModeBadge: 'ڈیمو موڈ (DEMO)',
  demoModeNotice: 'یہ نقلی سولر ڈیٹا ہے — ابھی کوئی حقیقی انورٹر ہارڈویئر منسلک نہیں ہے۔',
  navDashboard: 'ڈیش بورڈ',
  navPlants: 'پلانٹس',
  navAlarms: 'الارمز',
  navProfile: 'پروفائل',
  adminNavFleet: 'فلیٹ',
  adminNavCustomers: 'کسٹمرز',
  adminNavSystems: 'سسٹمز',
  adminNavTeam: 'ٹیم',
  adminNavAlarms: 'الارمز',
  adminNavSettings: 'سیٹنگز',
  liveSolarOutput: 'لائیو سولر پیداوار',
  energyFlowTopology: 'توانائی کے بہاؤ کا نقشہ',
  todaysGeneration: 'آج کی پیداوار',
  estimatedSavings: 'متوقع بچت',
  monthlyGeneration: 'ماہانہ پیداوار',
  lifetimeTotal: 'کل پیداوار',
  co2Reduction: 'CO₂ کمی',
  powerYieldAnalytics: 'پاور اور پیداوار کے چارٹس',
  storageLoadBalance: 'بیٹری اور گھریلو لوڈ',
  recentAlertsActivity: 'حالیہ الرٹس اور سرگرمی',
  supportDeskTitle: 'AJ سلوشنز سپورٹ ڈیسک',
  whatsappChat: 'واٹس ایپ چیٹ',
  callNow: 'ابھی کال کریں',
  submitInquiry: 'انکوائری بھیجیں',
  plantsManagement: 'سولر پلانٹس مینجمنٹ',
  addNewPlant: 'نیا پلانٹ شامل کریں',
  openDashboard: 'لائیو ڈیش بورڈ کھولیں',
  backToPlants: 'تمام پلانٹس',
  alarmsTitle: 'الارمز اور فالٹ سینٹر',
  acknowledge: 'تسلیم کریں',
  resolve: 'حل کریں',
  markAllResolved: 'سب حل شدہ نشان زد کریں',
  profileSettingsTitle: 'پروفائل اور سیٹنگز',
  languageLabel: 'ایپ کی زبان',
  themeLabel: 'ظاہری شکل اور تھیم',
  lightMode: 'لائٹ موڈ',
  darkMode: 'ڈارک موڈ',
  notificationPreferences: 'نوٹیفکیشن ترجیحات',
  aboutAjTitle: 'AJ سلوشنز کے بارے میں',
  signOut: 'لاگ آؤٹ',
  saveSettings: 'سیٹنگز محفوظ کریں',
  online: 'آن لائن',
  warning: 'انتباہ',
  offline: 'آف لائن',
};

export function getTranslations(lang: LanguageCode = 'en'): Translations {
  return lang === 'ur' ? UR : EN;
}
