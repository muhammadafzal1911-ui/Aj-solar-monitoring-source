export type UserRole = 'customer' | 'admin';
export type ThemeMode = 'light' | 'dark';
export type LanguageCode = 'en' | 'ur';
export type CurrencyCode = 'PKR' | 'USD' | 'AED' | 'EUR';

export interface UserPreferences {
  currency: CurrencyCode;
  tariffPerKwh: number;
  batteryReservePct: number;
  pushAlerts: boolean;
  smsAlerts: boolean;
  dailyDigest: boolean;
  autoRefreshSec: number;
  language?: LanguageCode;
}

export interface SupportConfig {
  companyName: string;
  whatsappNumber: string;
  supportPhone: string;
  supportEmail: string;
  supportHours: string;
}

export interface SupportInquiry {
  id: string;
  customerId: string;
  customerName: string;
  plantName: string;
  category: 'Technical Fault' | 'Battery & Backup' | 'Net Metering' | 'General Inquiry';
  target: 'AJ Solutions Admin' | 'Assigned Technician';
  message: string;
  createdAtIso: string;
  status: 'submitted' | 'in-review';
}

export interface Account {
  id: string;
  name: string;
  email: string;
  password: string;
  phone: string;
  address: string;
  city: string;
  role: UserRole;
  status: 'active' | 'suspended';
  createdAt: string;
  preferences: UserPreferences;
}

export type InverterStatus = 'online' | 'warning' | 'offline';
export type BatteryChargeState = 'charging' | 'discharging' | 'standby';

export interface DCStringTelemetry {
  id: string;
  name: string;
  voltageV: number;
  currentA: number;
  powerKw: number;
}

export interface InverterDetails {
  brand?: string;
  model: string;
  serialNumber: string;
  firmwareVersion: string;
  status: InverterStatus;
  ratedPowerKw: number;
  efficiencyPct: number;
  temperatureC: number;
  acVoltageV: number;
  acFrequencyHz: number;
  powerFactor: number;
  lastSyncIso: string;
  dcStrings: DCStringTelemetry[];
}

export interface BatteryPack {
  brand?: string;
  model: string;
  chemistry: 'LiFePO4' | 'LTO' | 'Lithium-Ion';
  capacityKwh: number;
  socPct: number;
  sohPct: number;
  powerKw: number;
  status: BatteryChargeState;
  voltageV: number;
  temperatureC: number;
  cycles: number;
}

export interface LiveTelemetry {
  solarKw: number;
  loadKw: number;
  /** Positive = importing from grid, Negative = exporting to grid */
  gridKw: number;
  batteryKw: number;
  batterySoc: number;
  batteryStatus: BatteryChargeState;
  dailyKwh: number;
  yesterdayKwh: number;
  monthlyKwh: number;
  yearlyKwh: number;
  lifetimeMwh: number;
  co2SavedKg: number;
}

export interface DailyChartPoint {
  time: string;
  solarKw: number;
  loadKw: number;
  batterySoc: number;
  gridKw?: number;
}

export interface PeriodChartPoint {
  label: string;
  solarKwh: number;
  loadKwh: number;
  exportedKwh: number;
  importedKwh?: number;
  batterySocAvg?: number;
}

export interface SolarPlant {
  id: string;
  ownerId: string;
  customerName?: string;
  name: string;
  location: string;
  city: string;
  plantType: 'Residential Hybrid' | 'Commercial Hybrid' | 'Grid-Tie Solar';
  capacityKwp: number;
  panelCount: number;
  panelBrand?: string;
  panelModel: string;
  installedDate: string;
  assignedTechnicianId?: string;
  imageUrl: string;
  inverterImageUrl: string;
  weather: {
    condition: string;
    tempC: number;
    irradianceWm2: number;
    uvIndex: number;
    windKmh: number;
    humidityPct: number;
    sunrise: string;
    sunset: string;
  };
  telemetry: LiveTelemetry;
  inverter: InverterDetails;
  battery: BatteryPack | null;
  charts: {
    daily: DailyChartPoint[];
    weekly?: PeriodChartPoint[];
    monthly: PeriodChartPoint[];
    yearly: PeriodChartPoint[];
  };
}

export type AlarmSeverity = 'critical' | 'warning' | 'info';
export type AlarmStatus = 'active' | 'acknowledged' | 'resolved';
export type AlarmCategory = 'inverter_offline' | 'battery' | 'temperature' | 'grid' | 'system';

export interface SolarAlarm {
  id: string;
  plantId: string;
  plantName: string;
  ownerId: string;
  code: string;
  title: string;
  message: string;
  recommendation: string;
  severity: AlarmSeverity;
  category?: AlarmCategory;
  status: AlarmStatus;
  timestampIso: string;
}

export interface Technician {
  id: string;
  name: string;
  roleTitle: string;
  region: string;
  phone: string;
  certification: string;
  availability: 'available' | 'on-site' | 'off-duty';
  activeJobs: number;
  completedInstalls: number;
}

export type CustomerTab = 'dashboard' | 'plants' | 'alarms' | 'profile';
export type AdminTab = 'fleet' | 'customers' | 'systems' | 'technicians' | 'alarms' | 'profile';
