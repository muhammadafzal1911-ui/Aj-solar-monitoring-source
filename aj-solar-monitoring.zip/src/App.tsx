import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  Activity,
  ArrowLeft,
  Bell,
  Cpu,
  Info,
  LayoutDashboard,
  Moon,
  Shield,
  Sun,
  User,
  Users,
  Wrench,
} from 'lucide-react';
import {
  Account,
  AdminTab,
  AlarmStatus,
  CustomerTab,
  InverterStatus,
  LanguageCode,
  SolarAlarm,
  SolarPlant,
  SupportConfig,
  SupportInquiry,
  Technician,
  ThemeMode,
} from './types/solar';
import {
  createCustomPlant,
  createStarterPlantForSignup,
  INITIAL_ACCOUNTS,
  INITIAL_ALARMS,
  INITIAL_PLANTS,
  INITIAL_SUPPORT_CONFIG,
  INITIAL_TECHNICIANS,
  NewPlantInput,
} from './data/demoData';
import { getTranslations } from './utils/i18n';
import { BrandMark } from './components/BrandMark';
import { AuthScreen } from './components/AuthScreen';
import { CustomerDashboard } from './components/CustomerDashboard';
import { PlantsInverterView } from './components/PlantsInverterView';
import { AlarmsView } from './components/AlarmsView';
import { ProfileSettingsView } from './components/ProfileSettingsView';
import { AdminDashboardView } from './components/AdminDashboardView';
import { AddPlantModal } from './components/AddPlantModal';

const STORAGE_KEY = 'aj_solar_monitoring_state_v4';
const THEME_STORAGE_KEY = 'aj_solar_theme_v1';

interface PersistedState {
  accounts: Account[];
  plants: SolarPlant[];
  alarms: SolarAlarm[];
  technicians: Technician[];
  supportConfig: SupportConfig;
  inquiries: SupportInquiry[];
  currentUserId: string | null;
}

function loadInitialTheme(): ThemeMode {
  try {
    const saved = localStorage.getItem(THEME_STORAGE_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
  } catch {
    // Fallback
  }
  return 'dark';
}

function loadInitialState(): PersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as PersistedState;
      if (
        Array.isArray(parsed.accounts) &&
        Array.isArray(parsed.plants) &&
        Array.isArray(parsed.alarms) &&
        Array.isArray(parsed.technicians)
      ) {
        return {
          ...parsed,
          supportConfig: parsed.supportConfig || INITIAL_SUPPORT_CONFIG,
          inquiries: Array.isArray(parsed.inquiries) ? parsed.inquiries : [],
        };
      }
    }
  } catch {
    // Fallback
  }
  return {
    accounts: INITIAL_ACCOUNTS,
    plants: INITIAL_PLANTS,
    alarms: INITIAL_ALARMS,
    technicians: INITIAL_TECHNICIANS,
    supportConfig: INITIAL_SUPPORT_CONFIG,
    inquiries: [],
    currentUserId: null,
  };
}

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>(loadInitialTheme);
  const [state, setState] = useState<PersistedState>(loadInitialState);
  const [customerTab, setCustomerTab] = useState<CustomerTab>('dashboard');
  const [customerTabHistory, setCustomerTabHistory] = useState<CustomerTab[]>([]);
  const [adminTab, setAdminTab] = useState<AdminTab>('fleet');
  const [adminTabHistory, setAdminTabHistory] = useState<AdminTab[]>([]);
  const [selectedPlantId, setSelectedPlantId] = useState<string>('');
  const [inspectingCustomerId, setInspectingCustomerId] = useState<string | null>(null);
  const [isLiveSim, setIsLiveSim] = useState<boolean>(true);
  const [showCustomerAddPlant, setShowCustomerAddPlant] = useState<boolean>(false);

  const navigateCustomerTab = (next: CustomerTab) => {
    if (next === customerTab) return;
    setCustomerTabHistory((prev) => [...prev.slice(-8), customerTab]);
    setCustomerTab(next);
  };

  const navigateAdminTab = (next: AdminTab) => {
    if (next === adminTab) return;
    setAdminTabHistory((prev) => [...prev.slice(-8), adminTab]);
    setAdminTab(next);
  };

  const handleBackNavigation = () => {
    if (inspectingCustomerId) {
      if (customerTabHistory.length > 0) {
        const prevTab = customerTabHistory[customerTabHistory.length - 1];
        setCustomerTabHistory((h) => h.slice(0, -1));
        setCustomerTab(prevTab);
        return;
      }
      setInspectingCustomerId(null);
      setAdminTab('customers');
      return;
    }
    if (currentAccount?.role === 'admin') {
      if (adminTabHistory.length > 0) {
        const prevTab = adminTabHistory[adminTabHistory.length - 1];
        setAdminTabHistory((h) => h.slice(0, -1));
        setAdminTab(prevTab);
      } else {
        setAdminTab('fleet');
      }
      return;
    }
    if (customerTabHistory.length > 0) {
      const prevTab = customerTabHistory[customerTabHistory.length - 1];
      setCustomerTabHistory((h) => h.slice(0, -1));
      setCustomerTab(prevTab);
    } else {
      setCustomerTab('dashboard');
    }
  };

  // Sync theme to <html class="dark"> and <meta name="theme-color">
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', theme === 'dark' ? '#0B1322' : '#F3F7FA');
    }
    try {
      localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // Ignore storage error
    }
  }, [theme]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore storage error
    }
  }, [state]);

  const currentAccount = useMemo(
    () => state.accounts.find((a) => a.id === state.currentUserId) || null,
    [state.accounts, state.currentUserId]
  );

  const effectiveCustomer = useMemo(() => {
    if (!currentAccount) return null;
    if (currentAccount.role === 'admin' && inspectingCustomerId) {
      return state.accounts.find((a) => a.id === inspectingCustomerId) || null;
    }
    if (currentAccount.role === 'customer') {
      return currentAccount;
    }
    return null;
  }, [currentAccount, inspectingCustomerId, state.accounts]);

  const customerPlants = useMemo(() => {
    if (!effectiveCustomer) return [];
    return state.plants.filter((p) => p.ownerId === effectiveCustomer.id);
  }, [effectiveCustomer, state.plants]);

  const selectedPlant = useMemo(() => {
    if (customerPlants.length === 0) return null;
    return customerPlants.find((p) => p.id === selectedPlantId) || customerPlants[0];
  }, [customerPlants, selectedPlantId]);

  const assignedTechnician = useMemo(() => {
    if (!selectedPlant?.assignedTechnicianId) return undefined;
    return state.technicians.find((t) => t.id === selectedPlant.assignedTechnicianId);
  }, [selectedPlant, state.technicians]);

  const customerAlarms = useMemo(() => {
    if (!effectiveCustomer) return [];
    return state.alarms.filter((a) => a.ownerId === effectiveCustomer.id);
  }, [effectiveCustomer, state.alarms]);

  const customerInquiries = useMemo(() => {
    if (!effectiveCustomer) return state.inquiries;
    return state.inquiries.filter((i) => i.customerId === effectiveCustomer.id);
  }, [effectiveCustomer, state.inquiries]);

  const activeAlarmCount = useMemo(() => {
    if (!currentAccount) return 0;
    if (currentAccount.role === 'admin' && !inspectingCustomerId) {
      return state.alarms.filter((a) => a.status !== 'resolved').length;
    }
    return customerAlarms.filter((a) => a.status !== 'resolved').length;
  }, [currentAccount, inspectingCustomerId, state.alarms, customerAlarms]);

  // Live solar telemetry simulation loop
  useEffect(() => {
    if (!isLiveSim || !state.currentUserId) return;
    const intervalSec = currentAccount?.preferences.autoRefreshSec || 4;
    const timer = window.setInterval(() => {
      setState((prev) => ({
        ...prev,
        plants: prev.plants.map((plant) => {
          if (plant.inverter.status === 'offline') return plant;

          const jitter = (Math.random() - 0.48) * 0.24;
          const nextSolar = Math.max(
            0.2,
            Math.min(plant.capacityKwp * 0.94, Number((plant.telemetry.solarKw + jitter).toFixed(2)))
          );
          const loadJitter = (Math.random() - 0.5) * 0.16;
          const nextLoad = Math.max(0.4, Number((plant.telemetry.loadKw + loadJitter).toFixed(2)));

          let nextBatKw = plant.telemetry.batteryKw;
          let nextSoc = plant.telemetry.batterySoc;
          let nextBatStatus = plant.telemetry.batteryStatus;

          if (plant.battery) {
            const surplus = nextSolar - nextLoad;
            if (surplus > 0.6 && nextSoc < 98) {
              nextBatStatus = 'charging';
              nextBatKw = Number(Math.min(surplus * 0.65, 3.5).toFixed(2));
              if (Math.random() > 0.72) nextSoc = Math.min(100, nextSoc + 1);
            } else if (surplus < -0.4 && nextSoc > 15) {
              nextBatStatus = 'discharging';
              nextBatKw = Number((-Math.min(Math.abs(surplus), 3.5)).toFixed(2));
              if (Math.random() > 0.72) nextSoc = Math.max(10, nextSoc - 1);
            } else {
              nextBatStatus = 'standby';
              nextBatKw = 0;
            }
          }

          const nextGrid = Number((nextLoad + nextBatKw - nextSolar).toFixed(2));
          const dailyIncrement = Number(((nextSolar * intervalSec) / 3600).toFixed(3));

          return {
            ...plant,
            telemetry: {
              ...plant.telemetry,
              solarKw: nextSolar,
              loadKw: nextLoad,
              gridKw: nextGrid,
              batteryKw: nextBatKw,
              batterySoc: nextSoc,
              batteryStatus: nextBatStatus,
              dailyKwh: Number((plant.telemetry.dailyKwh + dailyIncrement).toFixed(2)),
            },
            inverter: {
              ...plant.inverter,
              lastSyncIso: new Date().toISOString(),
            },
          };
        }),
      }));
    }, intervalSec * 1000);

    return () => window.clearInterval(timer);
  }, [isLiveSim, state.currentUserId, currentAccount?.preferences.autoRefreshSec]);

  const handleLogin = (email: string, password: string): { ok: boolean; error?: string } => {
    const match = state.accounts.find(
      (acc) => acc.email.toLowerCase() === email.toLowerCase() && acc.password === password
    );
    if (!match) {
      return { ok: false, error: 'Invalid email or password. Try one of the quick demo accounts below.' };
    }
    if (match.status === 'suspended') {
      return { ok: false, error: 'This account has been suspended by AJ Solutions Operations.' };
    }
    setInspectingCustomerId(null);
    setCustomerTab('dashboard');
    setAdminTab('fleet');
    setState((prev) => ({ ...prev, currentUserId: match.id }));
    return { ok: true };
  };

  const handleQuickDemoLogin = (email: string) => {
    const match = state.accounts.find((a) => a.email.toLowerCase() === email.toLowerCase());
    if (!match) return;
    setInspectingCustomerId(null);
    setCustomerTab('dashboard');
    setAdminTab('fleet');
    setState((prev) => ({ ...prev, currentUserId: match.id }));
  };

  const handleSignUp = (payload: {
    name: string;
    email: string;
    password: string;
    phone: string;
    address: string;
    plantName: string;
    capacityKwp: number;
  }): { ok: boolean; error?: string } => {
    const exists = state.accounts.some(
      (a) => a.email.toLowerCase() === payload.email.toLowerCase()
    );
    if (exists) {
      return { ok: false, error: 'An account with this email already exists.' };
    }

    const newId = `cust-${Date.now()}`;
    const cityGuess = payload.address.split(',').pop()?.trim() || 'Lahore';
    const newAccount: Account = {
      id: newId,
      name: payload.name,
      email: payload.email,
      password: payload.password,
      phone: payload.phone,
      address: payload.address,
      city: cityGuess,
      role: 'customer',
      status: 'active',
      createdAt: new Date().toISOString(),
      preferences: {
        currency: 'PKR',
        tariffPerKwh: 58,
        batteryReservePct: 20,
        pushAlerts: true,
        smsAlerts: true,
        dailyDigest: true,
        autoRefreshSec: 4,
      },
    };

    const starterPlant = createStarterPlantForSignup(
      newId,
      payload.name,
      payload.plantName,
      payload.capacityKwp
    );

    const welcomeAlarm: SolarAlarm = {
      id: `alm-${Date.now()}`,
      plantId: starterPlant.id,
      plantName: starterPlant.name,
      ownerId: newId,
      code: 'SYS-100',
      title: 'Solar Plant Registered & Connected',
      message: `${starterPlant.name} (${starterPlant.capacityKwp} kWp) is now streaming telemetry to AJ Solar Monitoring.`,
      recommendation: 'Review your electricity tariff rate in Profile Settings for accurate daily savings.',
      severity: 'info',
      status: 'active',
      timestampIso: new Date().toISOString(),
    };

    setInspectingCustomerId(null);
    setCustomerTab('dashboard');
    setSelectedPlantId(starterPlant.id);
    setState((prev) => ({
      ...prev,
      accounts: [newAccount, ...prev.accounts],
      plants: [starterPlant, ...prev.plants],
      alarms: [welcomeAlarm, ...prev.alarms],
      currentUserId: newId,
    }));

    return { ok: true };
  };

  const handleLogout = () => {
    setInspectingCustomerId(null);
    setState((prev) => ({ ...prev, currentUserId: null }));
  };

  const handleManualSync = (plantId: string) => {
    setState((prev) => ({
      ...prev,
      plants: prev.plants.map((p) =>
        p.id === plantId
          ? {
              ...p,
              inverter: { ...p.inverter, lastSyncIso: new Date().toISOString() },
            }
          : p
      ),
    }));
  };

  const handleUpdateAlarmStatus = (alarmId: string, status: AlarmStatus) => {
    setState((prev) => ({
      ...prev,
      alarms: prev.alarms.map((a) => (a.id === alarmId ? { ...a, status } : a)),
    }));
  };

  const handleResolveAllAlarms = () => {
    setState((prev) => ({
      ...prev,
      alarms: prev.alarms.map((a) => {
        if (effectiveCustomer && a.ownerId !== effectiveCustomer.id) return a;
        return { ...a, status: 'resolved' };
      }),
    }));
  };

  const handleUpdateAccount = (updated: Account) => {
    setState((prev) => ({
      ...prev,
      accounts: prev.accounts.map((a) => (a.id === updated.id ? updated : a)),
    }));
  };

  const handleUpdateSupportConfig = (config: SupportConfig) => {
    setState((prev) => ({ ...prev, supportConfig: config }));
  };

  const handleSubmitInquiry = (payload: {
    category: SupportInquiry['category'];
    target: SupportInquiry['target'];
    message: string;
  }) => {
    if (!currentAccount) return;
    const customer = effectiveCustomer || currentAccount;
    const newInquiry: SupportInquiry = {
      id: `inq-${Date.now()}`,
      customerId: customer.id,
      customerName: customer.name,
      plantName: selectedPlant?.name || 'General Account',
      category: payload.category,
      target: payload.target,
      message: payload.message,
      createdAtIso: new Date().toISOString(),
      status: 'submitted',
    };
    setState((prev) => ({
      ...prev,
      inquiries: [newInquiry, ...prev.inquiries],
    }));
  };

  const handleResetDemoData = () => {
    localStorage.removeItem(STORAGE_KEY);
    setInspectingCustomerId(null);
    setCustomerTab('dashboard');
    setAdminTab('fleet');
    setState({
      accounts: INITIAL_ACCOUNTS,
      plants: INITIAL_PLANTS,
      alarms: INITIAL_ALARMS,
      technicians: INITIAL_TECHNICIANS,
      supportConfig: INITIAL_SUPPORT_CONFIG,
      inquiries: [],
      currentUserId: state.currentUserId,
    });
  };

  // Admin Operations
  const handleAddCustomer = (payload: {
    name: string;
    email: string;
    phone: string;
    address: string;
    city: string;
  }) => {
    const newCust: Account = {
      id: `cust-${Date.now()}`,
      name: payload.name,
      email: payload.email,
      password: 'solar123',
      phone: payload.phone,
      address: payload.address,
      city: payload.city,
      role: 'customer',
      status: 'active',
      createdAt: new Date().toISOString(),
      preferences: {
        currency: 'PKR',
        tariffPerKwh: 58,
        batteryReservePct: 20,
        pushAlerts: true,
        smsAlerts: false,
        dailyDigest: true,
        autoRefreshSec: 4,
      },
    };
    setState((prev) => ({
      ...prev,
      accounts: [newCust, ...prev.accounts],
    }));
  };

  const handleToggleCustomerStatus = (customerId: string) => {
    setState((prev) => ({
      ...prev,
      accounts: prev.accounts.map((a) =>
        a.id === customerId
          ? { ...a, status: a.status === 'active' ? 'suspended' : 'active' }
          : a
      ),
    }));
  };

  const handleCreatePlant = (input: NewPlantInput) => {
    const newPlant = createCustomPlant(input);
    setSelectedPlantId(newPlant.id);
    setState((prev) => ({
      ...prev,
      plants: [newPlant, ...prev.plants],
    }));
  };

  const handleSetInverterStatus = (plantId: string, status: InverterStatus) => {
    setState((prev) => ({
      ...prev,
      plants: prev.plants.map((p) => {
        if (p.id !== plantId) return p;
        const isOffline = status === 'offline';
        return {
          ...p,
          telemetry: {
            ...p.telemetry,
            solarKw: isOffline ? 0 : Number((p.capacityKwp * 0.65).toFixed(2)),
            loadKw: isOffline ? 0 : Number((p.capacityKwp * 0.25).toFixed(2)),
            gridKw: isOffline ? 0 : Number((-p.capacityKwp * 0.3).toFixed(2)),
            batteryKw: isOffline ? 0 : p.telemetry.batteryKw,
          },
          inverter: {
            ...p.inverter,
            status,
            efficiencyPct: isOffline ? 0 : 97.3,
            acVoltageV: isOffline ? 0 : 230.5,
            acFrequencyHz: isOffline ? 0 : 50.0,
            lastSyncIso: new Date().toISOString(),
          },
        };
      }),
    }));
  };

  const handleSimulateFaultAlarm = (plantId: string) => {
    const plant = state.plants.find((p) => p.id === plantId);
    if (!plant) return;
    const newAlarm: SolarAlarm = {
      id: `alm-${Date.now()}`,
      plantId: plant.id,
      plantName: plant.name,
      ownerId: plant.ownerId,
      code: 'INV-307',
      title: 'DC Arc Fault Pre-Check Triggered',
      message: `Inverter ${plant.inverter.serialNumber} logged a transient DC string impedance spike on MPPT 1.`,
      recommendation: 'Inspect rooftop MC4 connectors on String 1 and verify dry conduit seals.',
      severity: 'warning',
      status: 'active',
      timestampIso: new Date().toISOString(),
    };
    setState((prev) => ({
      ...prev,
      alarms: [newAlarm, ...prev.alarms],
      plants: prev.plants.map((p) =>
        p.id === plantId ? { ...p, inverter: { ...p.inverter, status: 'warning' } } : p
      ),
    }));
  };

  const handleAddTechnician = (payload: {
    name: string;
    roleTitle: string;
    region: string;
    phone: string;
    certification: string;
  }) => {
    const newTech: Technician = {
      id: `tech-${Date.now()}`,
      name: payload.name,
      roleTitle: payload.roleTitle,
      region: payload.region,
      phone: payload.phone,
      certification: payload.certification,
      availability: 'available',
      activeJobs: 0,
      completedInstalls: 0,
    };
    setState((prev) => ({
      ...prev,
      technicians: [newTech, ...prev.technicians],
    }));
  };

  const handleCycleTechnicianAvailability = (techId: string) => {
    const order: Technician['availability'][] = ['available', 'on-site', 'off-duty'];
    setState((prev) => ({
      ...prev,
      technicians: prev.technicians.map((t) => {
        if (t.id !== techId) return t;
        const next = order[(order.indexOf(t.availability) + 1) % order.length];
        return { ...t, availability: next };
      }),
    }));
  };

  const navigateToSupportSection = () => {
    navigateCustomerTab('profile');
    window.setTimeout(() => {
      document.getElementById('support-section')?.scrollIntoView({ behavior: 'smooth' });
    }, 180);
  };

  if (!currentAccount) {
    return (
      <AuthScreen
        theme={theme}
        onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
        onLogin={handleLogin}
        onSignUp={handleSignUp}
        onQuickDemoLogin={handleQuickDemoLogin}
      />
    );
  }

  const language: LanguageCode = currentAccount.preferences.language || 'en';
  const t = getTranslations(language);
  const isAdminMode = currentAccount.role === 'admin' && !inspectingCustomerId;
  const canNavigateBack = isAdminMode
    ? adminTab !== 'fleet'
    : Boolean(inspectingCustomerId) || customerTab !== 'dashboard';

  const customerNavItems: { id: CustomerTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'dashboard', label: t.navDashboard, icon: LayoutDashboard },
    { id: 'plants', label: t.navPlants, icon: Cpu },
    { id: 'alarms', label: t.navAlarms, icon: Bell },
    { id: 'profile', label: t.navProfile, icon: User },
  ];

  const adminNavItems: { id: AdminTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'fleet', label: t.adminNavFleet, icon: Activity },
    { id: 'customers', label: t.adminNavCustomers, icon: Users },
    { id: 'systems', label: t.adminNavSystems, icon: Sun },
    { id: 'technicians', label: t.adminNavTeam, icon: Wrench },
    { id: 'alarms', label: t.adminNavAlarms, icon: Bell },
  ];

  const pageTitle = isAdminMode
    ? adminTab === 'profile'
      ? t.adminNavSettings
      : adminNavItems.find((i) => i.id === adminTab)?.label || 'Fleet Operations'
    : customerNavItems.find((i) => i.id === customerTab)?.label || 'Solar Dashboard';

  const activeScreenKey = isAdminMode ? `admin-${adminTab}` : `cust-${customerTab}-${inspectingCustomerId || 'self'}`;

  return (
    <div className="min-h-screen energy-canvas text-slate-900 dark:text-slate-100 flex relative transition-colors duration-200">
      {/* Desktop Left Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-white/90 dark:bg-[#091224]/95 backdrop-blur-xl border-r border-slate-200 dark:border-slate-800/75 z-30 transition-colors">
        <div className="h-16 px-5 flex items-center gap-3 border-b border-slate-200 dark:border-slate-800/75">
          <BrandMark size={34} />
          <div className="min-w-0">
            <span className="font-display text-sm font-semibold tracking-tight text-slate-900 dark:text-white block truncate">
              AJ Solar Monitoring
            </span>
            <span className="text-[11px] text-emerald-700 dark:text-cyan-300/80 block truncate">
              {isAdminMode ? 'AJ Solutions Ops' : 'by AJ Solutions'}
            </span>
          </div>
        </div>

        <nav className="flex-1 px-3 py-5 space-y-1" aria-label="Primary navigation">
          {isAdminMode
            ? [...adminNavItems, { id: 'profile' as AdminTab, label: t.adminNavSettings, icon: Shield }].map((item) => {
                const Icon = item.icon;
                const active = adminTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => navigateAdminTab(item.id)}
                    className={`w-full min-h-[44px] px-3.5 rounded-xl flex items-center justify-between text-sm font-medium transition-colors ${
                      active
                        ? 'bg-emerald-500/12 dark:bg-gradient-to-r dark:from-emerald-500/18 dark:to-cyan-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/25'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>{item.label}</span>
                    </span>
                    {item.id === 'alarms' && activeAlarmCount > 0 && (
                      <span className="font-mono text-xs font-semibold text-amber-600 dark:text-amber-300 tabular-nums">
                        {activeAlarmCount}
                      </span>
                    )}
                  </button>
                );
              })
            : customerNavItems.map((item) => {
                const Icon = item.icon;
                const active = customerTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => navigateCustomerTab(item.id)}
                    className={`w-full min-h-[44px] px-3.5 rounded-xl flex items-center justify-between text-sm font-medium transition-colors ${
                      active
                        ? 'bg-emerald-500/12 dark:bg-gradient-to-r dark:from-emerald-500/18 dark:to-cyan-500/10 text-emerald-700 dark:text-emerald-300 border border-emerald-500/25'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <Icon className="w-4 h-4 shrink-0" aria-hidden="true" />
                      <span>{item.label}</span>
                    </span>
                    {item.id === 'alarms' && activeAlarmCount > 0 && (
                      <span className="font-mono text-xs font-semibold text-amber-600 dark:text-amber-300 tabular-nums">
                        {activeAlarmCount}
                      </span>
                    )}
                  </button>
                );
              })}
        </nav>

        <div className="p-4 border-t border-slate-200 dark:border-slate-800/75">
          <button
            type="button"
            onClick={() => (isAdminMode ? navigateAdminTab('profile') : navigateCustomerTab('profile'))}
            className="w-full text-left flex items-center gap-3 rounded-xl p-2 -m-2 hover:bg-slate-100 dark:hover:bg-slate-800/40 transition-colors"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              {currentAccount.role === 'admin' ? <Shield className="w-4 h-4" /> : <User className="w-4 h-4" />}
            </div>
            <div className="min-w-0">
              <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">{currentAccount.name}</p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 capitalize truncate">
                {currentAccount.role} · {currentAccount.city}
              </p>
            </div>
          </button>
        </div>
      </aside>

      {/* Main Content Shell */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0 relative z-10">
        {/* Compact Sticky Top Bar */}
        <header className="sticky top-0 z-30 h-13 lg:h-16 bg-white/85 dark:bg-[#091224]/85 backdrop-blur-xl border-b border-slate-200 dark:border-slate-800/75 px-4 sm:px-6 flex items-center justify-between gap-4 transition-colors">
          <div className="flex items-center gap-2 min-w-0">
            {canNavigateBack ? (
              <button
                type="button"
                onClick={handleBackNavigation}
                aria-label="Go back"
                className="min-w-[38px] min-h-[38px] -ml-1 rounded-xl flex items-center justify-center text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800/60 transition-colors shrink-0"
              >
                <ArrowLeft className="w-4 h-4" aria-hidden="true" />
              </button>
            ) : (
              <div className="lg:hidden">
                <BrandMark size={28} />
              </div>
            )}
            <span className="font-display text-sm sm:text-base font-semibold text-slate-900 dark:text-white truncate">
              <span className="lg:hidden">AJ Solar · </span>
              {pageTitle}
            </span>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {inspectingCustomerId && (
              <button
                type="button"
                onClick={() => {
                  setInspectingCustomerId(null);
                  setAdminTab('customers');
                }}
                className="min-h-[38px] px-3 rounded-xl bg-sky-500/15 border border-sky-500/35 text-xs font-medium text-sky-700 dark:text-cyan-200 inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <ArrowLeft className="w-3.5 h-3.5" aria-hidden="true" />
                <span className="hidden sm:inline">Admin Console</span>
              </button>
            )}

            {/* Instant Theme Switcher */}
            <button
              type="button"
              onClick={() => setTheme((th) => (th === 'dark' ? 'light' : 'dark'))}
              aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
              className="min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-colors"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
            </button>

            {isAdminMode && (
              <button
                type="button"
                onClick={() => navigateAdminTab('profile')}
                aria-label="Admin System Settings"
                className="lg:hidden min-w-[40px] min-h-[40px] rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-colors"
              >
                <Shield className="w-4 h-4" aria-hidden="true" />
              </button>
            )}

            <button
              type="button"
              onClick={() => (isAdminMode ? navigateAdminTab('alarms') : navigateCustomerTab('alarms'))}
              aria-label={`Notifications, ${activeAlarmCount} unread`}
              className="relative min-w-[44px] min-h-[44px] rounded-xl flex items-center justify-center text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-colors"
            >
              <Bell className="w-5 h-5" aria-hidden="true" />
              {activeAlarmCount > 0 && (
                <span className="absolute top-2 right-2 min-w-[16px] h-4 px-1 rounded-full bg-amber-400 text-slate-950 font-mono text-[10px] font-bold flex items-center justify-center tabular-nums">
                  {activeAlarmCount}
                </span>
              )}
            </button>
          </div>
        </header>

        {/* Admin Inspection Banner */}
        {inspectingCustomerId && effectiveCustomer && (
          <div className="bg-sky-500/12 border-b border-sky-500/30 px-4 sm:px-6 py-2 text-xs text-sky-900 dark:text-cyan-100 flex items-center justify-between gap-2">
            <span className="truncate">
              Inspecting customer portal: <strong>{effectiveCustomer.name}</strong> ({effectiveCustomer.city})
            </span>
            <button
              type="button"
              onClick={() => setInspectingCustomerId(null)}
              className="text-sky-700 dark:text-cyan-300 font-semibold underline underline-offset-4 whitespace-nowrap shrink-0"
            >
              Exit Inspection
            </button>
          </div>
        )}

        {/* Main Viewport */}
        <main className="flex-1 px-4 sm:px-6 py-4 sm:py-6 pb-24 lg:pb-8 max-w-7xl w-full mx-auto space-y-4">
          {/* Explicit DEMO MODE Notice */}
          <div
            role="status"
            className="rounded-xl px-3.5 py-2.5 bg-amber-500/10 border border-amber-500/30 flex flex-wrap items-center justify-between gap-2 text-xs"
          >
            <div className="flex items-center gap-2 min-w-0">
              <Info className="w-4 h-4 text-amber-600 dark:text-amber-300 shrink-0" aria-hidden="true" />
              <span className="font-mono font-semibold text-amber-700 dark:text-amber-300 shrink-0">
                {t.demoModeBadge}
              </span>
              <span className="text-slate-700 dark:text-slate-300 truncate sm:whitespace-normal">
                {t.demoModeNotice}
              </span>
            </div>
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={activeScreenKey}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
            >
              {isAdminMode ? (
                adminTab === 'profile' ? (
                  <ProfileSettingsView
                    account={currentAccount}
                    selectedPlant={state.plants[0] || null}
                    theme={theme}
                    onChangeTheme={setTheme}
                    supportConfig={state.supportConfig}
                    onUpdateSupportConfig={handleUpdateSupportConfig}
                    inquiries={state.inquiries}
                    onSubmitInquiry={handleSubmitInquiry}
                    onUpdateAccount={handleUpdateAccount}
                    onLogout={handleLogout}
                    onResetDemoData={handleResetDemoData}
                  />
                ) : (
                  <AdminDashboardView
                    activeTab={adminTab}
                    onTabChange={navigateAdminTab}
                    accounts={state.accounts}
                    plants={state.plants}
                    alarms={state.alarms}
                    technicians={state.technicians}
                    inquiries={state.inquiries}
                    onAddCustomer={handleAddCustomer}
                    onToggleCustomerStatus={handleToggleCustomerStatus}
                    onCreatePlant={handleCreatePlant}
                    onSetInverterStatus={handleSetInverterStatus}
                    onSimulateFaultAlarm={handleSimulateFaultAlarm}
                    onInspectCustomer={(customerId) => {
                      setInspectingCustomerId(customerId);
                      setCustomerTab('dashboard');
                      setCustomerTabHistory([]);
                    }}
                    onUpdateAlarmStatus={handleUpdateAlarmStatus}
                    onResolveAllAlarms={handleResolveAllAlarms}
                    onAddTechnician={handleAddTechnician}
                    onCycleTechnicianAvailability={handleCycleTechnicianAvailability}
                  />
                )
              ) : (
                effectiveCustomer && (
                  <>
                    {customerTab === 'dashboard' && (
                      <CustomerDashboard
                        account={effectiveCustomer}
                        plants={customerPlants}
                        selectedPlant={selectedPlant}
                        onSelectPlant={setSelectedPlantId}
                        alarms={customerAlarms}
                        supportConfig={state.supportConfig}
                        assignedTechnician={assignedTechnician}
                        isLiveSim={isLiveSim}
                        onToggleLiveSim={() => setIsLiveSim((v) => !v)}
                        onManualSync={handleManualSync}
                        onNavigateAlarms={() => navigateCustomerTab('alarms')}
                        onNavigatePlants={() => navigateCustomerTab('plants')}
                        onNavigateSupport={navigateToSupportSection}
                      />
                    )}

                    {customerTab === 'plants' && (
                      <PlantsInverterView
                        plants={customerPlants}
                        selectedPlant={selectedPlant}
                        onSelectPlant={setSelectedPlantId}
                        onOpenPlantDashboard={(plantId) => {
                          setSelectedPlantId(plantId);
                          navigateCustomerTab('dashboard');
                        }}
                        onOpenAddPlant={() => setShowCustomerAddPlant(true)}
                        onUpdatePlantStatus={handleSetInverterStatus}
                        technicians={state.technicians}
                        language={language}
                      />
                    )}

                    {customerTab === 'alarms' && (
                      <AlarmsView
                        alarms={customerAlarms}
                        onUpdateAlarmStatus={handleUpdateAlarmStatus}
                        onResolveAll={handleResolveAllAlarms}
                        language={language}
                      />
                    )}

                    {customerTab === 'profile' && (
                      <ProfileSettingsView
                        account={effectiveCustomer}
                        selectedPlant={selectedPlant}
                        theme={theme}
                        onChangeTheme={setTheme}
                        supportConfig={state.supportConfig}
                        assignedTechnician={assignedTechnician}
                        inquiries={customerInquiries}
                        onSubmitInquiry={handleSubmitInquiry}
                        onUpdateAccount={handleUpdateAccount}
                        onLogout={handleLogout}
                        onResetDemoData={handleResetDemoData}
                      />
                    )}
                  </>
                )
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Customer Add Plant Modal */}
      {effectiveCustomer && (
        <AddPlantModal
          open={showCustomerAddPlant}
          onClose={() => setShowCustomerAddPlant(false)}
          onSubmit={handleCreatePlant}
          defaultOwnerId={effectiveCustomer.id}
          defaultCustomerName={effectiveCustomer.name}
          technicians={state.technicians}
        />
      )}

      {/* Android Mobile Bottom Tab Bar */}
      <nav
        aria-label="Mobile navigation"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#091224]/95 backdrop-blur-xl border-t border-slate-200 dark:border-slate-800/85 pb-safe transition-colors"
      >
        <div className={`grid ${isAdminMode ? 'grid-cols-5' : 'grid-cols-4'} h-16 items-center`}>
          {isAdminMode
            ? adminNavItems.map((item) => {
                const Icon = item.icon;
                const active = adminTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => navigateAdminTab(item.id)}
                    className={`relative min-h-[48px] flex flex-col items-center justify-center gap-0.5 transition-colors ${
                      active ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {active && (
                      <span className="absolute top-0 w-8 h-0.5 rounded-full bg-emerald-600 dark:bg-emerald-400" aria-hidden="true" />
                    )}
                    <Icon className="w-5 h-5" aria-hidden="true" />
                    <span className="text-[10px] font-medium tracking-tight">{item.label}</span>
                  </button>
                );
              })
            : customerNavItems.map((item) => {
                const Icon = item.icon;
                const active = customerTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => navigateCustomerTab(item.id)}
                    className={`relative min-h-[48px] flex flex-col items-center justify-center gap-0.5 transition-colors ${
                      active ? 'text-emerald-600 dark:text-emerald-400' : 'text-slate-500 dark:text-slate-400'
                    }`}
                  >
                    {active && (
                      <span className="absolute top-0 w-8 h-0.5 rounded-full bg-emerald-600 dark:bg-emerald-400" aria-hidden="true" />
                    )}
                    <div className="relative">
                      <Icon className="w-5 h-5" aria-hidden="true" />
                      {item.id === 'alarms' && activeAlarmCount > 0 && (
                        <span className="absolute -top-1 -right-2 min-w-[14px] h-3.5 px-1 rounded-full bg-amber-400 text-slate-950 font-mono text-[9px] font-bold flex items-center justify-center tabular-nums">
                          {activeAlarmCount}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] font-medium tracking-tight">{item.label}</span>
                  </button>
                );
              })}
        </div>
      </nav>
    </div>
  );
}
