import { Account, DailyChartPoint, PeriodChartPoint, SolarAlarm, SolarPlant, SupportConfig, Technician } from '../types/solar';

export const INITIAL_SUPPORT_CONFIG: SupportConfig = {
  companyName: 'AJ Solutions',
  whatsappNumber: '+923008421900',
  supportPhone: '+924235781900',
  supportEmail: 'support@ajsolutions.pk',
  supportHours: 'Mon–Sat · 9:00 AM – 7:00 PM',
};

export const PLANT_IMAGE_URL = '/src/assets/images/solar_rooftop_plant_1795232105284.jpg';
export const INVERTER_IMAGE_URL = '/src/assets/images/hybrid_solar_inverter_1795232104540.jpg';
export const SOLAR_FARM_IMAGE_URL = '/src/assets/images/solar_farm_aerial_1795232683357.jpg';
export const BATTERY_STORAGE_IMAGE_URL = '/src/assets/images/commercial_battery_storage_1795232683417.jpg';
export const ENGINEER_FIELD_IMAGE_URL = '/src/assets/images/solar_engineer_field_1795232684086.jpg';

function buildDailyCurve(peakKw: number, baseLoadKw: number, isOffline = false): DailyChartPoint[] {
  const solarFactors = [
    0, 0, 0, 0, 0, 0.03, 0.14, 0.34, 0.56, 0.76, 0.91, 0.98, 1.0, 0.96, 0.85, 0.68, 0.46, 0.22, 0.06, 0, 0, 0, 0, 0,
  ];
  const loadFactors = [
    0.45, 0.4, 0.38, 0.36, 0.42, 0.55, 0.75, 0.88, 0.82, 0.76, 0.85, 0.92, 1.05, 1.12, 1.08, 0.95, 0.9, 1.02, 1.25, 1.35, 1.18, 0.95, 0.7, 0.52,
  ];
  const socCurve = [
    38, 35, 33, 31, 29, 28, 30, 36, 46, 58, 70, 81, 89, 94, 96, 94, 88, 80, 72, 64, 56, 49, 44, 40,
  ];

  return solarFactors.map((sf, hour) => {
    const time = `${String(hour).padStart(2, '0')}:00`;
    const solarKw = isOffline ? 0 : Number((peakKw * sf).toFixed(2));
    const loadKw = isOffline ? 0 : Number((baseLoadKw * loadFactors[hour]).toFixed(2));
    const batterySoc = isOffline ? 24 : socCurve[hour];
    const gridKw = isOffline ? 0 : Number((loadKw - solarKw).toFixed(2));
    return { time, solarKw, loadKw, batterySoc, gridKw };
  });
}

export function buildWeeklySeries(avgDailyKwh: number, avgLoadKwh: number, isOffline = false): PeriodChartPoint[] {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const factors = [0.94, 1.03, 1.08, 0.88, 1.02, 1.06, 0.97];
  const socAvg = [74, 79, 84, 66, 78, 82, 76];
  return days.map((label, idx) => {
    const solarKwh = isOffline && idx >= 5 ? 0 : Number((avgDailyKwh * factors[idx]).toFixed(1));
    const loadKwh = isOffline && idx >= 5 ? 0 : Number((avgLoadKwh * (0.92 + (idx % 3) * 0.06)).toFixed(1));
    const exportedKwh = Number(Math.max(0, solarKwh - loadKwh * 0.62).toFixed(1));
    const importedKwh = Number(Math.max(0, loadKwh * 0.45 - solarKwh * 0.25).toFixed(1));
    return {
      label,
      solarKwh,
      loadKwh,
      exportedKwh,
      importedKwh,
      batterySocAvg: isOffline ? 24 : socAvg[idx],
    };
  });
}

function buildMonthlySeries(avgDailyKwh: number, avgLoadKwh: number, isOffline = false): PeriodChartPoint[] {
  const weatherVariance = [
    0.96, 1.04, 1.08, 0.92, 0.78, 0.88, 1.02, 1.06, 1.01, 0.99,
    0.94, 0.82, 0.68, 0.91, 1.05, 1.09, 1.03, 0.98, 1.02, 1.07,
    0.95, 0.89, 1.01, 1.06, 1.04, 0.97, 0.93, 1.02, 1.05, 0.99,
  ];
  return weatherVariance.map((variance, idx) => {
    const day = idx + 1;
    const solarKwh = isOffline && day > 28 ? 0 : Number((avgDailyKwh * variance).toFixed(1));
    const loadKwh = Number((avgLoadKwh * (0.9 + ((idx * 7) % 5) * 0.05)).toFixed(1));
    const exportedKwh = Number(Math.max(0, solarKwh - loadKwh * 0.65).toFixed(1));
    const importedKwh = Number(Math.max(0, loadKwh * 0.4 - solarKwh * 0.22).toFixed(1));
    const batterySocAvg = isOffline && day > 28 ? 24 : Math.min(96, Math.round(58 + variance * 26));
    return {
      label: `Nov ${day}`,
      solarKwh,
      loadKwh,
      exportedKwh,
      importedKwh,
      batterySocAvg,
    };
  });
}

function buildYearlySeries(capacityKwp: number): PeriodChartPoint[] {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const seasonal = [82, 95, 118, 134, 148, 152, 138, 132, 126, 112, 94, 78];
  return months.map((label, idx) => {
    const solarKwh = Number((capacityKwp * seasonal[idx]).toFixed(0));
    const loadKwh = Number((solarKwh * (idx >= 4 && idx <= 8 ? 0.84 : 0.68)).toFixed(0));
    const exportedKwh = Number(Math.max(0, solarKwh - loadKwh * 0.72).toFixed(0));
    const importedKwh = Number(Math.max(0, loadKwh * 0.35 - solarKwh * 0.16).toFixed(0));
    const batterySocAvg = Math.round(68 + (seasonal[idx] / 152) * 20);
    return { label, solarKwh, loadKwh, exportedKwh, importedKwh, batterySocAvg };
  });
}

export const INITIAL_ACCOUNTS: Account[] = [
  {
    id: 'cust-1',
    name: 'Tariq Mahmood',
    email: 'tariq@example.com',
    password: 'solar123',
    phone: '+92 300 8421904',
    address: 'House 14-B, Street 8, DHA Phase 6, Lahore',
    city: 'Lahore',
    role: 'customer',
    status: 'active',
    createdAt: '2025-03-14T09:00:00Z',
    preferences: {
      currency: 'PKR',
      tariffPerKwh: 58,
      batteryReservePct: 20,
      pushAlerts: true,
      smsAlerts: true,
      dailyDigest: true,
      autoRefreshSec: 4,
    },
  },
  {
    id: 'cust-2',
    name: 'Ayesha Siddiqui',
    email: 'ayesha@example.com',
    password: 'solar123',
    phone: '+92 321 4490122',
    address: 'Plot 22, Block 4, Clifton Commercial, Karachi',
    city: 'Karachi',
    role: 'customer',
    status: 'active',
    createdAt: '2025-06-02T11:30:00Z',
    preferences: {
      currency: 'PKR',
      tariffPerKwh: 62,
      batteryReservePct: 15,
      pushAlerts: true,
      smsAlerts: false,
      dailyDigest: true,
      autoRefreshSec: 5,
    },
  },
  {
    id: 'cust-3',
    name: 'Bilal Ahmed',
    email: 'bilal@example.com',
    password: 'solar123',
    phone: '+92 333 9182745',
    address: 'Villa 88, Sector C, Bahria Town, Islamabad',
    city: 'Islamabad',
    role: 'customer',
    status: 'active',
    createdAt: '2025-09-19T14:15:00Z',
    preferences: {
      currency: 'PKR',
      tariffPerKwh: 55,
      batteryReservePct: 25,
      pushAlerts: true,
      smsAlerts: true,
      dailyDigest: false,
      autoRefreshSec: 5,
    },
  },
  {
    id: 'cust-4',
    name: 'Zainab Textile Mills',
    email: 'ops@zainabmills.pk',
    password: 'solar123',
    phone: '+92 301 7741200',
    address: 'Plot 7, Industrial Estate, Faisalabad',
    city: 'Faisalabad',
    role: 'customer',
    status: 'active',
    createdAt: '2025-01-22T10:00:00Z',
    preferences: {
      currency: 'PKR',
      tariffPerKwh: 64,
      batteryReservePct: 15,
      pushAlerts: true,
      smsAlerts: true,
      dailyDigest: true,
      autoRefreshSec: 4,
    },
  },
  {
    id: 'admin-1',
    name: 'AJ Solar Operations',
    email: 'admin@ajsolar.com',
    password: 'admin123',
    phone: '+92 42 35781900',
    address: 'AJ Solar HQ, Gulberg III, Lahore',
    city: 'Lahore',
    role: 'admin',
    status: 'active',
    createdAt: '2024-01-10T08:00:00Z',
    preferences: {
      currency: 'PKR',
      tariffPerKwh: 58,
      batteryReservePct: 20,
      pushAlerts: true,
      smsAlerts: true,
      dailyDigest: true,
      autoRefreshSec: 4,
    },
  },
];

export const INITIAL_TECHNICIANS: Technician[] = [
  {
    id: 'tech-1',
    name: 'Kamran Raza',
    roleTitle: 'Lead Hybrid Systems Engineer',
    region: 'Lahore & Central Punjab',
    phone: '+92 300 4118920',
    certification: 'AEDB Tier-1 Certified · HV BESS',
    availability: 'available',
    activeJobs: 1,
    completedInstalls: 142,
  },
  {
    id: 'tech-2',
    name: 'Farhan Qureshi',
    roleTitle: 'Commercial Inverter Specialist',
    region: 'Karachi & Sindh',
    phone: '+92 322 8941203',
    certification: '3-Phase Grid-Tie & SCADA',
    availability: 'on-site',
    activeJobs: 2,
    completedInstalls: 98,
  },
  {
    id: 'tech-3',
    name: 'Sajid Mehmood',
    roleTitle: 'Field Service Technician',
    region: 'Islamabad & Rawalpindi',
    phone: '+92 334 5109284',
    certification: 'MPPT & Telemetry Diagnostics',
    availability: 'on-site',
    activeJobs: 1,
    completedInstalls: 76,
  },
  {
    id: 'tech-4',
    name: 'Noman Tariq',
    roleTitle: 'Industrial PV Installer',
    region: 'Faisalabad & Multan',
    phone: '+92 302 6610943',
    certification: 'MW-Scale String Array Lead',
    availability: 'available',
    activeJobs: 0,
    completedInstalls: 114,
  },
];

export const INITIAL_PLANTS: SolarPlant[] = [
  {
    id: 'plant-101',
    ownerId: 'cust-1',
    customerName: 'Tariq Mahmood',
    name: 'DHA Phase 6 Residence',
    location: 'Lahore, Punjab',
    city: 'Lahore',
    plantType: 'Residential Hybrid',
    capacityKwp: 12.4,
    panelCount: 22,
    panelBrand: 'LONGi Solar',
    panelModel: 'Longi Hi-MO 6 565W Bifacial',
    installedDate: '2025-03-18',
    assignedTechnicianId: 'tech-1',
    imageUrl: PLANT_IMAGE_URL,
    inverterImageUrl: INVERTER_IMAGE_URL,
    weather: {
      condition: 'Clear Sky',
      tempC: 27,
      irradianceWm2: 845,
      uvIndex: 7,
      windKmh: 11,
      humidityPct: 38,
      sunrise: '06:24',
      sunset: '17:18',
    },
    telemetry: {
      solarKw: 8.64,
      loadKw: 3.18,
      gridKw: -3.26,
      batteryKw: 2.2,
      batterySoc: 78,
      batteryStatus: 'charging',
      dailyKwh: 46.8,
      yesterdayKwh: 43.2,
      monthlyKwh: 1284,
      yearlyKwh: 15840,
      lifetimeMwh: 26.4,
      co2SavedKg: 11240,
    },
    inverter: {
      brand: 'AJ Solutions',
      model: 'AJ-HYB-12K Pro 3-Phase',
      serialNumber: 'AJS-12K-2503-8841',
      firmwareVersion: 'v4.12.8-HYB',
      status: 'online',
      ratedPowerKw: 12.0,
      efficiencyPct: 97.6,
      temperatureC: 41.2,
      acVoltageV: 231.4,
      acFrequencyHz: 50.01,
      powerFactor: 0.99,
      lastSyncIso: new Date(Date.now() - 12 * 1000).toISOString(),
      dcStrings: [
        { id: 'pv1', name: 'MPPT String 1 (South Array)', voltageV: 542.6, currentA: 8.8, powerKw: 4.78 },
        { id: 'pv2', name: 'MPPT String 2 (West Array)', voltageV: 518.2, currentA: 7.45, powerKw: 3.86 },
      ],
    },
    battery: {
      brand: 'AJ Vault',
      model: 'AJ Vault LFP-15',
      chemistry: 'LiFePO4',
      capacityKwh: 15.36,
      socPct: 78,
      sohPct: 99,
      powerKw: 2.2,
      status: 'charging',
      voltageV: 53.4,
      temperatureC: 29.5,
      cycles: 214,
    },
    charts: {
      daily: buildDailyCurve(10.6, 3.4),
      weekly: buildWeeklySeries(45.2, 28.4),
      monthly: buildMonthlySeries(44.5, 29.8),
      yearly: buildYearlySeries(12.4),
    },
  },
  {
    id: 'plant-102',
    ownerId: 'cust-1',
    customerName: 'Tariq Mahmood',
    name: 'Bedian Road Farmhouse',
    location: 'Lahore Cantt, Punjab',
    city: 'Lahore',
    plantType: 'Residential Hybrid',
    capacityKwp: 8.8,
    panelCount: 16,
    panelBrand: 'JinkoSolar',
    panelModel: 'Jinko Tiger Neo 550W N-Type',
    installedDate: '2025-07-09',
    assignedTechnicianId: 'tech-1',
    imageUrl: SOLAR_FARM_IMAGE_URL,
    inverterImageUrl: INVERTER_IMAGE_URL,
    weather: {
      condition: 'Mostly Sunny',
      tempC: 28,
      irradianceWm2: 790,
      uvIndex: 6,
      windKmh: 14,
      humidityPct: 41,
      sunrise: '06:24',
      sunset: '17:18',
    },
    telemetry: {
      solarKw: 5.42,
      loadKw: 1.85,
      gridKw: -3.57,
      batteryKw: 0.0,
      batterySoc: 96,
      batteryStatus: 'standby',
      dailyKwh: 31.4,
      yesterdayKwh: 32.1,
      monthlyKwh: 892,
      yearlyKwh: 9640,
      lifetimeMwh: 11.8,
      co2SavedKg: 5120,
    },
    inverter: {
      brand: 'AJ Solutions',
      model: 'AJ-HYB-8K Smart',
      serialNumber: 'AJS-08K-2507-4120',
      firmwareVersion: 'v4.12.8-HYB',
      status: 'online',
      ratedPowerKw: 8.0,
      efficiencyPct: 97.1,
      temperatureC: 38.4,
      acVoltageV: 229.8,
      acFrequencyHz: 49.98,
      powerFactor: 0.99,
      lastSyncIso: new Date(Date.now() - 18 * 1000).toISOString(),
      dcStrings: [
        { id: 'pv1', name: 'MPPT String 1 (Roof East)', voltageV: 410.4, currentA: 7.1, powerKw: 2.91 },
        { id: 'pv2', name: 'MPPT String 2 (Roof South)', voltageV: 398.0, currentA: 6.3, powerKw: 2.51 },
      ],
    },
    battery: {
      brand: 'AJ Vault',
      model: 'AJ Vault LFP-10',
      chemistry: 'LiFePO4',
      capacityKwh: 10.24,
      socPct: 96,
      sohPct: 100,
      powerKw: 0.0,
      status: 'standby',
      voltageV: 54.1,
      temperatureC: 27.8,
      cycles: 98,
    },
    charts: {
      daily: buildDailyCurve(7.4, 2.1),
      weekly: buildWeeklySeries(31.0, 17.8),
      monthly: buildMonthlySeries(30.2, 18.4),
      yearly: buildYearlySeries(8.8),
    },
  },
  {
    id: 'plant-201',
    ownerId: 'cust-2',
    customerName: 'Ayesha Siddiqui',
    name: 'Clifton Commercial Studio',
    location: 'Karachi, Sindh',
    city: 'Karachi',
    plantType: 'Commercial Hybrid',
    capacityKwp: 25.0,
    panelCount: 44,
    panelBrand: 'Canadian Solar',
    panelModel: 'Canadian Solar TOPCon 570W',
    installedDate: '2025-06-08',
    assignedTechnicianId: 'tech-2',
    imageUrl: PLANT_IMAGE_URL,
    inverterImageUrl: INVERTER_IMAGE_URL,
    weather: {
      condition: 'Warm Breeze',
      tempC: 31,
      irradianceWm2: 810,
      uvIndex: 8,
      windKmh: 19,
      humidityPct: 54,
      sunrise: '06:48',
      sunset: '17:44',
    },
    telemetry: {
      solarKw: 16.82,
      loadKw: 19.45,
      gridKw: 0.93,
      batteryKw: -1.7,
      batterySoc: 44,
      batteryStatus: 'discharging',
      dailyKwh: 98.5,
      yesterdayKwh: 104.2,
      monthlyKwh: 2780,
      yearlyKwh: 33400,
      lifetimeMwh: 41.2,
      co2SavedKg: 17520,
    },
    inverter: {
      brand: 'AJ Solutions',
      model: 'AJ-COM-25K Hybrid 3P',
      serialNumber: 'AJS-25K-2506-1190',
      firmwareVersion: 'v4.11.4-COM',
      status: 'warning',
      ratedPowerKw: 25.0,
      efficiencyPct: 96.4,
      temperatureC: 49.6,
      acVoltageV: 247.8,
      acFrequencyHz: 50.14,
      powerFactor: 0.97,
      lastSyncIso: new Date(Date.now() - 45 * 1000).toISOString(),
      dcStrings: [
        { id: 'pv1', name: 'MPPT String 1 (Main Deck A)', voltageV: 682.1, currentA: 12.6, powerKw: 8.59 },
        { id: 'pv2', name: 'MPPT String 2 (Main Deck B)', voltageV: 674.0, currentA: 12.2, powerKw: 8.23 },
      ],
    },
    battery: {
      brand: 'AJ Vault',
      model: 'AJ Commercial Rack 30kWh',
      chemistry: 'LiFePO4',
      capacityKwh: 30.72,
      socPct: 44,
      sohPct: 98,
      powerKw: -1.7,
      status: 'discharging',
      voltageV: 51.9,
      temperatureC: 33.4,
      cycles: 310,
    },
    charts: {
      daily: buildDailyCurve(21.2, 16.5),
      weekly: buildWeeklySeries(95.0, 108.0),
      monthly: buildMonthlySeries(94.0, 112.0),
      yearly: buildYearlySeries(25.0),
    },
  },
  {
    id: 'plant-301',
    ownerId: 'cust-3',
    customerName: 'Bilal Ahmed',
    name: 'Bahria Town Duplex',
    location: 'Islamabad, ICT',
    city: 'Islamabad',
    plantType: 'Residential Hybrid',
    capacityKwp: 6.6,
    panelCount: 12,
    panelBrand: 'JA Solar',
    panelModel: 'JA Solar DeepBlue 550W',
    installedDate: '2025-09-24',
    assignedTechnicianId: 'tech-3',
    imageUrl: PLANT_IMAGE_URL,
    inverterImageUrl: INVERTER_IMAGE_URL,
    weather: {
      condition: 'Partly Cloudy',
      tempC: 21,
      irradianceWm2: 520,
      uvIndex: 4,
      windKmh: 9,
      humidityPct: 48,
      sunrise: '06:31',
      sunset: '17:12',
    },
    telemetry: {
      solarKw: 0.0,
      loadKw: 0.0,
      gridKw: 0.0,
      batteryKw: 0.0,
      batterySoc: 24,
      batteryStatus: 'standby',
      dailyKwh: 11.2,
      yesterdayKwh: 22.8,
      monthlyKwh: 584,
      yearlyKwh: 4120,
      lifetimeMwh: 4.1,
      co2SavedKg: 1790,
    },
    inverter: {
      brand: 'AJ Solutions',
      model: 'AJ-HYB-6K Lite',
      serialNumber: 'AJS-06K-2509-7732',
      firmwareVersion: 'v4.10.2-HYB',
      status: 'offline',
      ratedPowerKw: 6.0,
      efficiencyPct: 0,
      temperatureC: 24.0,
      acVoltageV: 0,
      acFrequencyHz: 0,
      powerFactor: 0,
      lastSyncIso: new Date(Date.now() - 142 * 60 * 1000).toISOString(),
      dcStrings: [
        { id: 'pv1', name: 'MPPT String 1 (Roof South)', voltageV: 0, currentA: 0, powerKw: 0 },
      ],
    },
    battery: {
      brand: 'AJ Vault',
      model: 'AJ Vault LFP-5',
      chemistry: 'LiFePO4',
      capacityKwh: 5.12,
      socPct: 24,
      sohPct: 100,
      powerKw: 0.0,
      status: 'standby',
      voltageV: 50.8,
      temperatureC: 22.0,
      cycles: 48,
    },
    charts: {
      daily: buildDailyCurve(5.4, 2.0, true),
      weekly: buildWeeklySeries(21.4, 16.5, true),
      monthly: buildMonthlySeries(22.4, 17.5, true),
      yearly: buildYearlySeries(6.6),
    },
  },
  {
    id: 'plant-401',
    ownerId: 'cust-4',
    customerName: 'Zainab Textile Mills',
    name: 'Zainab Industrial Array',
    location: 'Faisalabad, Punjab',
    city: 'Faisalabad',
    plantType: 'Commercial Hybrid',
    capacityKwp: 60.0,
    panelCount: 106,
    panelBrand: 'LONGi Solar',
    panelModel: 'Longi Hi-MO 7 570W Bifacial',
    installedDate: '2025-01-28',
    assignedTechnicianId: 'tech-4',
    imageUrl: SOLAR_FARM_IMAGE_URL,
    inverterImageUrl: INVERTER_IMAGE_URL,
    weather: {
      condition: 'Sunny & Dry',
      tempC: 29,
      irradianceWm2: 880,
      uvIndex: 7,
      windKmh: 10,
      humidityPct: 33,
      sunrise: '06:28',
      sunset: '17:21',
    },
    telemetry: {
      solarKw: 46.2,
      loadKw: 38.4,
      gridKw: -4.6,
      batteryKw: 3.2,
      batterySoc: 82,
      batteryStatus: 'charging',
      dailyKwh: 248.6,
      yesterdayKwh: 239.4,
      monthlyKwh: 6840,
      yearlyKwh: 82400,
      lifetimeMwh: 114.5,
      co2SavedKg: 48600,
    },
    inverter: {
      brand: 'AJ Solutions',
      model: 'AJ-IND-60K Grid-Hybrid',
      serialNumber: 'AJS-60K-2501-0318',
      firmwareVersion: 'v5.02.1-IND',
      status: 'online',
      ratedPowerKw: 60.0,
      efficiencyPct: 98.2,
      temperatureC: 44.1,
      acVoltageV: 400.2,
      acFrequencyHz: 50.0,
      powerFactor: 0.99,
      lastSyncIso: new Date(Date.now() - 8 * 1000).toISOString(),
      dcStrings: [
        { id: 'pv1', name: 'MPPT Array East-1', voltageV: 760.4, currentA: 20.8, powerKw: 15.81 },
        { id: 'pv2', name: 'MPPT Array East-2', voltageV: 755.1, currentA: 20.1, powerKw: 15.18 },
        { id: 'pv3', name: 'MPPT Array West-1', voltageV: 748.9, currentA: 20.3, powerKw: 15.21 },
      ],
    },
    battery: {
      brand: 'AJ Vault',
      model: 'AJ Vault Commercial 60kWh',
      chemistry: 'LiFePO4',
      capacityKwh: 61.44,
      socPct: 82,
      sohPct: 99,
      powerKw: 3.2,
      status: 'charging',
      voltageV: 384.2,
      temperatureC: 30.2,
      cycles: 164,
    },
    charts: {
      daily: buildDailyCurve(52.8, 36.0),
      weekly: buildWeeklySeries(246.0, 206.0),
      monthly: buildMonthlySeries(242.0, 210.0),
      yearly: buildYearlySeries(60.0),
    },
  },
];

export const INITIAL_ALARMS: SolarAlarm[] = [
  {
    id: 'alm-1',
    plantId: 'plant-301',
    plantName: 'Bahria Town Duplex',
    ownerId: 'cust-3',
    code: 'COM-404',
    title: 'Inverter Communication Lost (Offline)',
    message: 'Data logger AJS-06K-2509-7732 has not reported telemetry for over 2 hours.',
    recommendation: 'Verify home Wi-Fi router power and check the green LED on the inverter Wi-Fi dongle.',
    severity: 'critical',
    category: 'inverter_offline',
    status: 'active',
    timestampIso: new Date(Date.now() - 140 * 60 * 1000).toISOString(),
  },
  {
    id: 'alm-2',
    plantId: 'plant-201',
    plantName: 'Clifton Commercial Studio',
    ownerId: 'cust-2',
    code: 'TMP-304',
    title: 'Inverter Heatsink Temperature Elevated (49.6°C)',
    message: 'Internal IGBT heatsink temperature reached 49.6°C under 19.4 kW peak load. Cooling fans stepped up to 90%.',
    recommendation: 'Clear dust filters around inverter intake louvers and ensure 30cm ventilation clearance.',
    severity: 'warning',
    category: 'temperature',
    status: 'active',
    timestampIso: new Date(Date.now() - 24 * 60 * 1000).toISOString(),
  },
  {
    id: 'alm-3',
    plantId: 'plant-101',
    plantName: 'DHA Phase 6 Residence',
    ownerId: 'cust-1',
    code: 'BAT-204',
    title: 'Battery Cell Thermal & Reserve Check',
    message: 'AJ Vault LFP-15 battery bank recorded overnight discharge near 20% reserve threshold before solar recharge.',
    recommendation: 'Keep minimum reserve floor at 20% in Profile Settings to preserve backup autonomy during outages.',
    severity: 'warning',
    category: 'battery',
    status: 'active',
    timestampIso: new Date(Date.now() - 95 * 60 * 1000).toISOString(),
  },
  {
    id: 'alm-4',
    plantId: 'plant-201',
    plantName: 'Clifton Commercial Studio',
    ownerId: 'cust-2',
    code: 'GRD-208',
    title: 'Grid Voltage Upper Threshold Notice',
    message: 'Utility phase voltage reached 247.8V (limit 250V). Inverter is automatically regulating reactive power.',
    recommendation: 'Monitor grid stability during off-peak hours. No manual shutdown required unless voltage exceeds 253V.',
    severity: 'warning',
    category: 'grid',
    status: 'active',
    timestampIso: new Date(Date.now() - 38 * 60 * 1000).toISOString(),
  },
  {
    id: 'alm-5',
    plantId: 'plant-101',
    plantName: 'DHA Phase 6 Residence',
    ownerId: 'cust-1',
    code: 'SYS-102',
    title: 'Firmware Update Available (v4.13.0)',
    message: 'AJ-HYB-12K Pro has a recommended MPPT shade-optimization update ready.',
    recommendation: 'Schedule update overnight when solar generation is at 0 kW.',
    severity: 'info',
    category: 'system',
    status: 'active',
    timestampIso: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'alm-6',
    plantId: 'plant-101',
    plantName: 'DHA Phase 6 Residence',
    ownerId: 'cust-1',
    code: 'BAT-110',
    title: 'Battery Reserve Threshold Reached',
    message: 'Battery State of Charge reached configured 20% reserve floor during overnight load.',
    recommendation: 'System seamlessly switched to utility grid backup. Battery recharged normally at sunrise.',
    severity: 'warning',
    category: 'battery',
    status: 'resolved',
    timestampIso: new Date(Date.now() - 18 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'alm-7',
    plantId: 'plant-102',
    plantName: 'Bedian Road Farmhouse',
    ownerId: 'cust-1',
    code: 'TMP-109',
    title: 'Afternoon Ambient Temperature Advisory',
    message: 'Inverter cabinet reached 46.2°C during peak afternoon irradiance; derating was not triggered.',
    recommendation: 'Automatic fan cooling restored nominal 38.4°C operating temperature.',
    severity: 'warning',
    category: 'temperature',
    status: 'resolved',
    timestampIso: new Date(Date.now() - 34 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'alm-8',
    plantId: 'plant-102',
    plantName: 'Bedian Road Farmhouse',
    ownerId: 'cust-1',
    code: 'GRD-105',
    title: 'Brief Utility Grid Outage — Island Mode Active',
    message: 'Grid failure detected for 24 minutes. Inverter switched to zero-ms UPS battery backup.',
    recommendation: 'Grid restored and resynchronized automatically.',
    severity: 'warning',
    category: 'grid',
    status: 'resolved',
    timestampIso: new Date(Date.now() - 42 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'alm-9',
    plantId: 'plant-401',
    plantName: 'Zainab Industrial Array',
    ownerId: 'cust-4',
    code: 'PV-108',
    title: 'Peak Irradiance Record Logged',
    message: 'Array achieved 92% rated AC output during midday thermal window.',
    recommendation: 'No action required. String balance within 1.4% tolerance.',
    severity: 'info',
    category: 'system',
    status: 'resolved',
    timestampIso: new Date(Date.now() - 26 * 60 * 60 * 1000).toISOString(),
  },
];

export interface NewPlantInput {
  ownerId: string;
  customerName: string;
  name: string;
  location: string;
  capacityKwp: number;
  panelCount: number;
  panelBrand: string;
  panelModel: string;
  inverterBrand: string;
  inverterModel: string;
  batteryBrand: string;
  batteryCapacityKwh: number;
  installedDate: string;
  status: 'online' | 'warning' | 'offline';
  plantType?: SolarPlant['plantType'];
  assignedTechnicianId?: string;
}

export function createCustomPlant(input: NewPlantInput): SolarPlant {
  const safeCap = Math.max(1, Math.min(500, input.capacityKwp || 10));
  const isOffline = input.status === 'offline';
  const isWarning = input.status === 'warning';
  const liveSolar = isOffline ? 0 : Number((safeCap * (isWarning ? 0.54 : 0.68)).toFixed(2));
  const load = isOffline ? 0 : Number((safeCap * 0.28).toFixed(2));
  const hasBattery = input.batteryCapacityKwh > 0 && input.plantType !== 'Grid-Tie Solar';
  const batteryKw = isOffline || !hasBattery ? 0 : Number((safeCap * 0.16).toFixed(2));
  const gridKw = isOffline ? 0 : Number((load + batteryKw - liveSolar).toFixed(2));
  const cityGuess = input.location.split(',')[0]?.trim() || 'Lahore';

  return {
    id: `plant-${Date.now()}`,
    ownerId: input.ownerId,
    customerName: input.customerName.trim() || 'Customer',
    name: input.name.trim() || `${input.customerName.split(' ')[0]}'s Solar Plant`,
    location: input.location.trim() || 'Lahore, Punjab',
    city: cityGuess,
    plantType:
      input.plantType ||
      (!hasBattery ? 'Grid-Tie Solar' : safeCap >= 20 ? 'Commercial Hybrid' : 'Residential Hybrid'),
    capacityKwp: safeCap,
    panelCount: Math.max(1, input.panelCount || Math.round((safeCap * 1000) / 550)),
    panelBrand: input.panelBrand.trim() || 'LONGi Solar',
    panelModel: input.panelModel.trim() || 'Hi-MO 6 550W Bifacial',
    installedDate: input.installedDate || new Date().toISOString().slice(0, 10),
    assignedTechnicianId: input.assignedTechnicianId || 'tech-1',
    imageUrl: safeCap >= 25 ? SOLAR_FARM_IMAGE_URL : PLANT_IMAGE_URL,
    inverterImageUrl: INVERTER_IMAGE_URL,
    weather: {
      condition: isOffline ? 'Partly Cloudy' : 'Clear Sky',
      tempC: 26,
      irradianceWm2: isOffline ? 410 : 835,
      uvIndex: 7,
      windKmh: 12,
      humidityPct: 39,
      sunrise: '06:24',
      sunset: '17:18',
    },
    telemetry: {
      solarKw: liveSolar,
      loadKw: load,
      gridKw,
      batteryKw,
      batterySoc: !hasBattery ? 0 : isOffline ? 24 : 76,
      batteryStatus: !hasBattery || isOffline ? 'standby' : 'charging',
      dailyKwh: Number((safeCap * (isOffline ? 1.1 : 3.7)).toFixed(1)),
      yesterdayKwh: Number((safeCap * 3.5).toFixed(1)),
      monthlyKwh: Number((safeCap * 105).toFixed(0)),
      yearlyKwh: Number((safeCap * 1240).toFixed(0)),
      lifetimeMwh: Number((safeCap * 1.4).toFixed(1)),
      co2SavedKg: Math.round(safeCap * 620),
    },
    inverter: {
      brand: input.inverterBrand.trim() || 'AJ Solutions',
      model: input.inverterModel.trim() || `AJ-HYB-${Math.round(safeCap)}K Pro`,
      serialNumber: `AJS-${Math.round(safeCap)}K-${String(Date.now()).slice(-6)}`,
      firmwareVersion: 'v4.12.8-HYB',
      status: input.status,
      ratedPowerKw: Math.round(safeCap),
      efficiencyPct: isOffline ? 0 : isWarning ? 95.8 : 97.5,
      temperatureC: isOffline ? 25.0 : isWarning ? 48.8 : 40.2,
      acVoltageV: isOffline ? 0 : isWarning ? 246.4 : 230.6,
      acFrequencyHz: isOffline ? 0 : 50.0,
      powerFactor: isOffline ? 0 : 0.99,
      lastSyncIso: new Date().toISOString(),
      dcStrings: [
        {
          id: 'pv1',
          name: 'MPPT String 1 (Main Array)',
          voltageV: isOffline ? 0 : 520.0,
          currentA: isOffline ? 0 : Number(((liveSolar * 550) / 520).toFixed(1)),
          powerKw: isOffline ? 0 : Number((liveSolar * 0.55).toFixed(2)),
        },
        {
          id: 'pv2',
          name: 'MPPT String 2 (Secondary Array)',
          voltageV: isOffline ? 0 : 498.0,
          currentA: isOffline ? 0 : Number(((liveSolar * 450) / 498).toFixed(1)),
          powerKw: isOffline ? 0 : Number((liveSolar * 0.45).toFixed(2)),
        },
      ],
    },
    battery: hasBattery
      ? {
          brand: input.batteryBrand.trim() || 'AJ Vault',
          model: `${input.batteryBrand.trim() || 'AJ Vault'} ${input.batteryCapacityKwh}kWh LFP`,
          chemistry: 'LiFePO4',
          capacityKwh: input.batteryCapacityKwh,
          socPct: isOffline ? 24 : 76,
          sohPct: 100,
          powerKw: batteryKw,
          status: isOffline ? 'standby' : 'charging',
          voltageV: 53.2,
          temperatureC: 28.6,
          cycles: 12,
        }
      : null,
    charts: {
      daily: buildDailyCurve(safeCap * 0.85, Math.max(1, safeCap * 0.31), isOffline),
      weekly: buildWeeklySeries(safeCap * 3.6, safeCap * 2.2, isOffline),
      monthly: buildMonthlySeries(safeCap * 3.6, safeCap * 2.2, isOffline),
      yearly: buildYearlySeries(safeCap),
    },
  };
}

export function createStarterPlantForSignup(ownerId: string, ownerName: string, plantName: string, capacityKwp: number): SolarPlant {
  const safeCap = Math.max(3, Math.min(250, capacityKwp || 10));
  return createCustomPlant({
    ownerId,
    customerName: ownerName,
    name: plantName,
    location: 'Lahore, Punjab',
    capacityKwp: safeCap,
    panelCount: Math.round((safeCap * 1000) / 550),
    panelBrand: 'LONGi Solar',
    panelModel: 'Hi-MO 6 550W Bifacial',
    inverterBrand: 'AJ Solutions',
    inverterModel: `AJ-HYB-${Math.round(safeCap)}K Pro`,
    batteryBrand: 'AJ Vault',
    batteryCapacityKwh: 10.24,
    installedDate: new Date().toISOString().slice(0, 10),
    status: 'online',
  });
}
